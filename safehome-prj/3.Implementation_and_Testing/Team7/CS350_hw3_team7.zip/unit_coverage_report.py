"""
Utility script to run coverage on unit tests and report results at
file, class, and method/function level.

Usage (from project root):

    uv run python unit_coverage_report.py

This will:
  - Run only tests in ``tests/unit_tests``
  - Measure coverage for the ``safehome`` package
  - Print a textual report with:
      * Per-file coverage
      * Per-class coverage
      * Per-method/function coverage
"""

from __future__ import annotations

import ast
import os
from dataclasses import dataclass
from typing import Dict, List, Optional, Set

import coverage
import pytest


PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
SRC_ROOT = os.path.join(PROJECT_ROOT, "src")


@dataclass
class SymbolCoverage:
    name: str
    kind: str  # "class" or "function" or "method"
    parent: Optional[str]  # enclosing class for methods
    lineno: int
    end_lineno: int
    executed: int = 0
    total: int = 0
    branch_executed: int = 0
    branch_total: int = 0

    @property
    def percent(self) -> float:
        if self.total == 0:
            return 100.0
        return 100.0 * self.executed / self.total

    @property
    def branch_percent(self) -> float:
        if self.branch_total == 0:
            return 100.0
        return 100.0 * self.branch_executed / self.branch_total


class _SymbolCollector(ast.NodeVisitor):
    def __init__(self) -> None:
        self.symbols: List[SymbolCoverage] = []
        self._class_stack: List[str] = []

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        parent = self._class_stack[-1] if self._class_stack else None
        self.symbols.append(
            SymbolCoverage(
                name=node.name,
                kind="class",
                parent=parent,
                lineno=node.lineno,
                end_lineno=getattr(node, "end_lineno", node.lineno),
            )
        )
        self._class_stack.append(node.name)
        self.generic_visit(node)
        self._class_stack.pop()

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        parent = self._class_stack[-1] if self._class_stack else None
        kind = "method" if parent else "function"
        self.symbols.append(
            SymbolCoverage(
                name=node.name,
                kind=kind,
                parent=parent,
                lineno=node.lineno,
                end_lineno=getattr(node, "end_lineno", node.lineno),
            )
        )
        self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        # Treat async functions the same way for coverage purposes
        self.visit_FunctionDef(node)  # type: ignore[arg-type]


def _iter_safehome_files() -> List[str]:
    files: List[str] = []
    safehome_root = os.path.join(SRC_ROOT, "safehome")
    for root, _, filenames in os.walk(safehome_root):
        for fn in filenames:
            if fn.endswith(".py"):
                files.append(os.path.join(root, fn))
    return files


def _collect_symbols_for_file(path: str) -> List[SymbolCoverage]:
    with open(path, "r", encoding="utf-8") as f:
        source = f.read()
    tree = ast.parse(source, filename=path)
    collector = _SymbolCollector()
    collector.visit(tree)
    return collector.symbols


def _compute_symbol_coverage(
    cov: coverage.Coverage,
) -> Dict[str, List[SymbolCoverage]]:
    data = cov.get_data()
    per_file_symbols: Dict[str, List[SymbolCoverage]] = {}

    for path in _iter_safehome_files():
        # Coverage only knows about measured files
        if os.path.abspath(path) not in data.measured_files():
            continue

        filename, statements, _, missing, _ = cov.analysis2(path)
        statements_set: Set[int] = set(statements)
        missing_set: Set[int] = set(missing)

        # Branch stats by line (if branch data is collected)
        branch_stats_by_line = {}
        if data.has_arcs():
            try:
                analysis = cov._analyze(path)  # type: ignore[attr-defined]
                if hasattr(analysis, "branch_stats"):
                    branch_stats_by_line = analysis.branch_stats()  # type: ignore[assignment]
            except Exception:
                branch_stats_by_line = {}

        symbols = _collect_symbols_for_file(path)
        for sym in symbols:
            # Line range for the symbol
            line_range = set(range(sym.lineno, sym.end_lineno + 1))
            relevant = statements_set & line_range
            if not relevant:
                sym.total = 0
                sym.executed = 0
            else:
                sym.total = len(relevant)
                sym.executed = len(relevant - missing_set)

            # Branch coverage within this symbol
            if branch_stats_by_line:
                total_b = 0
                missed_b = 0
                for line, (num_branches, num_missing) in branch_stats_by_line.items():
                    if line in line_range:
                        total_b += num_branches
                        missed_b += num_missing
                sym.branch_total = total_b
                sym.branch_executed = total_b - missed_b

        per_file_symbols[filename] = symbols

    return per_file_symbols


def run_unit_coverage() -> None:
    # Configure coverage to focus on the safehome package
    cov = coverage.Coverage(source=["safehome"], data_file=".coverage.unit", branch=True)
    cov.erase()
    cov.start()

    # Run only unit tests
    print("Running unit tests with coverage ...")
    exit_code = pytest.main(["tests/unit_tests", "-q"])

    cov.stop()
    cov.save()

    if exit_code != 0:
        print(f"WARNING: pytest exited with code {exit_code}")

    print("\n=== File-level coverage (safehome) ===")
    cov.report(show_missing=False, precision=1)

    # Compute class/method-level coverage
    per_file_symbols = _compute_symbol_coverage(cov)

    print("\n=== Class, method/function, and branch coverage (safehome) ===")
    for filename in sorted(per_file_symbols.keys()):
        rel = os.path.relpath(filename, PROJECT_ROOT)
        print(f"\n[{rel}]")

        # Group by class
        classes: Dict[str, SymbolCoverage] = {}
        methods_by_class: Dict[Optional[str], List[SymbolCoverage]] = {}

        for sym in per_file_symbols[filename]:
            if sym.kind == "class":
                classes[sym.name] = sym
            else:
                methods_by_class.setdefault(sym.parent, []).append(sym)

        # File-level branch summary
        try:
            data = cov.get_data()
            if data.has_arcs():
                analysis = cov._analyze(filename)  # type: ignore[attr-defined]
                branch_stats = (
                    analysis.branch_stats() if hasattr(analysis, "branch_stats") else {}
                )
                total_b = 0
                missed_b = 0
                for _, (num_branches, num_missing) in branch_stats.items():
                    total_b += num_branches
                    missed_b += num_missing
                executed_b = total_b - missed_b
                percent_b = 100.0 if total_b == 0 else 100.0 * executed_b / total_b
                print(
                    f"  File branches: {executed_b}/{total_b} covered, "
                    f"{missed_b} missed ({percent_b:.1f}%)"
                )
            else:
                print("  File branches: (branch data not collected)")
        except Exception:
            print("  File branches: (unable to compute)")

        # Module-level functions
        top_level_funcs = methods_by_class.get(None, [])
        if top_level_funcs:
            print("  Functions:")
            for f in sorted(top_level_funcs, key=lambda s: s.lineno):
                print(
                    f"    - {f.name} (lines {f.lineno}-{f.end_lineno}): "
                    f"{f.executed}/{f.total} lines, {f.percent:.1f}% | "
                    f"branches {f.branch_executed}/{f.branch_total} ({f.branch_percent:.1f}%)"
                )

        # Class-level summaries
        class_entries = sorted(classes.values(), key=lambda sym: sym.lineno)
        if class_entries:
            print("  Classes:")
            for cls_sym in class_entries:
                print(
                    f"    - {cls_sym.name} (lines {cls_sym.lineno}-{cls_sym.end_lineno}): "
                    f"{cls_sym.executed}/{cls_sym.total} lines, {cls_sym.percent:.1f}% | "
                    f"branches {cls_sym.branch_executed}/{cls_sym.branch_total} "
                    f"({cls_sym.branch_percent:.1f}%)"
                )

        # Methods grouped separately, prefixed with their parent class name
        method_entries = []
        for cls_name, methods in methods_by_class.items():
            if cls_name is None:
                continue
            cls_sym = classes.get(cls_name)
            cls_lineno = cls_sym.lineno if cls_sym else 0
            for method_sym in methods:
                method_entries.append((cls_lineno, method_sym))

        if method_entries:
            print("  Methods:")
            for _, method_sym in sorted(method_entries, key=lambda item: (item[0], item[1].lineno)):
                parent_name = method_sym.parent or "<module>"
                print(
                    f"    - {parent_name}.{method_sym.name} "
                    f"(lines {method_sym.lineno}-{method_sym.end_lineno}): "
                    f"{method_sym.executed}/{method_sym.total} lines, {method_sym.percent:.1f}% | "
                    f"branches {method_sym.branch_executed}/{method_sym.branch_total} "
                    f"({method_sym.branch_percent:.1f}%)"
                )


if __name__ == "__main__":
    run_unit_coverage()
