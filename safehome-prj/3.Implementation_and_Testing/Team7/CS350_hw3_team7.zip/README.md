# CS350 SAFEHOME PROJECT

## Overview

This project uses **uv** for environment and dependency management. The sections below explain how to run the application as an end user, how to prepare a development environment, and how to execute tests.

## Running as a User

To install and synchronize standard dependencies:

```bash
uv sync
```

## Running as a Developer

To install and synchronize development dependencies:

```bash
uv sync --extra dev
```

## Running Tests (Development Only)

To execute the test suite with pytest:

```bash
uv run pytest
```
