import pytest
import tkinter as tk
from safehome.web.pages.safeHomeModeRemovePage import SafeHomeModeRemovePage


@pytest.fixture
def root():
    root = tk.Tk()
    root.withdraw()
    yield root
    root.destroy()


@pytest.fixture
def selected_mode():
    return {"name": "Night Mode", "sensor_list": ["sensor1"]}


def test_draw_page_and_cancel(root, selected_mode):
    page = SafeHomeModeRemovePage(root, selected_mode, remove_action_callback=lambda: None)
    page.drawPage()
    # Window should exist
    assert page.window.winfo_exists() == 1

    # Cancel closes the window
    page._cancel()
    assert not page.window.winfo_exists()
