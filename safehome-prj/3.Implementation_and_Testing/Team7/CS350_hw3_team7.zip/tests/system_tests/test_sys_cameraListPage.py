# test_system_cameraListPage.py
import tkinter as tk
from safehome.web.pages.camera.cameraListPage import CameraListPage


def test_camera_list_page_system():
    root = tk.Tk()
    root.geometry("600x400")

    # Mock switch page callback
    switched = []

    def switch_page(pid):
        switched.append(pid)

    page = CameraListPage(root, page_id=0, switch_page_callback=switch_page)

    # Mock camera list manually to avoid CameraManager dependency
    page.camera_list = [
        {"id": "Cam1", "hasPassword": False},
        {"id": "Cam2", "hasPassword": False},
    ]
    page._update_camera_buttons()
    page.drawPage()

    # Schedule root.quit to end loop
    root.after(200, root.quit)
    root.mainloop()

    # Verify buttons exist
    buttons = [w for w in page.camera_container.winfo_children() if isinstance(w, tk.Button)]
    assert len(buttons) == 2
    assert buttons[0].cget("text") == "Cam1"
    assert buttons[1].cget("text") == "Cam2"

    # Test View as Thumbnail button triggers callback
    page._view_thumbnail()
    assert switched[0] == "thumbnail"
