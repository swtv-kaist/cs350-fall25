import pytest
import tkinter as tk

from safehome.controlPanel import MyControlPanel


@pytest.fixture
def root():
    r = tk.Tk()
    r.withdraw()
    yield r
    r.destroy()


def test_login_success_and_main_menu_flow(root):
    callbacks = {"calls": []}

    def system_callback(event, data):
        callbacks["calls"].append((event, data))
        if event == "login":
            # Accept only password 1234
            return data == "1234"
        return None

    panel = MyControlPanel(master=root, system_callback=system_callback)

    # Simulate entering password "1234"
    panel.button1()
    panel.button2()
    panel.button3()
    panel.button4()

    # After 4 digits the callback should have been invoked and
    # panel should transition to "main" status on success.
    assert ("login", "1234") in callbacks["calls"]
    assert panel.status == "main"

    # In main menu, press button2 to turn system on, button3 to turn off.
    panel.button2()
    panel.button3()
    assert ("on", []) in callbacks["calls"]
    assert ("off", []) in callbacks["calls"]


def test_mode_change_and_panic_flow(root):
    callbacks = {"calls": [], "mode": "Home"}

    def system_callback(event, data):
        callbacks["calls"].append((event, data))
        if event == "cur_mode":
            return callbacks["mode"]
        if event == "mode":
            callbacks["mode"] = data
            return callbacks["mode"]

    panel = MyControlPanel(master=root, system_callback=system_callback)

    # Bypass login for this test
    panel.status = "main"
    panel.set_main_display()

    # Enter mode selection via button1
    panel.button1()
    assert panel.status == "mode"
    assert ("cur_mode", []) in callbacks["calls"]

    # Cycle through different modes with buttons 1-4
    panel.button1()  # Home
    panel.button2()  # Away
    panel.button3()  # Overnight travel
    panel.button4()  # Extended Travel

    mode_events = [c for c in callbacks["calls"] if c[0] == "mode"]
    assert mode_events  # at least one mode change requested

    # Panic button should update display but not require callback
    panel.button_star()
    assert panel.status == "panic"
    # We only assert that the callback history did not include a panic-specific event
    # (panic is a pure UI effect here).
    assert all(call[0] != "panic" for call in callbacks["calls"])


def test_panic_mode_reset_via_sharp(root):
    """Ensure pressing # exits panic mode and returns to login prompt."""
    panel = MyControlPanel(master=root, system_callback=lambda *args: None)

    panel.button_star()
    assert panel.status == "panic"

    panel.button_sharp()

    assert panel.status == "login"
    assert panel.button_sequence == ""
