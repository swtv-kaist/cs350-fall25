# test_system_viewLogPage.py
import tkinter as tk
from safehome.web.pages.viewLogPage import ViewLogPage


def test_viewLogPage_system_loop():
    root = tk.Tk()
    root.geometry("600x400")

    logs = [{"id": 1, "dateTime": "2025-12-01 10:00", "description": "Door opened"}]

    def logs_cb():
        return logs

    page = ViewLogPage(root, page_id=0, logs_callback=logs_cb, refresh_interval=200)
    page.drawPage()

    # Schedule closure after 200ms
    root.after(200, root.quit)
    root.mainloop()

    # Ensure table has initial log
    tree_items = page.tree.get_children()
    assert len(tree_items) == 1
    assert page.tree.item(tree_items[0])["values"][2] == "Door opened"
