import tempfile
import shutil
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))

from safehome.cameras.CameraManager import CameraManager
from safehome.cameras.Camera import Camera


class TestCameraManagerSystemWorkflows:
    """System tests for complete camera management workflows"""

    def setup_method(self):
        """Setup persistent storage for system tests"""
        self.temp_dir = tempfile.mkdtemp(prefix="camera_system_test_")

    def teardown_method(self):
        """Cleanup"""
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_complete_camera_lifecycle(self):
        """Test: Create → Save → Load → Modify → Save → Load"""
        # Step 1: Create manager and cameras
        manager1 = CameraManager(storage_dir=self.temp_dir)
        cam1 = Camera(1, [10.0, 20.0], password=None)
        cam2 = Camera(2, [30.0, 40.0], password="initial")
        manager1._cameras = [cam1, cam2]

        # Step 2: Save
        assert manager1.save_cameras() is True

        # Step 3: Load in new manager
        manager2 = CameraManager(storage_dir=self.temp_dir)
        assert len(manager2._cameras) == 2

        # Step 4: Modify camera 2's password
        cam2_loaded = manager2.get_camera_by_id(2, password="initial")
        assert cam2_loaded is not None
        cam2_loaded.set_password("new_password")

        # Step 5: Save modifications
        assert manager2.save_cameras() is True

        # Step 6: Load again and verify
        manager3 = CameraManager(storage_dir=self.temp_dir)
        cam2_final = manager3.get_camera_by_id(2, password="new_password")
        assert cam2_final is not None

    def test_multi_user_scenario(self):
        """Test: Multiple users accessing cameras with different passwords"""
        manager = CameraManager(storage_dir=self.temp_dir)

        # Setup: 3 cameras with different security levels
        cam1 = Camera(1, [10.0, 20.0], password=None)  # Public
        cam2 = Camera(2, [30.0, 40.0], password="user123")  # User protected
        cam3 = Camera(3, [50.0, 60.0], password="admin999")  # Admin protected

        manager._cameras = [cam1, cam2, cam3]
        manager.save_cameras()

        # Reload
        manager = CameraManager(storage_dir=self.temp_dir)

        # User 1: Guest (no passwords)
        guest_cameras = manager.get_all_cameras([None, None, None])
        assert guest_cameras[0] is not None  # Public camera

        # User 2: Regular user
        user_cameras = manager.get_all_cameras([None, "user123", None])
        assert user_cameras[0] is not None
        assert user_cameras[1] is not None  # Has password

        # User 3: Admin
        admin_cameras = manager.get_all_cameras([None, "user123", "admin999"])
        assert all(cam is not None for cam in admin_cameras)  # Full access

    def test_camera_persistence_across_restarts(self):
        """Test: Simulate application restart with camera data persistence"""
        # Session 1: Initial setup
        manager1 = CameraManager(storage_dir=self.temp_dir)
        for i in range(1, 4):
            cam = Camera(i, [float(i * 10), float(i * 20)], password=f"pass{i}")
            cam.enable()
            manager1._cameras.append(cam)
        manager1.save_cameras()
        del manager1

        # Session 2: "Application restart"
        manager2 = CameraManager(storage_dir=self.temp_dir)
        assert len(manager2._cameras) == 3

        # Verify all cameras accessible with correct passwords
        for i in range(1, 4):
            cam = manager2.get_camera_by_id(i, password=f"pass{i}")
            assert cam is not None
            assert cam.get_id() == i

        # Modify one camera
        cam2 = manager2.get_camera_by_id(2, password="pass2")
        cam2.disable()
        manager2.save_cameras()
        del manager2

        # Session 3: Verify modification persisted
        manager3 = CameraManager(storage_dir=self.temp_dir)
        cam2_reloaded = manager3.get_camera_by_id(2, password="pass2")
        assert cam2_reloaded is not None
        assert not cam2_reloaded.is_enabled()

    def test_camera_enable_disable_and_password_lifecycle(self):
        """System test: enable/disable and password changes persist across manager instances."""
        manager1 = CameraManager(storage_dir=self.temp_dir)

        # Create a single disabled camera with no password
        cam = Camera(1, [10.0, 20.0], password=None)
        cam.disable()
        manager1._cameras = [cam]
        assert manager1.save_cameras() is True

        # New manager sees same disabled camera
        manager2 = CameraManager(storage_dir=self.temp_dir)
        cam_loaded = manager2.get_camera_by_id(1)
        assert cam_loaded is not None
        assert not cam_loaded.is_enabled()

        # Enable camera and set password
        cam_loaded.enable()
        cam_loaded.set_password("secret123")
        assert manager2.save_cameras() is True

        # Another manager instance should see enabled camera requiring password
        manager3 = CameraManager(storage_dir=self.temp_dir)
        cam_checked = manager3.get_camera_by_id(1, password="secret123")
        assert cam_checked is not None
        assert cam_checked.is_enabled()
