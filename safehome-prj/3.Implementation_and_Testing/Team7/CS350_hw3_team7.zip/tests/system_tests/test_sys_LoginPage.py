import pytest
import tkinter as tk
from safehome.web.pages.loginPage import LoginPage


@pytest.fixture
def root():
    root = tk.Tk()
    root.withdraw()  # hide the main window
    yield root
    root.destroy()


def test_login_flow(root):
    """System test: simulate user login flow"""
    called = {}

    def system_callback(username, password):
        called["username"] = username
        called["password"] = password
        return username == "admin" and password == "1234"

    def next_page():
        called["next"] = True

    page = LoginPage(root, system_callback=system_callback, next_page_callback=next_page)
    page.drawPage()

    # Simulate user entering credentials
    page.username_entry.insert(0, "admin")
    page.password_entry.insert(0, "1234")

    # Press login button
    page.login_button.invoke()

    assert called.get("username") == "admin"
    assert called.get("password") == "1234"
    assert called.get("next") is True
    assert "Login successful" in page.status_label.cget("text")


def test_login_failure(root):
    """System test: simulate failed login"""
    called = {}

    def system_callback(username, password):
        called["username"] = username
        called["password"] = password
        return False

    page = LoginPage(root, system_callback=system_callback)
    page.drawPage()

    page.username_entry.insert(0, "user")
    page.password_entry.insert(0, "wrongpass")
    page.login_button.invoke()

    assert called.get("username") == "user"
    assert called.get("password") == "wrongpass"
    assert "Incorrect username or password" in page.status_label.cget("text")
