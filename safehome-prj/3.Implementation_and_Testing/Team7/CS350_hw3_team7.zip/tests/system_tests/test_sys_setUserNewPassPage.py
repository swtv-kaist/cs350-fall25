# test_system_setUserNewPassPage.py
import pytest
import tkinter as tk
from safehome.web.pages.setUserNewPassPage import SetUserNewPassPage


@pytest.fixture
def root():
    root = tk.Tk()
    yield root
    root.destroy()


def test_system_new_pass_page_gui_interaction(root):
    """System test: simulate user typing and submitting new password in the GUI."""

    submitted_password = {}

    def submit_cb(new_pw):
        submitted_password["pw"] = new_pw

    page = SetUserNewPassPage(root, submit_callback=submit_cb)

    # Fill fields like a real user
    page.new_pass_entry.insert(0, "mypassword")
    page.confirm_pass_entry.insert(0, "mypassword")

    # Schedule submission after window appears
    root.after(100, page._submit)

    # Run Tkinter mainloop for short time to process events
    root.after(200, root.quit)
    root.mainloop()

    assert submitted_password["pw"] == "mypassword"
