# test_system_userSettingPage.py
import tkinter as tk
from safehome.web.pages.userSettingPage import UserSettingPage


def test_system_user_setting_page_gui():
    root = tk.Tk()
    root.geometry("300x400")
    user_data = {"name": "Charlie", "type": "Guest", "image_path": ""}

    changed_pw = {}

    def change_cb(user, new_pw):
        changed_pw["name"] = user["name"]
        changed_pw["new_pw"] = new_pw

    page = UserSettingPage(
        root,
        user_data_callback=lambda: user_data,
        change_pass_callback=change_cb,
    )
    page.drawPage()

    # Simulate pressing "Change Password"
    root.after(100, page._change_password)

    # Close app after 200ms
    root.after(200, root.quit)
    root.mainloop()

    # The password callback should not have been called yet (no submission)
    assert changed_pw == {}
