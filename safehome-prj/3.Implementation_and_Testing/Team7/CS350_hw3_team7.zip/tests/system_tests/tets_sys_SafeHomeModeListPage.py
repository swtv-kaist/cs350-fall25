import pytest
import tkinter as tk
from safehome.web.pages.safeHomeModeListPage import SafeHomeModeListPage


@pytest.fixture
def root():
    root = tk.Tk()
    root.withdraw()
    yield root
    root.destroy()


def test_system_change_mode(root):
    called = {}

    def on_change_mode(mode_name):
        called["mode"] = mode_name

    page = SafeHomeModeListPage(root, on_change_mode_callback=on_change_mode)

    # Simulate selecting "Overnight Travel"
    page.selected_mode.set("Overnight Travel")
    page._on_change_mode_pressed()

    # Label should update
    assert page.current_mode_label.cget("text") == "Current Mode: Overnight Travel"
    # Callback should be called
    assert called.get("mode") == "Overnight Travel"
