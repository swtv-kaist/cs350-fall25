import pytest
import tkinter as tk
from safehome.web.pages.safeHomeModeAddPage import SafeHomeModeAddPage


@pytest.fixture
def root():
    root = tk.Tk()
    root.withdraw()
    yield root
    root.destroy()


@pytest.fixture
def selected_mode():
    return {"name": "Night Mode", "sensor_ids": ["sensor1"], "sensor_list": []}


def test_system_add_and_cancel(root, selected_mode):
    called = {}

    def add_callback():
        called["added"] = True

    page = SafeHomeModeAddPage(root, selected_mode, add_action_callback=add_callback)
    page.drawPage()

    # Add a sensor via point click
    page.point_click_callback("sensor2")
    assert "sensor2" in page.new_sensor_vars

    # Cancel should close the window
    page._cancel()
    # Toplevel should be destroyed
    assert not page.window.winfo_exists()
