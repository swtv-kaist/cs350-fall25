import shutil
import tempfile
from safehome.sensors.SensorManager import SensorManager
from safehome.sensors.Sensor import Sensor


def test_sensor_manager_integration_full_flow():
    tmp_dir = tempfile.mkdtemp()

    try:
        # initial save
        sensors = [
            Sensor("motion", "motion1", 1, [0, 0, 10, 10], is_armed=True),
            Sensor("door", "door1", 2, [5, 5, 15, 15], is_armed=False),
        ]

        # manually create initial file
        mgr = SensorManager(tmp_dir)
        mgr._sensors = sensors
        assert mgr.save_sensors() is True

        # reload from storage
        mgr2 = SensorManager(tmp_dir)
        loaded = mgr2.getAllSensors()
        assert len(loaded) == 2

        s1 = mgr2.getSensorbyName("motion1")
        s2 = mgr2.getSensorbyName("door1")

        assert s1.isArmed() is True
        assert s2.isArmed() is False

        # test armAllSensors + persist
        mgr2.armAllSensors()
        mgr3 = SensorManager(tmp_dir)
        reloaded_after_arm = mgr3.getAllSensors()
        assert all(s.isArmed() for s in reloaded_after_arm)

        # test disarmAllSensors + persist
        mgr2.disarmAllSensors()
        mgr4 = SensorManager(tmp_dir)
        reloaded_after_disarm = mgr4.getAllSensors()
        assert all(s.isArmed() is False for s in reloaded_after_disarm)

        # test readAllSensors
        reads = mgr4.readAllSensors()
        assert isinstance(reads, list)
        assert len(reads) == 2

    finally:
        shutil.rmtree(tmp_dir)
