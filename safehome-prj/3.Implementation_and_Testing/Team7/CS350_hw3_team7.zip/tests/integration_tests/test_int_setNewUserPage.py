import pytest
import tkinter as tk
from safehome.web.pages.setNewUserPage import SetNewUserPage


@pytest.fixture
def root():
    root = tk.Tk()
    root.withdraw()
    yield root
    root.destroy()


def test_user_flow(root):
    called = {}

    def submit_callback(username, password, user_type, user_image):
        called.update({"username": username, "type": user_type, "image": user_image})

    page = SetNewUserPage(
        root, submit_callback=submit_callback, user_image_callback=lambda: "image.png"
    )

    # Fill fields
    page.username_entry.insert(0, "testuser")
    page.password_entry.insert(0, "1234")
    page.confirm_password_entry.insert(0, "1234")
    page.user_type_var.set("Homeowner")
    page._select_user_image()

    # Submit
    page._submit()
    assert called["username"] == "testuser"
    assert called["type"] == "Homeowner"
    assert called["image"] == "image.png"
