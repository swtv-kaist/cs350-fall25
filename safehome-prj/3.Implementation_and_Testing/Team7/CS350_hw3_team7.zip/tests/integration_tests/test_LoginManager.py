import tempfile
import shutil
import os
import pytest

from safehome.login.LoginManager import LoginManager
from safehome.login.UserEntry import UserEntry


@pytest.fixture
def temp_storage():
    """Create a temporary storage folder for integration tests"""
    tmp_dir = tempfile.mkdtemp()
    yield tmp_dir
    shutil.rmtree(tmp_dir)


@pytest.fixture
def login_manager(temp_storage):
    """Prepare LoginManager with empty temp storage"""
    # Pre-populate a test user in storage
    user = UserEntry(username="alice", password="secret1", type="admin")
    storage_path = os.path.join(temp_storage, "users.json")
    import json

    with open(storage_path, "w") as f:
        json.dump([user.to_dict()], f)

    mgr = LoginManager(storage_dir=temp_storage)
    return mgr


def test_login_logout_change_password_flow(login_manager):
    # Test login success
    success, user = login_manager.login("alice", "secret1")
    assert success is True
    assert user.getUsername() == "alice"

    # Test failed login with wrong password
    failed, _ = login_manager.login("alice", "wrongpass")
    assert failed is False

    # Test change password (success)
    result = login_manager.change_password(user, "newsecret")
    assert result is True
    # Login with old password fails
    failed_old, _ = login_manager.login("alice", "secret1")
    assert failed_old is False
    # Login with new password succeeds
    success_new, _ = login_manager.login("alice", "newsecret")
    assert success_new is True

    # Test logout
    assert login_manager.logout(user) is True
    # Logout again fails
    assert login_manager.logout(user) is False
