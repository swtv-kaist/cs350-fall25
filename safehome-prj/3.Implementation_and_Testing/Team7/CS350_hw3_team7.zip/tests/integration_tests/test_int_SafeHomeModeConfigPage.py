import pytest
import tkinter as tk
from safehome.web.pages.safeHomeModeConfigPage import SafeHomeModeConfigPage


@pytest.fixture
def root():
    root = tk.Tk()
    root.withdraw()
    yield root
    root.destroy()


@pytest.fixture
def selected_mode():
    return {"name": "Night Mode", "sensor_list": ["sensor1"]}


def test_add_action_triggers_add_page(root, selected_mode):
    page = SafeHomeModeConfigPage(root, selected_mode)

    # Patch SafeHomeModeAddPage.drawPage to track call
    called = {}
    from safehome.web.pages.safeHomeModeAddPage import SafeHomeModeAddPage

    original_drawPage = SafeHomeModeAddPage.drawPage

    def fake_drawPage(self):
        called["add_page"] = True

    SafeHomeModeAddPage.drawPage = fake_drawPage

    page._action("add")
    assert called.get("add_page") is True

    # Restore original
    SafeHomeModeAddPage.drawPage = original_drawPage


def test_remove_action_triggers_remove_page(root, selected_mode):
    page = SafeHomeModeConfigPage(root, selected_mode)

    called = {}
    from safehome.web.pages.safeHomeModeRemovePage import SafeHomeModeRemovePage

    original_drawPage = SafeHomeModeRemovePage.drawPage

    def fake_drawPage(self):
        called["remove_page"] = True

    SafeHomeModeRemovePage.drawPage = fake_drawPage

    page._action("remove")
    assert called.get("remove_page") is True

    # Restore original
    SafeHomeModeRemovePage.drawPage = original_drawPage
