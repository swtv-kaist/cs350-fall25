import pytest
import tkinter as tk
from safehome.web.pages.safeHomeModeAddPage import SafeHomeModeAddPage


@pytest.fixture
def root():
    root = tk.Tk()
    root.withdraw()
    yield root
    root.destroy()


@pytest.fixture
def selected_mode():
    return {"name": "Night Mode", "sensor_ids": ["sensor1"], "sensor_list": []}


def test_integration_add_multiple_sensors(root, selected_mode):
    called = {}

    def add_callback():
        called["added"] = True

    page = SafeHomeModeAddPage(root, selected_mode, add_action_callback=add_callback)

    # Click new sensors
    page.point_click_callback("sensor2")
    page.point_click_callback("sensor3")

    # Verify new_sensor_vars updated
    assert "sensor2" in page.new_sensor_vars
    assert "sensor3" in page.new_sensor_vars

    # Add them
    page._add()

    # Verify added to mode
    assert "sensor2" in selected_mode["sensor_list"]
    assert "sensor3" in selected_mode["sensor_list"]
    assert called.get("added") is True
