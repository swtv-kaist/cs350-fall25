import pytest
import tkinter as tk

from safehome.web.pages.homePage import HomePage
from safehome.web.pages.setNewUserPage import SetNewUserPage


@pytest.fixture
def root():
    r = tk.Tk()
    r.withdraw()
    yield r
    r.destroy()


def test_switch_page_callback_invoked(root):
    called = {"value": None}

    def mock_callback(page_id):
        called["value"] = page_id

    page = HomePage(root, switch_page_callback=mock_callback)

    page._switch_page("security")

    assert called["value"] == "security"


def test_add_user_creates_page(root, monkeypatch):
    create_called = {"value": False}

    def mock_draw_page(self):
        create_called["value"] = True

    # Patch drawPage method
    monkeypatch.setattr(SetNewUserPage, "drawPage", mock_draw_page)

    page = HomePage(root)
    page._on_add_user()

    assert create_called["value"] is True
