import pytest
import tkinter as tk
from safehome.web.pages.safeHomeModeListPage import SafeHomeModeListPage


@pytest.fixture
def root():
    root = tk.Tk()
    root.withdraw()
    yield root
    root.destroy()


def test_configure_mode_opens_config_page(root):
    page = SafeHomeModeListPage(root)

    called = {}

    # Patch SafeHomeModeConfigPage.drawPage to track call
    from safehome.web.pages.safeHomeModeConfigPage import SafeHomeModeConfigPage

    original_drawPage = SafeHomeModeConfigPage.drawPage

    def fake_drawPage(self):
        called["config"] = True

    SafeHomeModeConfigPage.drawPage = fake_drawPage

    # Trigger configure for "Away"
    page._on_configure_pressed("Away")
    assert called.get("config") is True

    # Restore original method
    SafeHomeModeConfigPage.drawPage = original_drawPage
