import pytest
import tkinter as tk
from safehome.web.pages.loginPage import LoginPage
from safehome.web.pages.homePage import HomePage


@pytest.fixture
def root():
    root = tk.Tk()
    root.withdraw()  # hide main window
    yield root
    root.destroy()


def test_login_to_homepage_integration(root):
    """Integration test: LoginPage -> HomePage transition using callbacks"""
    called = {}

    # Simulate a simple system validation
    def system_callback(username, password):
        return username == "admin" and password == "1234"

    # This callback simulates switching to HomePage after successful login
    def next_page_callback():
        called["next_page"] = True
        # Instantiate HomePage to simulate real transition
        home = HomePage(root)
        home.drawPage()
        called["home_drawn"] = True

    login_page = LoginPage(
        root, system_callback=system_callback, next_page_callback=next_page_callback
    )
    login_page.drawPage()

    # Enter correct credentials
    login_page.username_entry.insert(0, "admin")
    login_page.password_entry.insert(0, "1234")

    # Press login button
    login_page.login_button.invoke()

    # Assertions
    assert called.get("next_page") is True, "Next page callback was not called"
    assert called.get("home_drawn") is True, "HomePage was not drawn after login"
    assert "Login successful" in login_page.status_label.cget("text")


def test_login_integration_failure(root):
    """Integration test: LoginPage with failed credentials does not proceed to next page"""
    called = {}

    def system_callback(username, password):
        return False

    def next_page_callback():
        called["next_page"] = True

    login_page = LoginPage(
        root, system_callback=system_callback, next_page_callback=next_page_callback
    )
    login_page.drawPage()

    # Enter wrong credentials
    login_page.username_entry.insert(0, "user")
    login_page.password_entry.insert(0, "wrongpass")
    login_page.login_button.invoke()

    assert "Incorrect username or password" in login_page.status_label.cget("text")
    assert (
        called.get("next_page") is None
    ), "Next page callback should not be called on failed login"
