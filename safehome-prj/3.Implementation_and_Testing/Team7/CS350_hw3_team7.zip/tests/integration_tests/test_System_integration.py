import tempfile
import shutil

from safehome.system.System import System
from safehome.sensors.Sensor import Sensor


def test_system_arm_disarm_persists_to_storage():
    """Integration: System + SensorManager + StorageManager using real JSON IO."""
    temp_dir = tempfile.mkdtemp(prefix="system_integration_")

    try:
        system = System(storage_dir=temp_dir)

        # Inject a couple of real Sensor objects into the manager
        s1 = Sensor("motion", "m1", 1, [0, 0, 5, 5])
        s2 = Sensor("door", "d1", 2, [1, 1, 6, 6])

        system._sensor_mng._sensors = [s1, s2]

        # Arm sensors and verify they are armed and persisted
        assert system.armSensors([1, 2]) is True

        # Create a new System instance using the same storage directory
        system2 = System(storage_dir=temp_dir)
        # It should load the sensors from disk
        loaded_sensors = system2._sensor_mng.getAllSensors()
        assert len(loaded_sensors) == 2
        assert all(s.isArmed() for s in loaded_sensors)

        # Disarm using the new instance and verify persistence again
        assert system2.disarmSensors([1, 2]) is True

        system3 = System(storage_dir=temp_dir)
        loaded_sensors2 = system3._sensor_mng.getAllSensors()
        assert len(loaded_sensors2) == 2
        assert all(not s.isArmed() for s in loaded_sensors2)

    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)
