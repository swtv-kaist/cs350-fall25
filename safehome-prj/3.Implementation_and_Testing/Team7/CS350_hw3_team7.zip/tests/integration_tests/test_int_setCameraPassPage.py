# test_integration_setCameraPassPage.py
import pytest
import tkinter as tk

from safehome.web.pages.camera.setCameraPassPage import SetCameraPassPage, cameraManager


class FakeCamera:
    def __init__(self, cam_id):
        self.id = cam_id
        self._password = None

    def set_password(self, pw):
        self._password = pw


@pytest.fixture
def root():
    r = tk.Tk()
    r.withdraw()
    yield r
    r.destroy()


def test_camera_manager_integration(root, monkeypatch):
    cam_info = {"id": "Cam1"}
    fake_cam = FakeCamera("Cam1")
    monkeypatch.setattr(cameraManager, "load_cameras", lambda: None)
    monkeypatch.setattr(cameraManager, "save_cameras", lambda: None)
    monkeypatch.setattr(cameraManager, "get_camera_by_id", lambda cid: fake_cam)

    page = SetCameraPassPage(root, selected_camera=cam_info)
    monkeypatch.setattr(page, "_cancel", lambda: None)

    page.new_pass_entry.insert(0, "pass123")
    page.confirm_pass_entry.insert(0, "pass123")
    page._submit()

    # Integration: CameraManager returned object is updated
    assert fake_cam._password == "pass123"
    assert page.status_label.cget("text") == "Password updated successfully!"
