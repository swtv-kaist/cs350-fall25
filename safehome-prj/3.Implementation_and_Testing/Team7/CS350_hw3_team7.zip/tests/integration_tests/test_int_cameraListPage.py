# test_integration_cameraListPage.py
import tkinter as tk
import pytest
from safehome.web.pages.camera.cameraListPage import CameraListPage


@pytest.fixture
def root():
    root = tk.Tk()
    root.withdraw()
    yield root
    root.destroy()


def test_camera_select_triggers_pages(root, monkeypatch):
    # Mock Camera pages to track calls
    called_pages = []

    class MockSingleCameraPage:
        def __init__(self, root, selected_camera):
            called_pages.append(("single", selected_camera))

        def drawPage(self):
            called_pages.append("single_draw")

    class MockCameraLoginPage:
        def __init__(self, root, selected_camera, switch_page_callback):
            called_pages.append(("login", selected_camera))

        def drawPage(self):
            called_pages.append("login_draw")

    monkeypatch.setattr(
        "safehome.web.pages.camera.cameraListPage.SingleCameraPage", MockSingleCameraPage
    )
    monkeypatch.setattr(
        "safehome.web.pages.camera.cameraListPage.CameraLoginPage", MockCameraLoginPage
    )

    page = CameraListPage(root, page_id=0, switch_page_callback=lambda x: None)
    cam_no_pw = {"id": "Cam1", "hasPassword": False}
    cam_with_pw = {"id": "Cam2", "hasPassword": True}

    # Select cameras
    page._select_camera(cam_no_pw)
    page._select_camera(cam_with_pw)

    assert called_pages[0][0] == "single"
    assert called_pages[1] == "single_draw"
    assert called_pages[2][0] == "login"
    assert called_pages[3] == "login_draw"
