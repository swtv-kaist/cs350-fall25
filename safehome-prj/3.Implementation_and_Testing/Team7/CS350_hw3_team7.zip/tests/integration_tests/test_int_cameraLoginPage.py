# test_integration_cameraLoginPage.py
import tkinter as tk
import pytest
from safehome.web.pages.camera.cameraLoginPage import CameraLoginPage


@pytest.fixture
def root():
    root = tk.Tk()
    root.withdraw()
    yield root
    root.destroy()


def test_empty_password_shows_error(root):
    cam = {"id": "Cam1", "password": "1234"}
    page = CameraLoginPage(root, selected_camera=cam)
    page.password_var.set("")
    page._submit()
    assert page.status_label.cget("text") == "Please enter the password."
