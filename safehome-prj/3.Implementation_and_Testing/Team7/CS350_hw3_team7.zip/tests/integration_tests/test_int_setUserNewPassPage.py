# test_integration_setUserNewPassPage.py
import pytest
import tkinter as tk
from safehome.web.pages.setUserNewPassPage import SetUserNewPassPage


@pytest.fixture
def root():
    root = tk.Tk()
    root.withdraw()
    yield root
    root.destroy()


def test_integration_new_password_submission(root):
    """Simulate system using SetUserNewPassPage to get a new password."""

    system_storage = {"password": "old_pw"}

    def system_update_callback(new_pw):
        # system receives new password
        system_storage["password"] = new_pw

    page = SetUserNewPassPage(root, submit_callback=system_update_callback)
    page._test_mode = True  # prevent destruction

    # User enters new password
    page.new_pass_entry.insert(0, "new_secret")
    page.confirm_pass_entry.insert(0, "new_secret")
    page._submit()

    # The system component should now have the new password
    assert system_storage["password"] == "new_secret"
