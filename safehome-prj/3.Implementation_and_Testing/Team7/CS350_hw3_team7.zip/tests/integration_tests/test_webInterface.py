import tkinter as tk
from unittest.mock import Mock, patch, MagicMock
import sys
import pytest


@pytest.fixture(autouse=True)
def mock_webinterface_dependencies():
    mocked_modules = {
        "safehome.login.LoginManager": MagicMock(),
        "safehome.sensors.SensorManager": MagicMock(),
        "safehome.cameras.CameraManager": MagicMock(),
    }
    with patch.dict(sys.modules, mocked_modules):
        if "safehome.web.webInterface" in sys.modules:
            del sys.modules["safehome.web.webInterface"]
        yield
        if "safehome.web.webInterface" in sys.modules:
            del sys.modules["safehome.web.webInterface"]


def test_webinterface_initialization_and_page_navigation():
    """Test WebInterface initialization and basic page navigation."""
    with (
        patch("safehome.web.webInterface.LoginPage") as MockLogin,
        patch("safehome.web.webInterface.HomePage") as MockHome,
        patch("safehome.web.webInterface.UserSettingPage"),
        patch("safehome.web.webInterface.SecurityPage") as MockSecurity,
        patch("safehome.web.webInterface.CameraListPage"),
        patch("safehome.web.webInterface.ViewLogPage"),
        patch("safehome.web.webInterface.FloorPlanPage"),
        patch("safehome.web.webInterface.SafetyZoneListPage"),
        patch("safehome.web.webInterface.SafeHomeModeListPage"),
        patch("safehome.web.webInterface.ThumbnailViewPage"),
    ):
        # Mock page instances
        for MockPage in [MockLogin, MockHome, MockSecurity]:
            mock_instance = Mock()
            mock_instance.frame = Mock()
            mock_instance.frame.lower = Mock()
            mock_instance.frame.tkraise = Mock()
            mock_instance.drawPage = Mock()
            MockPage.return_value = mock_instance

        from safehome.web.webInterface import WebInterface

        # Initialize interface
        mock_system = Mock()
        interface = WebInterface(system=mock_system)

        try:
            # Verify initialization
            assert interface.system == mock_system
            assert len(interface.pages) == 10
            assert interface.current_page is None
            assert interface.current_user is None
            assert isinstance(interface.root, tk.Tk)
            assert isinstance(interface.container, tk.Frame)

            # Verify all pages exist
            expected_pages = [
                "login",
                "home",
                "user_settings",
                "security",
                "camera",
                "view_log",
                "floor_plan",
                "safety_zone_list",
                "safe_home_mode_list",
                "thumbnail",
            ]
            for page_key in expected_pages:
                assert page_key in interface.pages

            # Test page switching
            result = interface.switchToPage("home")
            assert result is True
            assert interface.current_page == interface.pages["home"]
            interface.pages["home"].frame.tkraise.assert_called()
            interface.pages["home"].drawPage.assert_called()

            # Test navigation to security
            result = interface.switchToPage("security")
            assert result is True
            assert interface.current_page == interface.pages["security"]

            # Test invalid page
            result = interface.switchToPage("invalid_page")
            assert result is False

            # Test login clears user
            interface.pages["login"].clear_entry = Mock()
            interface.current_user = "test_user"
            interface.switchToPage("login")
            assert interface.current_user is None
            interface.pages["login"].clear_entry.assert_called_once()

        finally:
            interface.root.destroy()


def test_webinterface_page_management():
    """Test adding and managing pages."""
    with (
        patch("safehome.web.webInterface.LoginPage"),
        patch("safehome.web.webInterface.HomePage"),
        patch("safehome.web.webInterface.UserSettingPage"),
        patch("safehome.web.webInterface.SecurityPage"),
        patch("safehome.web.webInterface.CameraListPage"),
        patch("safehome.web.webInterface.ViewLogPage"),
        patch("safehome.web.webInterface.FloorPlanPage"),
        patch("safehome.web.webInterface.SafetyZoneListPage"),
        patch("safehome.web.webInterface.SafeHomeModeListPage"),
        patch("safehome.web.webInterface.ThumbnailViewPage"),
    ):
        from safehome.web.webInterface import WebInterface

        interface = WebInterface()

        try:
            initial_count = len(interface.pages)

            # Add new page
            mock_page = Mock()
            mock_page.frame = Mock()
            interface.addPage("test_page", mock_page)

            assert "test_page" in interface.pages
            assert len(interface.pages) == initial_count + 1
            assert interface.pages["test_page"] == mock_page

            # Overwrite existing page
            new_mock_page = Mock()
            new_mock_page.frame = Mock()
            interface.addPage("test_page", new_mock_page)

            assert interface.pages["test_page"] == new_mock_page
            assert len(interface.pages) == initial_count + 1

        finally:
            interface.root.destroy()


def test_webinterface_draw_page():
    """Test drawPage functionality."""
    with (
        patch("safehome.web.webInterface.LoginPage"),
        patch("safehome.web.webInterface.HomePage"),
        patch("safehome.web.webInterface.UserSettingPage"),
        patch("safehome.web.webInterface.SecurityPage"),
        patch("safehome.web.webInterface.CameraListPage"),
        patch("safehome.web.webInterface.ViewLogPage"),
        patch("safehome.web.webInterface.FloorPlanPage"),
        patch("safehome.web.webInterface.SafetyZoneListPage"),
        patch("safehome.web.webInterface.SafeHomeModeListPage"),
        patch("safehome.web.webInterface.ThumbnailViewPage"),
    ):
        from safehome.web.webInterface import WebInterface

        interface = WebInterface()

        try:
            # Add test page with numeric key
            mock_page = Mock()
            mock_page.frame = Mock()
            mock_page.drawPage = Mock()
            interface.addPage("99", mock_page)

            # Test drawPage with valid number
            result = interface.drawPage([99])
            assert result is True
            assert interface.current_page == mock_page
            mock_page.drawPage.assert_called_once()

            # Test drawPage with empty list
            result = interface.drawPage([])
            assert result is False

            # Test drawPage with invalid number
            result = interface.drawPage([999])
            assert result is False

        finally:
            interface.root.destroy()


def test_webinterface_login_logout_flow():
    """Test complete login/logout workflow."""
    with (
        patch("safehome.web.webInterface.LoginPage") as MockLogin,
        patch("safehome.web.webInterface.HomePage") as MockHome,
        patch("safehome.web.webInterface.UserSettingPage"),
        patch("safehome.web.webInterface.SecurityPage"),
        patch("safehome.web.webInterface.CameraListPage"),
        patch("safehome.web.webInterface.ViewLogPage"),
        patch("safehome.web.webInterface.FloorPlanPage"),
        patch("safehome.web.webInterface.SafetyZoneListPage"),
        patch("safehome.web.webInterface.SafeHomeModeListPage"),
        patch("safehome.web.webInterface.ThumbnailViewPage"),
    ):
        # Mock page instances
        mock_login = Mock()
        mock_login.frame = Mock()
        mock_login.frame.lower = Mock()
        mock_login.frame.tkraise = Mock()
        mock_login.drawPage = Mock()
        mock_login.clear_entry = Mock()
        MockLogin.return_value = mock_login

        mock_home = Mock()
        mock_home.frame = Mock()
        mock_home.frame.lower = Mock()
        mock_home.frame.tkraise = Mock()
        mock_home.drawPage = Mock()
        MockHome.return_value = mock_home

        from safehome.web.webInterface import WebInterface

        interface = WebInterface()

        try:
            # Simulate login
            interface.current_user = "test_user"
            interface.switchToPage("home")
            assert interface.current_user == "test_user"

            # Simulate logout
            interface.switchToPage("login")
            assert interface.current_user is None
            mock_login.clear_entry.assert_called_once()

            # Verify user persists across non-login pages
            interface.current_user = "test_user"
            interface.switchToPage("home")
            assert interface.current_user == "test_user"

        finally:
            interface.root.destroy()


def test_device_info_function():
    """Test device_info helper function."""
    with (
        patch("safehome.web.webInterface.sensorManager") as mock_sensor_mgr,
        patch("safehome.web.webInterface.cameraManager") as mock_camera_mgr,
    ):
        mock_sensor_mgr.getSensorbyName = Mock(return_value={"name": "sensor1", "type": "motion"})
        mock_camera_mgr.get_camera_by_id = Mock(return_value={"id": 1, "name": "camera1"})

        from safehome.web.webInterface import device_info

        # Test camera device
        result = device_info("camera1")
        mock_camera_mgr.get_camera_by_id.assert_called_once_with(1)
        assert result == {"id": 1, "name": "camera1"}

        # Test sensor device
        result = device_info("motionSensor1")
        mock_sensor_mgr.getSensorbyName.assert_called_once_with("motionSensor1")
        assert result == {"name": "sensor1", "type": "motion"}

        # Test camera with high ID
        mock_camera_mgr.get_camera_by_id.return_value = {"id": 25, "name": "camera25"}
        result = device_info("camera25")
        mock_camera_mgr.get_camera_by_id.assert_called_with(25)
        assert result == {"id": 25, "name": "camera25"}


def test_webinterface_multiple_page_navigation():
    """Test navigating through multiple pages."""
    with (
        patch("safehome.web.webInterface.LoginPage"),
        patch("safehome.web.webInterface.HomePage") as MockHome,
        patch("safehome.web.webInterface.UserSettingPage"),
        patch("safehome.web.webInterface.SecurityPage") as MockSecurity,
        patch("safehome.web.webInterface.CameraListPage") as MockCamera,
        patch("safehome.web.webInterface.ViewLogPage"),
        patch("safehome.web.webInterface.FloorPlanPage"),
        patch("safehome.web.webInterface.SafetyZoneListPage"),
        patch("safehome.web.webInterface.SafeHomeModeListPage"),
        patch("safehome.web.webInterface.ThumbnailViewPage"),
    ):
        # Mock all page instances
        for MockPage in [MockHome, MockSecurity, MockCamera]:
            mock_instance = Mock()
            mock_instance.frame = Mock()
            mock_instance.frame.lower = Mock()
            mock_instance.frame.tkraise = Mock()
            mock_instance.drawPage = Mock()
            MockPage.return_value = mock_instance

        from safehome.web.webInterface import WebInterface

        interface = WebInterface()

        try:
            # Navigate through multiple pages
            pages_to_visit = ["home", "security", "camera", "home"]

            for page_key in pages_to_visit:
                result = interface.switchToPage(page_key)
                assert result is True
                assert interface.current_page == interface.pages[page_key]
                interface.pages[page_key].frame.tkraise.assert_called()
                interface.pages[page_key].drawPage.assert_called()

            # Verify all pages had lower() called multiple times
            for page in interface.pages.values():
                assert page.frame.lower.call_count >= len(pages_to_visit)

        finally:
            interface.root.destroy()


def test_webinterface_run_method():
    """Test the run method."""
    with (
        patch("safehome.web.webInterface.LoginPage"),
        patch("safehome.web.webInterface.HomePage"),
        patch("safehome.web.webInterface.UserSettingPage"),
        patch("safehome.web.webInterface.SecurityPage"),
        patch("safehome.web.webInterface.CameraListPage"),
        patch("safehome.web.webInterface.ViewLogPage"),
        patch("safehome.web.webInterface.FloorPlanPage") as MockFloorPlan,
        patch("safehome.web.webInterface.SafetyZoneListPage"),
        patch("safehome.web.webInterface.SafeHomeModeListPage"),
        patch("safehome.web.webInterface.ThumbnailViewPage"),
    ):
        # Mock floor plan page
        mock_floor_plan = Mock()
        mock_floor_plan.frame = Mock()
        mock_floor_plan.frame.lower = Mock()
        mock_floor_plan.frame.tkraise = Mock()
        mock_floor_plan.drawPage = Mock()
        MockFloorPlan.return_value = mock_floor_plan

        from safehome.web.webInterface import WebInterface

        interface = WebInterface()

        try:
            # Mock mainloop to prevent blocking
            interface.root.mainloop = Mock()

            interface.run()

            # Verify it switched to login page before entering mainloop
            assert interface.current_page == interface.pages["login"]
            interface.pages["login"].drawPage.assert_called()
            assert not mock_floor_plan.frame.tkraise.called
            assert not mock_floor_plan.drawPage.called
            interface.root.mainloop.assert_called_once()

        finally:
            interface.root.destroy()


def test_webinterface_with_without_system():
    """Test WebInterface with and without system object."""
    with (
        patch("safehome.web.webInterface.LoginPage"),
        patch("safehome.web.webInterface.HomePage"),
        patch("safehome.web.webInterface.UserSettingPage"),
        patch("safehome.web.webInterface.SecurityPage"),
        patch("safehome.web.webInterface.CameraListPage"),
        patch("safehome.web.webInterface.ViewLogPage"),
        patch("safehome.web.webInterface.FloorPlanPage"),
        patch("safehome.web.webInterface.SafetyZoneListPage"),
        patch("safehome.web.webInterface.SafeHomeModeListPage"),
        patch("safehome.web.webInterface.ThumbnailViewPage"),
    ):
        from safehome.web.webInterface import WebInterface

        # Test with system
        mock_system = Mock()
        interface1 = WebInterface(system=mock_system)
        try:
            assert interface1.system == mock_system
            assert interface1.system is not None
        finally:
            interface1.root.destroy()

        # Test without system
        interface2 = WebInterface()
        try:
            assert interface2.system is None
        finally:
            interface2.root.destroy()
