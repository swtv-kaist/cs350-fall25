# test_log_manager.py
import pytest
import shutil
from safehome.log.Log import Log
from safehome.log.LogManager import LogManager
from pathlib import Path

TEMP_DIR = "TempStorage"


@pytest.fixture
def cleanup_temp_dir():
    """Cleanup temporary storage before and after tests."""
    if Path(TEMP_DIR).exists():
        shutil.rmtree(TEMP_DIR)
    yield
    if Path(TEMP_DIR).exists():
        shutil.rmtree(TEMP_DIR)


@pytest.fixture
def log_manager(cleanup_temp_dir):
    return LogManager(storage_dir=TEMP_DIR)


@pytest.fixture
def sample_log():
    return Log(log_id=1, datetime="2025-11-30 16:00:00", description="Test log")


def test_save_and_get_log(log_manager, sample_log):
    # Save log
    assert log_manager.saveLog(sample_log) is True

    # Retrieve logs
    logs = log_manager.getLogList()
    assert len(logs) == 1
    log = logs[0]
    assert log.getID() == 1
    assert log.getDateTime() == "2025-11-30 16:00:00"
    assert log.getDescription() == "Test log"


def test_find_log(log_manager, sample_log):
    log_manager.saveLog(sample_log)
    found = log_manager.findLog(1)
    assert found is not None
    assert found.getID() == 1

    not_found = log_manager.findLog(999)
    assert not_found is None


def test_delete_log(log_manager, sample_log):
    log_manager.saveLog(sample_log)
    # Delete existing log
    assert log_manager.deleteLog(1) is True
    assert len(log_manager.getLogList()) == 0

    # Delete non-existing log
    assert log_manager.deleteLog(999) is False
