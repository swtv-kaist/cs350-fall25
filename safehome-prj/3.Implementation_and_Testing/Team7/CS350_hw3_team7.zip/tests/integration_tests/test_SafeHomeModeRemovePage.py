import pytest
import tkinter as tk
from safehome.web.pages.safeHomeModeRemovePage import SafeHomeModeRemovePage


@pytest.fixture
def root():
    root = tk.Tk()
    root.withdraw()
    yield root
    root.destroy()


@pytest.fixture
def selected_mode():
    return {"name": "Night Mode", "sensor_list": ["sensor1", "sensor2"]}


def test_remove_action_updates_selected_mode(root, selected_mode):
    called = {}

    def remove_callback():
        called["done"] = True

    page = SafeHomeModeRemovePage(root, selected_mode, remove_action_callback=remove_callback)

    # Select first sensor
    first_sensor = list(page.sensor_vars.keys())[0]
    page.sensor_vars[first_sensor].set(1)

    page._remove()

    # The first sensor should be removed
    assert first_sensor not in selected_mode["sensor_list"]
    # Callback should be called
    assert called.get("done") is True
