import os
import json
import shutil
import tempfile

from safehome.storage.StorageManager import StorageManager


def test_storage_manager_integrated_read_write():
    tmp = tempfile.mkdtemp()

    try:
        sm = StorageManager(tmp)
        data = {"a": 123, "b": "xyz"}

        # save
        ok = sm.save_json("testfile", data)
        assert ok is True

        # verify file exists
        filepath = os.path.join(tmp, "testfile.json")
        assert os.path.exists(filepath)

        # verify actual file content
        with open(filepath, "r", encoding="utf-8") as f:
            raw = json.load(f)
        assert raw == data

        # load using real method
        loaded = sm.load_json("testfile")
        assert loaded == data

    finally:
        shutil.rmtree(tmp)


def test_storage_manager_read_missing_file():
    tmp = tempfile.mkdtemp()

    try:
        sm = StorageManager(tmp)
        assert sm.load_json("does_not_exist") is None
    finally:
        shutil.rmtree(tmp)
