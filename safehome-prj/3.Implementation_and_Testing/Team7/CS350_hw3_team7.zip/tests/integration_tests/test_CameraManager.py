import tempfile
import shutil
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))

from safehome.cameras.CameraManager import CameraManager
from safehome.cameras.Camera import Camera


class TestCameraManagerIntegrationLoadSave:
    """Integration tests for loading and saving cameras"""

    def setup_method(self):
        """Create temporary storage directory for each test"""
        self.temp_dir = tempfile.mkdtemp(prefix="camera_test_")
        self.storage_dir = self.temp_dir

    def teardown_method(self):
        """Clean up temporary directory"""
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_load_cameras_from_empty_storage(self):
        """Test loading when storage file doesn't exist"""
        manager = CameraManager(storage_dir=self.storage_dir)

        assert manager._cameras == []

    def test_save_and_load_cameras_roundtrip(self):
        """Test saving cameras and loading them back"""
        # Create manager and add cameras
        manager1 = CameraManager(storage_dir=self.storage_dir)

        cam1 = Camera(camera_id=1, location=[10.0, 20.0], password=None)
        cam2 = Camera(camera_id=2, location=[30.0, 40.0], password="secret")
        cam3 = Camera(camera_id=3, location=[50.0, 60.0], password=None)

        manager1._cameras = [cam1, cam2, cam3]

        # Save
        result = manager1.save_cameras()
        assert result is True

        # Create new manager and load
        manager2 = CameraManager(storage_dir=self.storage_dir)

        assert len(manager2._cameras) == 3
        assert manager2._cameras[0].get_id() == 1
        assert manager2._cameras[1].get_id() == 2
        assert manager2._cameras[2].get_id() == 3

    def test_save_preserves_camera_properties(self):
        """Test that saving preserves all camera properties"""
        manager1 = CameraManager(storage_dir=self.storage_dir)

        cam = Camera(camera_id=1, location=[100.0, 200.0], password="test123")
        cam.enable()
        manager1._cameras = [cam]
        manager1.save_cameras()

        # Reload
        manager2 = CameraManager(storage_dir=self.storage_dir)
        loaded_cam = manager2.get_camera_by_id(1, password="test123")

        assert loaded_cam is not None
        assert loaded_cam.get_id() == 1
        assert loaded_cam.get_location() == [100.0, 200.0]
        assert loaded_cam.verify_password("test123")


class TestCameraManagerIntegrationCameraAccess:
    """Integration tests for camera access methods"""

    def setup_method(self):
        """Setup for each test"""
        self.temp_dir = tempfile.mkdtemp(prefix="camera_test_")
        self.manager = CameraManager(storage_dir=self.temp_dir)

        # Add test cameras
        self.cam1 = Camera(1, [10.0, 20.0], password=None)
        self.cam2 = Camera(2, [30.0, 40.0], password="pass2")
        self.cam3 = Camera(3, [50.0, 60.0], password="pass3")

        self.manager._cameras = [self.cam1, self.cam2, self.cam3]

    def teardown_method(self):
        """Cleanup"""
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_get_camera_by_id_integration(self):
        """Test getting camera by ID with real Camera objects"""
        cam = self.manager.get_camera_by_id(1)
        assert cam is not None
        assert cam.get_id() == 1

    def test_get_camera_with_password_integration(self):
        """Test password verification with real Camera objects"""
        # Correct password
        cam = self.manager.get_camera_by_id(2, password="pass2")
        assert cam is not None

    def test_get_all_cameras_integration(self):
        """Test getting all cameras with mixed passwords"""
        passwords = [None, "pass2", "pass3"]
        cameras = self.manager.get_all_cameras(passwords)

        assert len(cameras) == 3
        assert cameras[0] is not None
        assert cameras[1] is not None
        assert cameras[2] is not None

        # Test with wrong password
        passwords = [None, "wrong", "pass3"]
        cameras = self.manager.get_all_cameras(passwords)

        assert cameras[0] is not None
        assert cameras[2] is not None
