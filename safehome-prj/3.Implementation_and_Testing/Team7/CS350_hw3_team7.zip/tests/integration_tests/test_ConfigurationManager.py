import tempfile
import shutil
from pathlib import Path
import sys
import os

sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))
os.environ["SAFEHOME_HEADLESS"] = "1"  # Disable GUI

from safehome.config.ConfigurationManager import ConfigurationManager
from safehome.config.SystemSettings import SystemSettings
from safehome.config.SafetyZone import SafetyZone
from safehome.config.SafeHomeMode import SafeHomeMode
from safehome.sensors.Sensor import Sensor


class TestConfigurationManagerIntegrationSystemSettings:
    """Integration tests for system settings with real storage"""

    def setup_method(self):
        """Create temporary storage for each test"""
        self.temp_dir = tempfile.mkdtemp(prefix="config_test_")

    def teardown_method(self):
        """Clean up"""
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_system_settings_default_values(self):
        """Test that default system settings are created correctly"""
        manager = ConfigurationManager(storage_dir=self.temp_dir)
        settings = manager.getSystemSettings()

        assert settings.getSystemLockTime() == 0
        assert settings.getPanicPhoneNumber() == ""
        assert settings.getAlarmTimeBeforePhoneCall() == 0
        assert settings.getHomePhoneNumber() == ""

    def test_system_settings_save_and_load_roundtrip(self):
        """Test saving and loading system settings"""
        # Create and save
        manager1 = ConfigurationManager(storage_dir=self.temp_dir)
        settings = SystemSettings(
            systemLockTime=30,
            panicPhoneNumber="911",
            alarmTimeBeforePhoneCall=60,
            homePhoneNumber="555-1234",
        )
        result = manager1.updateSystemSettings(settings)
        assert result is True

        # Load in new instance
        manager2 = ConfigurationManager(storage_dir=self.temp_dir)
        loaded_settings = manager2.getSystemSettings()

        assert loaded_settings.getSystemLockTime() == 30
        assert loaded_settings.getPanicPhoneNumber() == "911"
        assert loaded_settings.getAlarmTimeBeforePhoneCall() == 60
        assert loaded_settings.getHomePhoneNumber() == "555-1234"

    def test_system_settings_update_overwrites(self):
        """Test that updating settings overwrites previous values"""
        manager = ConfigurationManager(storage_dir=self.temp_dir)

        # Initial settings
        settings1 = SystemSettings(systemLockTime=30, panicPhoneNumber="111")
        manager.updateSystemSettings(settings1)

        # Update settings
        settings2 = SystemSettings(systemLockTime=60, panicPhoneNumber="999")
        manager.updateSystemSettings(settings2)

        # Reload and verify
        manager2 = ConfigurationManager(storage_dir=self.temp_dir)
        loaded = manager2.getSystemSettings()
        assert loaded.getSystemLockTime() == 60
        assert loaded.getPanicPhoneNumber() == "999"


class TestConfigurationManagerIntegrationSafetyZones:
    """Integration tests for safety zones with real sensors"""

    def setup_method(self):
        """Setup for each test"""
        self.temp_dir = tempfile.mkdtemp(prefix="config_test_")
        SafetyZone._zone_id_counter = 0

    def teardown_method(self):
        """Cleanup"""
        shutil.rmtree(self.temp_dir, ignore_errors=True)
        SafetyZone._zone_id_counter = 0

    def test_safety_zone_with_sensors_save_and_load(self):
        """Test saving and loading zones with real sensor objects"""
        manager1 = ConfigurationManager(storage_dir=self.temp_dir)

        # Create sensors
        sensor1 = Sensor("motion", "motionSensor1", 1, [10, 20, 10, 20])
        sensor2 = Sensor("door", "doorSensor1", 2, [30, 40, 30, 40])

        # Create zone with sensors
        zone = SafetyZone(name="LivingRoom", sensor_list=[sensor1, sensor2])
        manager1.addSafetyZone(zone)

        # Reload
        manager2 = ConfigurationManager(storage_dir=self.temp_dir)
        zones = manager2.getAllSafetyZones()

        assert len(zones) == 1
        loaded_zone = zones[0]
        assert loaded_zone.get_name() == "LivingRoom"

        # Verify sensors were restored
        sensors = loaded_zone.get_sensor_list()
        assert len(sensors) == 2
        assert sensors[0].get_type() == "motion"
        assert sensors[0].get_name() == "motionSensor1"
        assert sensors[1].get_type() == "door"

    def test_safety_zone_arm_status_persistence(self):
        """Test that zone arm status persists correctly"""
        manager1 = ConfigurationManager(storage_dir=self.temp_dir)

        sensor = Sensor("motion", "sensor1", 1, [10, 20, 10, 20])
        zone = SafetyZone(name="TestZone", sensor_list=[sensor], arm_status=False)
        manager1.addSafetyZone(zone)

        # Arm the zone
        zone.armSafetyZone()
        manager1.save_safety_zones()

        # Reload and verify armed status
        manager2 = ConfigurationManager(storage_dir=self.temp_dir)
        loaded_zone = manager2.getSafetyZoneByName("TestZone")

        assert loaded_zone.is_armed() is True
        # Verify sensors are also armed
        sensors = loaded_zone.get_sensor_list()
        assert sensors[0].isArmed() is True

    def test_multiple_zones_with_different_sensors(self):
        """Test multiple zones each with different sensors"""
        manager = ConfigurationManager(storage_dir=self.temp_dir)

        # Zone 1: Motion sensors
        motion1 = Sensor("motion", "motion1", 1, [10, 10, 0, 1])
        motion2 = Sensor("motion", "motion2", 2, [20, 20, 0, 1])
        zone1 = SafetyZone(name="Zone1", sensor_list=[motion1, motion2])

        # Zone 2: Door/Window sensors
        door1 = Sensor("door", "door1", 3, [30, 30, 0, 2])
        window1 = Sensor("window", "window1", 4, [40, 40, 5, 2])
        zone2 = SafetyZone(name="Zone2", sensor_list=[door1, window1])

        manager.addSafetyZone(zone1)
        manager.addSafetyZone(zone2)

        # Reload
        manager2 = ConfigurationManager(storage_dir=self.temp_dir)
        zones = manager2.getAllSafetyZones()

        assert len(zones) == 2

        # Verify Zone1
        z1 = manager2.getSafetyZoneByName("Zone1")
        assert len(z1.get_sensor_list()) == 2
        assert all(s.get_type() == "motion" for s in z1.get_sensor_list())

        # Verify Zone2
        z2 = manager2.getSafetyZoneByName("Zone2")
        assert len(z2.get_sensor_list()) == 2
        types = [s.get_type() for s in z2.get_sensor_list()]
        assert "door" in types
        assert "window" in types

    def test_delete_zone_persists(self):
        """Test that deleting a zone persists"""
        manager1 = ConfigurationManager(storage_dir=self.temp_dir)

        zone1 = SafetyZone(name="Zone1", sensor_list=[])
        zone2 = SafetyZone(name="Zone2", sensor_list=[])
        manager1.addSafetyZone(zone1)
        manager1.addSafetyZone(zone2)

        # Delete zone1
        result = manager1.deleteSafetyZone("Zone1")
        assert result is True

        # Reload and verify
        manager2 = ConfigurationManager(storage_dir=self.temp_dir)
        zones = manager2.getAllSafetyZones()

        assert len(zones) == 1
        assert zones[0].get_name() == "Zone2"


class TestConfigurationManagerIntegrationSafeHomeModes:
    """Integration tests for SafeHome modes with real sensors"""

    def setup_method(self):
        """Setup"""
        self.temp_dir = tempfile.mkdtemp(prefix="config_test_")
        SafeHomeMode._mode_id_counter = 0

    def teardown_method(self):
        """Cleanup"""
        shutil.rmtree(self.temp_dir, ignore_errors=True)
        SafeHomeMode._mode_id_counter = 0

    def test_safehome_mode_with_sensors_save_and_load(self):
        """Test saving and loading modes with real sensors"""
        manager1 = ConfigurationManager(storage_dir=self.temp_dir)

        # Create sensors
        sensor1 = Sensor("motion", "motion1", 1, [10, 20, 10, 20])
        sensor2 = Sensor("door", "door1", 2, [30, 40, 30, 40])
        sensor3 = Sensor("window", "window1", 3, [50, 60, 50, 60])

        # Create mode with sensors
        mode = SafeHomeMode(name="AwayMode", sensor_list=[sensor1, sensor2, sensor3])
        manager1.addSafeHomeMode(mode)

        # Reload
        manager2 = ConfigurationManager(storage_dir=self.temp_dir)
        modes = manager2.getAllSafeHomeModes()

        assert len(modes) == 1
        loaded_mode = modes[0]
        assert loaded_mode.get_name() == "AwayMode"

        # Verify sensors
        sensors = loaded_mode.get_sensor_list()
        assert len(sensors) == 3
        assert sensors[0].get_type() == "motion"
        assert sensors[1].get_type() == "door"
        assert sensors[2].get_type() == "window"

    def test_multiple_modes_with_overlapping_sensors(self):
        """Test multiple modes that share some sensors"""
        manager = ConfigurationManager(storage_dir=self.temp_dir)

        sensor1 = Sensor("motion", "motion1", 1, [10, 10, 0, 1])
        sensor2 = Sensor("door", "door1", 2, [20, 20, 0, 1])
        sensor3 = Sensor("window", "window1", 3, [30, 30, 5, 1])

        # Away mode: all sensors
        away_mode = SafeHomeMode(name="Away", sensor_list=[sensor1, sensor2, sensor3])

        # Night mode: only motion and door
        night_mode = SafeHomeMode(name="Night", sensor_list=[sensor1, sensor2])

        # Home mode: only motion
        home_mode = SafeHomeMode(name="Home", sensor_list=[sensor1])

        manager.addSafeHomeMode(away_mode)
        manager.addSafeHomeMode(night_mode)
        manager.addSafeHomeMode(home_mode)

        # Reload
        manager2 = ConfigurationManager(storage_dir=self.temp_dir)

        away = manager2.getSafeHomeModeByName("Away")
        assert len(away.get_sensor_list()) == 3

        night = manager2.getSafeHomeModeByName("Night")
        assert len(night.get_sensor_list()) == 2

        home = manager2.getSafeHomeModeByName("Home")
        assert len(home.get_sensor_list()) == 1

    def test_mode_id_counter_persistence(self):
        """Test that mode ID counter is properly restored"""
        manager1 = ConfigurationManager(storage_dir=self.temp_dir)

        mode1 = SafeHomeMode(name="Mode1", sensor_list=[])
        mode2 = SafeHomeMode(name="Mode2", sensor_list=[])
        manager1.addSafeHomeMode(mode1)
        manager1.addSafeHomeMode(mode2)

        assert mode1.get_id() == 1
        assert mode2.get_id() == 2

        # Reload
        manager2 = ConfigurationManager(storage_dir=self.temp_dir)
        modes = manager2.getAllSafeHomeModes()

        # IDs should be preserved
        assert modes[0].get_id() == 1
        assert modes[1].get_id() == 2
