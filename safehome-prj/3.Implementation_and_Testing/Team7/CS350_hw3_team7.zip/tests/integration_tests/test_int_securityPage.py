import pytest
import tkinter as tk
from safehome.web.pages.securityPage import SecurityPage


@pytest.fixture
def root():
    root = tk.Tk()
    root.withdraw()
    yield root
    root.destroy()


def test_button_clicks(root):
    called = {}

    def switch_page_callback(pid):
        called["pid"] = pid

    page = SecurityPage(root, switch_page_callback=switch_page_callback)

    # Simulate clicking each button
    for btn, expected_pid in zip(
        [w for w in page.frame.winfo_children()[0].winfo_children() if isinstance(w, tk.Button)],
        ["floor_plan", "safety_zone_list", "safe_home_mode_list"],
    ):
        btn.invoke()
        assert called["pid"] == expected_pid
