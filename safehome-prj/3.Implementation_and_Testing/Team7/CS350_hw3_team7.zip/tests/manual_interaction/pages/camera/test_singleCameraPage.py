import tkinter as tk
import sys
import os

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../.."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.safehome.web.pages.camera.singleCameraPage import SingleCameraPage  # adjust import path


def switch_page_callback():
    print("Return button pressed - switch page callback called")


def camera_action_callback(camera, action):
    print(f"Camera {camera.get('id')} action: {action}")


def get_view_callback(camera):
    # Example: display static image
    image = camera.get("image_path")
    if image:
        from PIL import Image

        pil_image = Image.open(image).resize((400, 300))

    return pil_image


if __name__ == "__main__":
    root = tk.Tk()
    root.title("Single Camera Page Test")
    root.geometry("100x200")

    # Dummy camera info
    camera_info = {
        "id": 101,
        "location": [12.5, 7.8],
        "enabled": True,
        "hasPassword": True,
        "password": "secret",
        "image_path": os.path.join(
            PROJECT_ROOT, "src/safehome/virtual_device_v3/camera1.jpg"
        ),  # use a valid local image path
    }

    page = SingleCameraPage(
        root=root,
        switch_page_callback=switch_page_callback,
        camera_action_callback=camera_action_callback,
        selected_camera=camera_info,
        get_view_callback=get_view_callback,
    )

    page.drawPage()  # Show the page

    root.mainloop()
