import tkinter as tk
import sys
import os

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../.."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.safehome.web.pages.camera.cameraLoginPage import CameraLoginPage  # adjust import path

fake_camera_list = [
    {"id": 1, "name": "Front Door", "password": "abcd"},
    {"id": 2, "name": "Backyard", "password": "1234"},
]


def on_camera_auth(password, camera):
    print(f"Authenticating camera {camera['name']} with password: {password}")
    if password == camera["password"]:
        print("Authentication successful")
        return True
    else:
        print("Authentication failed")
        return False


def on_switch_page(camera):
    print(f"Switching to camera page for: {camera['name']}")


if __name__ == "__main__":
    root = tk.Tk()
    root.title("Camera List Test")

    page = CameraLoginPage(
        root,
        switch_page_callback=on_switch_page,
        camera_auth_callback=on_camera_auth,
        selected_camera=fake_camera_list[0],
    )

    page.drawPage()
    root.mainloop()
