import tkinter as tk
import sys
import os

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../.."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.safehome.web.pages.camera.cameraListPage import CameraListPage  # adjust import path


def fake_camera_list_callback():
    return [
        {
            "id": 1,
            "location": [12.5, 7.8],
            "enabled": True,
            "hasPassword": False,
            "password": "secret",
            "image_path": os.path.join(
                PROJECT_ROOT, "src/safehome/virtual_device_v3/camera1.jpg"
            ),  # use a valid local image path
        },
        {
            "id": 2,
            "location": [12.5, 7.8],
            "enabled": True,
            "hasPassword": True,
            "password": "secret",
            "image_path": os.path.join(
                PROJECT_ROOT, "src/safehome/virtual_device_v3/camera1.jpg"
            ),  # use a valid local image path
        },
        {
            "id": 3,
            "location": [12.5, 7.8],
            "enabled": False,
            "hasPassword": True,
            "password": "secret",
            "image_path": os.path.join(
                PROJECT_ROOT, "src/safehome/virtual_device_v3/camera1.jpg"
            ),  # use a valid local image path
        },
        {
            "id": 4,
            "location": [12.5, 7.8],
            "enabled": True,
            "hasPassword": False,
            "password": "",
            "image_path": os.path.join(
                PROJECT_ROOT, "src/safehome/virtual_device_v3/camera2.jpg"
            ),  # use a valid local image path
        },
    ]


def on_camera_select(camera, action):
    print("Selected camera:", camera)


def on_add_camera():
    print("Adding a new camera")


def on_view_thumbnail():
    print("Switching to thumbnail view")


if __name__ == "__main__":
    root = tk.Tk()
    root.title("Camera List Test")

    page = CameraListPage(
        root,
        camera_list_callback=fake_camera_list_callback,
        camera_add_callback=on_add_camera,
        view_as_thumbnail_callback=on_view_thumbnail,
        prev_page=None,  # or another page instance
    )

    page.drawPage()
    root.mainloop()
