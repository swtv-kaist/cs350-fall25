import tkinter as tk
import sys
import os

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../.."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.safehome.web.pages.camera.thumbnailViewPage import ThumbnailViewPage  # adjust import path


def fake_camera_list_callback():
    return [
        {
            "id": 1,
            "location": [12.5, 7.8],
            "enabled": True,
            "hasPassword": False,
            "password": "secret",
            "image_path": os.path.join(
                PROJECT_ROOT, "src/safehome/virtual_device_v3/camera1.jpg"
            ),  # use a valid local image path
        },
        {
            "id": 2,
            "location": [12.5, 7.8],
            "enabled": True,
            "hasPassword": True,
            "password": "secret",
            "image_path": os.path.join(
                PROJECT_ROOT, "src/safehome/virtual_device_v3/camera1.jpg"
            ),  # use a valid local image path
        },
        {
            "id": 3,
            "location": [12.5, 7.8],
            "enabled": False,
            "hasPassword": True,
            "password": "secret",
            "image_path": os.path.join(
                PROJECT_ROOT, "src/safehome/virtual_device_v3/camera1.jpg"
            ),  # use a valid local image path
        },
        {
            "id": 4,
            "location": [12.5, 7.8],
            "enabled": True,
            "hasPassword": False,
            "password": "",
            "image_path": os.path.join(
                PROJECT_ROOT, "src/safehome/virtual_device_v3/camera2.jpg"
            ),  # use a valid local image path
        },
    ]


def switch_page_callback(camera):
    print(f"Access camera: {camera.get('id')} - switch page callback called")


def get_view_callback(camera):
    # Example: display static image
    image = camera.get("image_path")
    if image:
        from PIL import Image

        pil_image = Image.open(image).resize((400, 300))

    return pil_image


if __name__ == "__main__":
    root = tk.Tk()
    root.title("Thumbnail Camera Page Test")
    root.geometry("800x700")

    page = ThumbnailViewPage(
        root=root,
        page_id=1,
        camera_list_callback=fake_camera_list_callback,
        switch_page_callback=switch_page_callback,
        get_view_callback=get_view_callback,
    )

    page.drawPage()  # Show the page

    root.mainloop()
