import tkinter as tk
import sys
import os
import random
from datetime import datetime

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.safehome.web.pages.viewLogPage import ViewLogPage  # adjust import path

# Dummy log list
logs = []


# Callback to get logs
def get_logs():
    # Add a new log randomly for testing
    if random.random() < 0.3:  # 30% chance to add a new log
        logs.append(
            {
                "id": len(logs) + 1,
                "dateTime": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "description": f"Random event {len(logs) + 1}",
            }
        )
    return logs


if __name__ == "__main__":
    # Tkinter root
    root = tk.Tk()
    root.geometry("700x500")
    root.title("Test ViewLogPage")

    # Create the page
    log_page = ViewLogPage(root, logs_callback=get_logs)
    log_page.drawPage()  # bring it to front

    root.mainloop()
