import tkinter as tk
import sys
import os

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.safehome.web.pages.userSettingPage import UserSettingPage  # adjust import path


# --- Mock callbacks ---
def mock_change_password(user, password):
    print(f"[Mock] Change password for: {user['name']} to {password}")


def mock_remove_user(user):
    print(f"[Mock] Remove user: {user['name']}")


def mock_user_data():
    return {
        "name": "Alice",
        "type": "Guest",  # try changing to 'Homeowner' to test restriction
        "image_path": os.path.join(
            PROJECT_ROOT, "src/safehome/virtual_device_v3/camera1.jpg"
        ),  # use a valid local image path
    }


if __name__ == "__main__":
    # --- Tkinter setup ---
    root = tk.Tk()
    root.geometry("400x500")
    root.title("User Setting Page Test")

    # --- Create UserSettingPage ---
    user_page = UserSettingPage(
        root=root,
        page_id=1,
        prev_page=None,
        change_pass_callback=mock_change_password,
        remove_user_callback=mock_remove_user,
        user_data_callback=mock_user_data,
    )

    # Draw page initially
    user_page.drawPage()

    # Run Tkinter main loop
    root.mainloop()
