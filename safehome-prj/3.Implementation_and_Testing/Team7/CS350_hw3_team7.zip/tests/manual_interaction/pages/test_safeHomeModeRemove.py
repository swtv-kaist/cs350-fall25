import tkinter as tk
import sys
import os

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.safehome.web.pages.safeHomeModeRemovePage import (
    SafeHomeModeRemovePage,
)  # adjust import path

# Dummy mode data
mode_data = {"id": "Home", "sensor_ids": ["sensor1", "sensor2", "sensor3", "sensor4"]}


# Dummy callback
def remove_callback(mode, removed_sensors):
    print(f"Removed from mode {mode['id']}: {removed_sensors}")


if __name__ == "__main__":
    # Tkinter root
    root = tk.Tk()
    # root.withdraw()  # Hide root window since our page uses Toplevel

    # Create SafeHomeModeRemovePage
    page = SafeHomeModeRemovePage(
        root, selected_mode=mode_data, remove_action_callback=remove_callback
    )
    page.drawPage()

    root.mainloop()
