import tkinter as tk
import sys
import os

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.safehome.web.pages.setUserNewPassPage import SetUserNewPassPage  # adjust import path


def handle_submit(new_pw):
    print("New password submitted:", new_pw)


if __name__ == "__main__":
    root = tk.Tk()
    root.title("Test New Password Page")

    page = SetUserNewPassPage(
        root,
        submit_callback=handle_submit,
    )
    page.drawPage()

    root.mainloop()
