import tkinter as tk
import sys
import os

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.safehome.web.pages.homePage import HomePage  # adjust import path


def dummy_switch_page(page_id):
    print(f"Switch to page: {page_id}")


if __name__ == "__main__":
    root = tk.Tk()
    root.title("SafeHome Test")
    root.geometry("400x500")

    # Create and show the HomePage
    home_page = HomePage(root, switch_page_callback=dummy_switch_page)
    home_page.drawPage()  # bring the page to front

    root.mainloop()
