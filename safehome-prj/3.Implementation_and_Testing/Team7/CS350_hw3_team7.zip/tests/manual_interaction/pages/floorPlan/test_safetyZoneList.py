import tkinter as tk
import sys
import os

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../.."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.safehome.web.pages.floorPlan.safetyZoneListPage import (
    SafetyZoneListPage,
)  # adjust import path


def switch_page(page_key):
    print(f"[TEST] Switch to page: {page_key}")


def safetyZone_added(zone_id, selected_sensors):
    print(f"[TEST] Safety Zone added: {zone_id} with sensors {selected_sensors}")


def safetyZone_clicked(zid):
    print(f"[TEST] Safety Zone clicked: {zid}")


def safetyZone_removed(zone_id):
    print(f"[TEST] Safety Zone removed: {zone_id}")


def safetyZone_updated(zone_data):
    print(f"[TEST] Safety Zone updated: {zone_data}")


if __name__ == "__main__":
    root = tk.Tk()
    root.title("Floor Plan Test")
    root.geometry("800x600")

    # If you have a blueprint image, put path here, else None
    floor_image_path = None

    page = SafetyZoneListPage(
        root=root,
        switch_page_callback=switch_page,
        safetyZone_add_callback=safetyZone_added,
        safetyZone_click_callback=safetyZone_clicked,
        safetyZone_remove_callback=safetyZone_removed,
        safetyZone_update_callback=safetyZone_updated,
    )

    page.add_zone(["motionSensor1", "doorSensor1"])

    # page.add_zone(["window1", "window2", "window3"])

    # page.add_zone(["motionSensor2", "window6"])

    page.drawPage()  # show the page

    root.mainloop()
