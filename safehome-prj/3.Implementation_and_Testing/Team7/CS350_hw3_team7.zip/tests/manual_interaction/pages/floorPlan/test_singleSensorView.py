import tkinter as tk
import sys
import os

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../.."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.safehome.web.pages.floorPlan.singleSensorViewPage import (
    SingleSensorPage,
)  # adjust import path


def switch_page_callback():
    print("Return button pressed - switch page callback called")


def sensor_action_callback(sensor, action):
    print(f"Sensor {sensor.get('name')} action: {action}")


if __name__ == "__main__":
    root = tk.Tk()
    root.title("Single Camera Page Test")
    root.geometry("100x200")

    # Dummy camera info
    sensor_info = {"id": 101, "name": "motionSensor1", "location": [12.5, 7.8], "enabled": True}

    page = SingleSensorPage(
        root=root,
        switch_page_callback=switch_page_callback,
        sensor_action_callback=sensor_action_callback,
        selected_sensor=sensor_info,
    )

    page.drawPage()  # Show the page

    root.mainloop()
