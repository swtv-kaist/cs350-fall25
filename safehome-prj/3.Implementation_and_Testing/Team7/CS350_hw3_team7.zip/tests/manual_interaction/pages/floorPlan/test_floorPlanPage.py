import tkinter as tk
import sys
import os

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../.."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.safehome.web.pages.floorPlan.floorPlanPage import FloorPlanPage  # adjust import path

fake_camera_list = [
    {
        "id": 1,
        "location": [12.5, 7.8],
        "enabled": True,
        "hasPassword": False,
        "password": "secret",
        "image_path": os.path.join(
            PROJECT_ROOT, "src/safehome/virtual_device_v3/camera1.jpg"
        ),  # use a valid local image path
    },
    {
        "id": 2,
        "location": [12.5, 7.8],
        "enabled": True,
        "hasPassword": True,
        "password": "secret",
        "image_path": os.path.join(
            PROJECT_ROOT, "src/safehome/virtual_device_v3/camera1.jpg"
        ),  # use a valid local image path
    },
    {
        "id": 3,
        "location": [12.5, 7.8],
        "enabled": False,
        "hasPassword": True,
        "password": "secret",
        "image_path": os.path.join(
            PROJECT_ROOT, "src/safehome/virtual_device_v3/camera1.jpg"
        ),  # use a valid local image path
    },
    {
        "id": 4,
        "location": [12.5, 7.8],
        "enabled": True,
        "hasPassword": False,
        "password": "",
        "image_path": os.path.join(
            PROJECT_ROOT, "src/safehome/virtual_device_v3/camera2.jpg"
        ),  # use a valid local image path
    },
]

fake_sensor_list = [
    {"id": 1, "name": "motionSensor1", "location": [5, 10], "enabled": True},
    {"id": 2, "name": "motionSensor2", "location": [15, 20], "enabled": True},
    {"id": 3, "name": "doorSensor1", "location": [25, 30], "enabled": False},
    {"id": 4, "name": "doorSensor2", "location": [35, 40], "enabled": True},
    {"id": 5, "name": "window1", "location": [35, 40], "enabled": True},
    {"id": 6, "name": "window2", "location": [35, 40], "enabled": True},
    {"id": 7, "name": "window3", "location": [35, 40], "enabled": True},
    {"id": 8, "name": "window4", "location": [35, 40], "enabled": True},
    {"id": 9, "name": "window5", "location": [35, 40], "enabled": True},
    {"id": 10, "name": "window6", "location": [35, 40], "enabled": True},
]


def point_clicked(point_id):
    if "camera" in point_id:
        return fake_camera_list[int(point_id.split("camera")[-1]) - 1]
    else:
        for sensor in fake_sensor_list:
            if sensor["name"] == point_id:
                return sensor
    # print(f"[TEST] Point clicked: {point_id}")


def switch_page(page_key):
    print(f"[TEST] Switch to page: {page_key}")


if __name__ == "__main__":
    root = tk.Tk()
    root.title("Floor Plan Test")
    root.geometry("800x600")

    # If you have a blueprint image, put path here, else None
    floor_image_path = None

    page = FloorPlanPage(root, switch_page_callback=switch_page, point_click_callback=point_clicked)

    page.drawPage()  # show the page

    root.mainloop()
