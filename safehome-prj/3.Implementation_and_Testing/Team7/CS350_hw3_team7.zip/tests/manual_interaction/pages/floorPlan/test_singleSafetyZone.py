import tkinter as tk
import sys
import os

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../.."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.safehome.web.pages.floorPlan.singleSafetyZonePage import (
    SingleSafetyZonePage,
)  # adjust import path


# Example callback (you can move this to another file if you want)
def fake_zone_action(zone, action):
    print(f"Zone {zone['id']} → action: {action}")


if __name__ == "__main__":
    root = tk.Tk()
    # root.withdraw()   # Hide main window (optional)

    # Example zone data for testing
    zone = {"id": 1, "enabled": True, "sensor_ids": ["motionSensor1", "window2", "window3"]}

    # Create popup page
    page = SingleSafetyZonePage(root, selected_zone=zone, zone_action_callback=fake_zone_action)

    # Draw window
    page.drawPage()

    # Run Tk event loop
    root.mainloop()
