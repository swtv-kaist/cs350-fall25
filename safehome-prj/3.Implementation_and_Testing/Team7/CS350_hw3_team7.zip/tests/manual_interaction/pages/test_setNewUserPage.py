# tests/pages/test_setNewUserPage.py
import tkinter as tk
import sys
import os

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.safehome.web.pages.setNewUserPage import SetNewUserPage  # adjust import path


def demo_submit_callback(username, password, user_type, image_path):
    print("----- New User Submitted -----")
    print("Username:", username)
    print("Password:", password)
    print("Type:", user_type)
    print("Image Path:", image_path)
    print("--------------------------------")


def demo_image_callback():
    """Optional: You can override image selection if needed"""
    from tkinter import filedialog

    return filedialog.askopenfilename(
        title="Choose User Image", filetypes=[("Image Files", "*.png;*.jpg;*.jpeg;*.bmp;*.gif")]
    )


if __name__ == "__main__":
    root = tk.Tk()
    root.title("Test - Set New User Page")
    root.geometry("100x200")

    page = SetNewUserPage(
        root=root, submit_callback=demo_submit_callback, user_image_callback=demo_image_callback
    )

    page.drawPage()  # show it

    root.mainloop()
