import tkinter as tk
import sys
import os

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.safehome.web.pages.safeHomeModeConfigPage import (
    SafeHomeModeConfigPage,
)  # adjust import path


def mode_action_callback(mode, action):
    print("Callback received:", mode, action)


if __name__ == "__main__":
    root = tk.Tk()
    # root.withdraw()   # Hide main window (optional)

    # Example mode data
    selected_mode = {"id": "Home", "sensor_ids": ["window1", "window2", "doorSensor1"]}

    # Run the page
    page = SafeHomeModeConfigPage(
        root, selected_mode, get_mode_callback=None, mode_action_callback=mode_action_callback
    )

    root.mainloop()
