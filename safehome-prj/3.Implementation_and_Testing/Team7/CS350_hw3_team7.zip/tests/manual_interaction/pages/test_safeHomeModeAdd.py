import tkinter as tk
import sys
import os

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.safehome.web.pages.safeHomeModeAddPage import SafeHomeModeAddPage  # adjust import path

# Example mode data
example_mode = {"id": "Home", "sensor_ids": ["motionSensor1", "doorSensor1"]}


def add_action_callback(mode, new_sensors):
    print(f"Add sensors to mode {mode['id']}: {new_sensors}")
    # Optionally update mode locally
    mode["sensor_ids"].extend(new_sensors)


if __name__ == "__main__":
    # Initialize root window
    root = tk.Tk()
    root.title("SafeHome Demo")

    # Launch SafeHomeModeAddPage
    page = SafeHomeModeAddPage(root, example_mode, add_action_callback=add_action_callback)
    page.drawPage()

    # Start Tkinter main loop
    root.mainloop()
