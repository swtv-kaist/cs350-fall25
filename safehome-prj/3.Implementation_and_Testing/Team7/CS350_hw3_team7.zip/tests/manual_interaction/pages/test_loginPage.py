import tkinter as tk
import sys
import os

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.safehome.web.pages.loginPage import LoginPage  # adjust import path


# Dummy system callback to simulate system response
def system_receive_login(username, password):
    print(f"System received login attempt: {username=} {password=}")
    # For example, return a message to page (like wrong password)
    login_page.setPageParameters(f"Received username: {username}")


if __name__ == "__main__":
    root = tk.Tk()
    root.title("Login Page Test")
    root.geometry("300x250")

    # Create login page
    login_page = LoginPage(root, page_id=1, system_callback=system_receive_login)

    # Start Tkinter mainloop
    root.mainloop()
