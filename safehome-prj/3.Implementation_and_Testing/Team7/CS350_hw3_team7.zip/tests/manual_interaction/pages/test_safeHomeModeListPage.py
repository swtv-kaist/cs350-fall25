import tkinter as tk
import sys
import os

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.safehome.web.pages.safeHomeModeListPage import SafeHomeModeListPage  # adjust import path


def on_change_mode(new_mode):
    print("Mode changed to:", new_mode)


def on_configure_mode(selected_mode):
    print("Configuring mode:", selected_mode)


if __name__ == "__main__":
    root = tk.Tk()
    root.title("Safe Home Mode List Page Test")
    root.geometry("800x800")
    page = SafeHomeModeListPage(
        root,
        current_mode="Home",
        on_change_mode_callback=on_change_mode,
        on_configure_mode_callback=on_configure_mode,
    )
    root.mainloop()
