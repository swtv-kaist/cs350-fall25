# tests/unit_tests/test_system_settings.py

from safehome.config.SystemSettings import SystemSettings


def test_initialization_defaults():
    """
    Ensure default initialization sets all values correctly.
    """
    s = SystemSettings()

    assert s.getSystemLockTime() == 0
    assert s.getPanicPhoneNumber() == ""
    assert s.getAlarmTimeBeforePhoneCall() == 0
    assert s.getHomePhoneNumber() == ""


def test_initialization_custom_values():
    """
    Ensure custom constructor arguments are properly stored.
    """
    s = SystemSettings(
        systemLockTime=30,
        panicPhoneNumber="112",
        alarmTimeBeforePhoneCall=10,
        homePhoneNumber="010-1234-5678",
    )

    assert s.getSystemLockTime() == 30
    assert s.getPanicPhoneNumber() == "112"
    assert s.getAlarmTimeBeforePhoneCall() == 10
    assert s.getHomePhoneNumber() == "010-1234-5678"


def test_setters_update_values_correctly():
    """
    Ensure all setter methods properly replace values.
    """
    s = SystemSettings()

    s.setSystemLockTime(45)
    s.setPanicPhoneNumber("119")
    s.setAlarmTimeBeforePhoneCall(20)
    s.setHomePhoneNumber("02-555-5555")

    assert s.getSystemLockTime() == 45
    assert s.getPanicPhoneNumber() == "119"
    assert s.getAlarmTimeBeforePhoneCall() == 20
    assert s.getHomePhoneNumber() == "02-555-5555"


def test_multiple_instances_are_independent():
    """
    Ensure instances maintain their own state.
    """
    s1 = SystemSettings(systemLockTime=10)
    s2 = SystemSettings(systemLockTime=99)

    assert s1.getSystemLockTime() == 10
    assert s2.getSystemLockTime() == 99

    s1.setSystemLockTime(50)
    assert s1.getSystemLockTime() == 50
    assert s2.getSystemLockTime() == 99  # unchanged


def test_setting_negative_values():
    """
    Even if application logic may not allow negatives, ensure class stores them consistently
    since no validation exists.
    """
    s = SystemSettings()

    s.setSystemLockTime(-5)
    s.setAlarmTimeBeforePhoneCall(-10)

    assert s.getSystemLockTime() == -5
    assert s.getAlarmTimeBeforePhoneCall() == -10


def test_invalid_types_for_numeric_inputs():
    """
    Validate current behavior: class does not enforce type checking.
    Test documents expected behavior (may change later).
    """

    s = SystemSettings()

    # no type enforcement, so any value is assigned directly
    s.setSystemLockTime("not-a-number")
    assert s.getSystemLockTime() == "not-a-number"

    s.setAlarmTimeBeforePhoneCall(None)
    assert s.getAlarmTimeBeforePhoneCall() is None


def test_invalid_types_for_string_inputs():
    """
    Ensure class stores any assigned value even if unconventional.
    """
    s = SystemSettings()

    s.setPanicPhoneNumber(12345)
    s.setHomePhoneNumber(99999)

    assert s.getPanicPhoneNumber() == 12345
    assert s.getHomePhoneNumber() == 99999
