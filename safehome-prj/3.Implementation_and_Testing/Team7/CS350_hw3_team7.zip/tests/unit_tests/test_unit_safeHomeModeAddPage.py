import pytest
import tkinter as tk
from safehome.web.pages.safeHomeModeAddPage import SafeHomeModeAddPage


@pytest.fixture
def root():
    root = tk.Tk()
    root.withdraw()  # hide main window
    yield root
    root.destroy()


@pytest.fixture
def selected_mode():
    return {"name": "Night Mode", "sensor_ids": ["sensor1", "sensor2"], "sensor_list": []}


def test_point_click_add_sensor(root, selected_mode):
    called = {}

    def add_callback():
        called["called"] = True

    page = SafeHomeModeAddPage(root, selected_mode, add_action_callback=add_callback)

    # Click a new sensor
    page.point_click_callback("sensor3")
    assert "sensor3" in page.new_sensor_vars
    assert page.status_label.cget("text") == "sensor3 added to selection."

    # Click a duplicate sensor
    page.point_click_callback("sensor1")
    assert "already in mode or selected" in page.status_label.cget("text")

    # Click a camera point
    page.point_click_callback("camera1")
    assert "Cannot add cameras" in page.status_label.cget("text")


def test_add_selected_sensors(root, selected_mode):
    called = {}

    def add_callback():
        called["called"] = True

    page = SafeHomeModeAddPage(root, selected_mode, add_action_callback=add_callback)
    page.point_click_callback("sensor3")  # Add sensor to new_sensor_vars

    # Call _add
    page._add()
    assert "sensor3" in selected_mode["sensor_list"]
    assert called.get("called") is True
    # new_sensor_vars should be cleared
    assert page.new_sensor_vars == {}
