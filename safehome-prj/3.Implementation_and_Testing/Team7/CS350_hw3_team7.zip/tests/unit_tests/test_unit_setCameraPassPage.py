# test_unit_setCameraPassPage.py
import pytest
import tkinter as tk

from safehome.web.pages.camera.setCameraPassPage import SetCameraPassPage, cameraManager


class MockCamera:
    def __init__(self, cam_id):
        self.id = cam_id
        self._password = None

    def set_password(self, new_pw):
        self._password = new_pw


@pytest.fixture
def root():
    r = tk.Tk()
    r.withdraw()  # hide main window
    yield r
    r.destroy()


def test_submit_validation_empty_fields(root, monkeypatch):
    cam = {"id": "Cam1"}
    page = SetCameraPassPage(root, selected_camera=cam)

    # Patch cameraManager to avoid real I/O
    monkeypatch.setattr(cameraManager, "load_cameras", lambda: None)
    monkeypatch.setattr(cameraManager, "get_camera_by_id", lambda cam_id: MockCamera(cam_id))
    monkeypatch.setattr(cameraManager, "save_cameras", lambda: None)
    monkeypatch.setattr(page, "_cancel", lambda: None)  # prevent window destroy

    # empty fields
    page.new_pass_entry.delete(0, tk.END)
    page.confirm_pass_entry.delete(0, tk.END)
    page._submit()
    assert page.status_label.cget("text") == "Please fill all fields"


def test_submit_validation_mismatch(root, monkeypatch):
    cam = {"id": "Cam1"}
    page = SetCameraPassPage(root, selected_camera=cam)
    monkeypatch.setattr(page, "_cancel", lambda: None)
    monkeypatch.setattr(cameraManager, "load_cameras", lambda: None)
    monkeypatch.setattr(cameraManager, "save_cameras", lambda: None)
    monkeypatch.setattr(cameraManager, "get_camera_by_id", lambda cam_id: MockCamera(cam_id))

    page.new_pass_entry.insert(0, "1234")
    page.confirm_pass_entry.insert(0, "5678")
    page._submit()
    assert page.status_label.cget("text") == "Passwords do not match"


def test_submit_success(root, monkeypatch):
    cam = {"id": "Cam1"}
    page = SetCameraPassPage(root, selected_camera=cam)
    monkeypatch.setattr(page, "_cancel", lambda: None)

    mock_cam = MockCamera("Cam1")
    monkeypatch.setattr(cameraManager, "load_cameras", lambda: None)
    monkeypatch.setattr(cameraManager, "save_cameras", lambda: None)
    monkeypatch.setattr(cameraManager, "get_camera_by_id", lambda cam_id: mock_cam)

    page.new_pass_entry.insert(0, "1234")
    page.confirm_pass_entry.insert(0, "1234")
    page._submit()
    assert page.status_label.cget("text") == "Password updated successfully!"
    assert mock_cam._password == "1234"
