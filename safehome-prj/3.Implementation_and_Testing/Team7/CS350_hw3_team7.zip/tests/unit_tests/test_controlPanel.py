import pytest
import tkinter as tk

from safehome.controlPanel import MyControlPanel


@pytest.fixture
def panel():
    """Create a control panel instance for unit tests."""
    root = tk.Tk()
    root.withdraw()
    calls = {"events": []}

    def system_callback(event, data):
        calls["events"].append((event, data))
        # Simple login/password behavior
        if event == "login":
            return data == "1234"
        if event == "cur_mode":
            return "Home"
        if event == "mode":
            return data
        return None

    p = MyControlPanel(master=root, system_callback=system_callback)
    yield p, calls
    try:
        p.destroy()
        root.destroy()
    except Exception:
        pass


def _enter_code(panel, code: str):
    mapping = {
        "0": panel.button0,
        "1": panel.button1,
        "2": panel.button2,
        "3": panel.button3,
        "4": panel.button4,
        "5": panel.button5,
        "6": panel.button6,
        "7": panel.button7,
        "8": panel.button8,
        "9": panel.button9,
    }
    for ch in code:
        mapping[ch]()


def test_login_success_transitions_to_main(panel):
    p, calls = panel

    # Start in login status
    assert p.status == "login"

    _enter_code(p, "1234")
    # Simulate display update cycle
    p._update_display_text()

    assert ("login", "1234") in calls["events"]
    assert p.status == "main"


def test_login_failure_stays_in_login(panel, monkeypatch):
    p, calls = panel

    # Avoid recursive calls from display updates during failure path
    monkeypatch.setattr(MyControlPanel, "set_display_short_message2", lambda self, msg: None)

    _enter_code(p, "0000")
    p._update_display_text()

    assert ("login", "0000") in calls["events"]
    assert p.status == "login"
    assert p.button_sequence == ""


def test_main_menu_buttons_trigger_on_off_arm_disarm(panel):
    p, calls = panel

    # Force main state
    p.status = "main"

    p.button2()  # on
    p.button3()  # off
    p.button4()  # arm
    p.button5()  # disarm

    assert ("on", []) in calls["events"]
    assert ("off", []) in calls["events"]
    assert ("arm", []) in calls["events"]
    assert ("disarm", []) in calls["events"]


def test_mode_selection_and_changes(panel):
    p, calls = panel

    p.status = "main"
    p.set_main_display()

    # Enter mode selection
    p.button1()
    assert p.status == "mode"
    assert ("cur_mode", []) in calls["events"]

    # Choose specific modes
    p.button1()  # Home
    p.button2()  # Away
    p.button3()  # Overnight travel
    p.button4()  # Extended Travel

    mode_events = [e for e in calls["events"] if e[0] == "mode"]
    assert mode_events
    # Last call should be Extended Travel
    assert mode_events[-1][1] == "Extended Travel"


def test_change_password_flow(panel):
    p, calls = panel

    p.status = "main"
    p.button6()  # enter change_pass state
    assert p.status == "change_pass"

    # Enter new password
    _enter_code(p, "5678")
    p._update_display_text()

    assert p.status == "conf_pass"

    # Confirm
    p.button1()
    assert ("change_pass", "5678") in calls["events"]
    assert p.status == "main"


def test_logout_resets_to_login(panel):
    p, _ = panel

    p.status = "main"
    p.set_display_away(True)
    p.set_display_stay(True)
    p.set_display_not_ready(True)

    p.button7()

    assert p.status == "login"
    assert p.button_sequence == ""

