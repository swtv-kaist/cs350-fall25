from unittest.mock import Mock, patch
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))

from safehome.cameras.CameraManager import CameraManager


class TestCameraManagerUnitInit:
    """Unit tests for CameraManager initialization"""

    @patch("safehome.cameras.CameraManager.StorageManager")
    def test_init_creates_storage_manager(self, mock_storage_class):
        """Test that __init__ creates a StorageManager instance"""
        mock_storage = Mock()
        mock_storage.load_json.return_value = []
        mock_storage_class.return_value = mock_storage

        manager = CameraManager(storage_dir="TestStorage")

        # Verify StorageManager was created with correct directory
        mock_storage_class.assert_called_once_with("TestStorage")
        assert manager.storage == mock_storage

    @patch("safehome.cameras.CameraManager.StorageManager")
    def test_init_calls_load_cameras(self, mock_storage_class):
        """Test that __init__ calls load_cameras"""
        mock_storage = Mock()
        mock_storage.load_json.return_value = []
        mock_storage_class.return_value = mock_storage

        manager = CameraManager()

        # Verify load_json was called
        mock_storage.load_json.assert_called_once_with("cameras")

    @patch("safehome.cameras.CameraManager.StorageManager")
    def test_init_with_default_storage_dir(self, mock_storage_class):
        """Test initialization with default storage directory"""
        mock_storage = Mock()
        mock_storage.load_json.return_value = []
        mock_storage_class.return_value = mock_storage

        manager = CameraManager()

        mock_storage_class.assert_called_once_with("Storage")


class TestCameraManagerUnitSaveCameras:
    """Unit tests for save_cameras method"""

    @patch("safehome.cameras.CameraManager.StorageManager")
    def test_save_cameras_empty_list(self, mock_storage_class):
        """Test saving when camera list is empty"""
        mock_storage = Mock()
        mock_storage.load_json.return_value = []
        mock_storage.save_json.return_value = True
        mock_storage_class.return_value = mock_storage

        manager = CameraManager()
        result = manager.save_cameras()

        assert result is True
        mock_storage.save_json.assert_called_once_with("cameras", [])

    @patch("safehome.cameras.CameraManager.StorageManager")
    def test_save_cameras_with_cameras(self, mock_storage_class):
        """Test saving cameras to storage"""
        mock_storage = Mock()
        mock_storage.load_json.return_value = []
        mock_storage.save_json.return_value = True
        mock_storage_class.return_value = mock_storage

        manager = CameraManager()

        # Add mock cameras
        mock_cam1 = Mock()
        mock_cam1.to_dict.return_value = {"camera_id": 1, "location": [10, 20]}
        mock_cam2 = Mock()
        mock_cam2.to_dict.return_value = {"camera_id": 2, "location": [30, 40]}

        manager._cameras = [mock_cam1, mock_cam2]

        result = manager.save_cameras()

        assert result is True
        expected_data = [
            {"camera_id": 1, "location": [10, 20]},
            {"camera_id": 2, "location": [30, 40]},
        ]
        mock_storage.save_json.assert_called_once_with("cameras", expected_data)

    @patch("safehome.cameras.CameraManager.StorageManager")
    def test_save_cameras_returns_false_on_failure(self, mock_storage_class):
        """Test save_cameras returns False when storage fails"""
        mock_storage = Mock()
        mock_storage.load_json.return_value = []
        mock_storage.save_json.return_value = False
        mock_storage_class.return_value = mock_storage

        manager = CameraManager()
        result = manager.save_cameras()

        assert result is False


class TestCameraManagerUnitGetCameraById:
    """Unit tests for get_camera_by_id method"""

    @patch("safehome.cameras.CameraManager.StorageManager")
    def test_get_camera_by_id_not_found(self, mock_storage_class):
        """Test getting camera that doesn't exist returns None"""
        mock_storage = Mock()
        mock_storage.load_json.return_value = []
        mock_storage_class.return_value = mock_storage

        manager = CameraManager()

        result = manager.get_camera_by_id(999)
        assert result is None


class TestCameraManagerUnitGetAllCameras:
    """Unit tests for get_all_cameras method"""

    @patch("safehome.cameras.CameraManager.StorageManager")
    def test_get_all_cameras_returns_three_cameras(self, mock_storage_class):
        """Test get_all_cameras returns exactly 3 cameras"""
        mock_storage = Mock()
        mock_storage.load_json.return_value = []
        mock_storage_class.return_value = mock_storage

        manager = CameraManager()

        # Add 3 mock cameras
        mock_cams = []
        for i in range(3):
            mock_cam = Mock()
            mock_cam.get_id.return_value = i + 1
            mock_cam.verify_password.return_value = True
            mock_cams.append(mock_cam)

        manager._cameras = mock_cams

        result = manager.get_all_cameras([None, None, None])

        assert len(result) == 3
        assert result == mock_cams

    @patch("safehome.cameras.CameraManager.StorageManager")
    def test_get_all_cameras_with_passwords(self, mock_storage_class):
        """Test get_all_cameras with password list"""
        mock_storage = Mock()
        mock_storage.load_json.return_value = []
        mock_storage_class.return_value = mock_storage

        manager = CameraManager()

        # Setup mocks
        mock_cam1 = Mock()
        mock_cam1.get_id.return_value = 1
        mock_cam1.verify_password.return_value = True

        mock_cam2 = Mock()
        mock_cam2.get_id.return_value = 2
        mock_cam2.verify_password.return_value = True

        mock_cam3 = Mock()
        mock_cam3.get_id.return_value = 3
        mock_cam3.verify_password.return_value = True

        manager._cameras = [mock_cam1, mock_cam2, mock_cam3]

        passwords = ["pass1", "pass2", None]
        result = manager.get_all_cameras(passwords)

    @patch("safehome.cameras.CameraManager.StorageManager")
    def test_get_all_cameras_with_wrong_password(self, mock_storage_class):
        """Test get_all_cameras returns None for wrong password"""
        mock_storage = Mock()
        mock_storage.load_json.return_value = []
        mock_storage_class.return_value = mock_storage

        manager = CameraManager()

        # Camera 1: correct password
        mock_cam1 = Mock()
        mock_cam1.get_id.return_value = 1
        mock_cam1.verify_password.return_value = True

        # Camera 2: wrong password
        mock_cam2 = Mock()
        mock_cam2.get_id.return_value = 2
        mock_cam2.verify_password.return_value = False

        # Camera 3: correct
        mock_cam3 = Mock()
        mock_cam3.get_id.return_value = 3
        mock_cam3.verify_password.return_value = True

        manager._cameras = [mock_cam1, mock_cam2, mock_cam3]

        result = manager.get_all_cameras(["pass1", "wrong", None])

        assert len(result) == 3
        assert result[0] == mock_cam1
        assert result[2] == mock_cam3
