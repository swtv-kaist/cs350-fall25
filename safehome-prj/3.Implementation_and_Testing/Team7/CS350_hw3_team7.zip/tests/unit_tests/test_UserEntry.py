# test_user_entry.py
import pytest
from safehome.login.UserEntry import UserEntry


@pytest.fixture
def sample_user():
    return UserEntry(username="alice", password="secret", type="admin", interface="web")


def test_username(sample_user):
    assert sample_user.getUsername() == "alice"
    sample_user.setUsername("bob")
    assert sample_user.getUsername() == "bob"


def test_password(sample_user):
    assert sample_user.getPassword() == "secret"
    assert sample_user.verifyPassword("secret") is True
    assert sample_user.verifyPassword("wrong") is False
    sample_user.setPassword("newpass")
    assert sample_user.getPassword() == "newpass"
    assert sample_user.verifyPassword("newpass") is True


def test_interface(sample_user):
    assert sample_user.getInterface() == "web"
    sample_user.setInterface("mobile")
    assert sample_user.getInterface() == "mobile"


def test_type(sample_user):
    assert sample_user.getType() == "admin"
    sample_user.setType("guest")
    assert sample_user.getType() == "guest"


def test_to_dict_and_from_dict(sample_user):
    d = sample_user.to_dict()
    assert d["username"] == "alice"
    assert d["password"] == "secret"
    assert d["interface"] == "web"
    assert d["type"] == "admin"

    user_copy = UserEntry.from_dict(d)
    assert user_copy.getUsername() == "alice"
    assert user_copy.getPassword() == "secret"
    assert user_copy.getInterface() == "web"
    assert user_copy.getType() == "admin"
