# =============================================================================
# UNIT TESTS - tests/unit_tests/test_FloorPlanView.py
# =============================================================================

import tkinter as tk
from unittest.mock import Mock, patch
import sys
import os
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))

from safehome.web.floorPlan import FloorPlanView, points, PROJECT_ROOT


class TestFloorPlanViewInitialization:
    """Unit tests for FloorPlanView initialization"""

    def setup_method(self):
        """Create Tkinter root for each test"""
        self.root = tk.Tk()
        self.root.withdraw()  # Hide window

    def teardown_method(self):
        """Destroy Tkinter root"""
        try:
            self.root.destroy()
        except:
            pass

    def test_init_creates_canvas(self):
        """Test that FloorPlanView creates a Canvas widget"""
        view = FloorPlanView(self.root)

        assert isinstance(view, tk.Canvas)

    def test_init_sets_background_white(self):
        """Test that canvas background is white"""
        view = FloorPlanView(self.root)

        assert view.cget("bg") == "white"

    def test_init_stores_callback(self):
        """Test that callback is stored"""
        callback = Mock()
        view = FloorPlanView(self.root, point_click_callback=callback)

        assert view.point_click_callback == callback

    def test_init_stores_floor_image_path(self):
        """Test that floor image path is stored"""
        custom_path = "/custom/path/image.png"
        view = FloorPlanView(self.root, floor_image_path=custom_path)

        assert view.floor_image_path == custom_path

    def test_init_stores_points_dict(self):
        """Test that points dictionary is stored"""
        custom_points = {"test": (10, 20, 5, 5)}
        view = FloorPlanView(self.root, points_dict=custom_points)

        assert view.points == custom_points

    def test_init_uses_default_floor_image_path(self):
        """Test default floor image path is correct"""
        view = FloorPlanView(self.root)

        expected_path = os.path.join(PROJECT_ROOT, "virtual_device_v3/floorplan.png")
        assert view.floor_image_path == expected_path

    def test_init_uses_default_points(self):
        """Test default points dictionary is used"""
        view = FloorPlanView(self.root)

        assert view.points == points

    @patch.object(FloorPlanView, "_load_image")
    def test_init_schedules_load_image(self, mock_load):
        """Test that _load_image is scheduled with after()"""
        view = FloorPlanView(self.root)

        # Process pending events
        self.root.update()

        # _load_image should be called (at least once from after)
        assert mock_load.call_count >= 1


class TestFloorPlanViewLoadImage:
    """Unit tests for _load_image method"""

    def setup_method(self):
        """Create Tkinter root and mock image"""
        self.root = tk.Tk()
        self.root.withdraw()

    def teardown_method(self):
        """Cleanup"""
        try:
            self.root.destroy()
        except:
            pass

    @patch("safehome.web.floorPlan.Image.open")
    @patch("safehome.web.floorPlan.ImageTk.PhotoImage")
    def test_load_image_stores_dimensions(self, mock_photo, mock_open):
        """Test that image dimensions are stored"""
        mock_img = Mock()
        mock_img.size = (640, 480)
        mock_open.return_value = mock_img
        mock_photo.return_value = Mock()

        view = FloorPlanView(self.root)
        view._load_image()

        assert view.orig_width == 640
        assert view.orig_height == 480

    @patch("safehome.web.floorPlan.Image.open")
    @patch("builtins.print")
    def test_load_image_handles_file_not_found(self, mock_print, mock_open):
        """Test that FileNotFoundError is handled gracefully"""
        mock_open.side_effect = FileNotFoundError("File not found")

        view = FloorPlanView(self.root, floor_image_path="/nonexistent/file.png")
        view._load_image()

        # Should print error message
        mock_print.assert_called()
        call_args = str(mock_print.call_args)
        assert "Failed to load" in call_args

    @patch("safehome.web.floorPlan.Image.open")
    @patch("builtins.print")
    def test_load_image_handles_generic_exception(self, mock_print, mock_open):
        """Test that generic exceptions are handled"""
        mock_open.side_effect = Exception("Generic error")

        view = FloorPlanView(self.root)
        view._load_image()

        mock_print.assert_called()


class TestFloorPlanViewSetPoints:
    """Unit tests for set_points method"""

    def setup_method(self):
        """Setup"""
        self.root = tk.Tk()
        self.root.withdraw()

    def teardown_method(self):
        """Cleanup"""
        try:
            self.root.destroy()
        except:
            pass

    def test_set_points_creates_ovals(self):
        """Test that ovals are created for each point"""
        view = FloorPlanView(self.root)
        test_points = {
            "point1": (100, 100, 10, 10),
            "point2": (200, 200, 20, 20),
        }

        view.set_points(test_points)

        # Check that ovals were created
        point1_items = view.find_withtag("point1")
        point2_items = view.find_withtag("point2")

        assert len(point1_items) > 0
        assert len(point2_items) > 0

    def test_set_points_oval_coordinates(self):
        """Test that oval coordinates are correct"""
        view = FloorPlanView(self.root)
        test_points = {"test": (100, 100, 10, 20)}

        view.set_points(test_points)

        oval_id = view.find_withtag("test")[0]
        coords = view.coords(oval_id)

        # Oval should be at (x-rx, y-ry, x+rx, y+ry)
        assert coords == [90, 80, 110, 120]  # (100-10, 100-20, 100+10, 100+20)

    def test_set_points_oval_styling(self):
        """Test that ovals have correct styling"""
        view = FloorPlanView(self.root)
        test_points = {"test": (100, 100, 10, 10)}

        view.set_points(test_points)

        oval_id = view.find_withtag("test")[0]

        # Check styling
        assert view.itemcget(oval_id, "fill") == ""
        assert view.itemcget(oval_id, "outline") == ""

    def test_set_points_binds_click_handler(self):
        """Test that click handler is bound to each point"""
        callback = Mock()
        view = FloorPlanView(self.root, point_click_callback=callback)
        test_points = {"test": (100, 100, 10, 10)}

        view.set_points(test_points)

        # Verify binding exists (we can't easily test the actual click without integration test)
        bindings = view.tag_bind("test")
        assert bindings is not None

    def test_set_points_regular_sensor_no_mapping(self):
        """Test that non-motionSensor2 points use their own ID"""
        callback = Mock()
        view = FloorPlanView(self.root, point_click_callback=callback)
        test_points = {
            "motionSensor1": (100, 100, 10, 10),
            "doorSensor1": (200, 200, 10, 10),
        }

        view.set_points(test_points)

        view._clicked("motionSensor1")
        view._clicked("doorSensor1")

        callback.assert_any_call("motionSensor1")
        callback.assert_any_call("doorSensor1")

    def test_set_points_empty_dict(self):
        """Test that empty points dict doesn't cause errors"""
        view = FloorPlanView(self.root)

        # Should not raise exception
        view.set_points({})


class TestFloorPlanViewClicked:
    """Unit tests for _clicked method"""

    def setup_method(self):
        """Setup"""
        self.root = tk.Tk()
        self.root.withdraw()

    def teardown_method(self):
        """Cleanup"""
        try:
            self.root.destroy()
        except:
            pass

    @patch("builtins.print")
    def test_clicked_prints_point_id(self, mock_print):
        """Test that clicking prints the point ID"""
        view = FloorPlanView(self.root)

        view._clicked("test_point")

        assert any(
            call_args.args == ("Clicked point: test_point",) and not call_args.kwargs
            for call_args in mock_print.call_args_list
        )

    def test_clicked_calls_callback_when_provided(self):
        """Test that callback is called with correct point ID"""
        callback = Mock()
        view = FloorPlanView(self.root, point_click_callback=callback)

        view._clicked("doorSensor1")

        callback.assert_called_once_with("doorSensor1")

    def test_clicked_no_callback_doesnt_error(self):
        """Test that clicking without callback doesn't cause error"""
        view = FloorPlanView(self.root, point_click_callback=None)

        # Should not raise exception
        view._clicked("test_point")

    def test_clicked_callback_receives_correct_id(self):
        """Test that callback receives the exact point ID passed"""
        callback = Mock()
        view = FloorPlanView(self.root, point_click_callback=callback)

        test_ids = ["motionSensor1", "doorSensor1", "camera1", "window1"]

        for point_id in test_ids:
            callback.reset_mock()
            view._clicked(point_id)
            callback.assert_called_once_with(point_id)


class TestFloorPlanViewPointsConstant:
    """Unit tests for the points constant"""

    def test_points_is_dict(self):
        """Test that points is a dictionary"""
        assert isinstance(points, dict)

    def test_points_has_motion_sensors(self):
        """Test that points includes motion sensors"""
        assert "motionSensor1" in points
        assert "motionSensor2-1" in points
        assert "motionSensor2-2" in points

    def test_points_has_door_sensors(self):
        """Test that points includes door sensors"""
        assert "doorSensor1" in points
        assert "doorSensor2" in points

    def test_points_has_windows(self):
        """Test that points includes windows"""
        assert "window1" in points
        assert "window2" in points
        assert "window3" in points

    def test_points_has_cameras(self):
        """Test that points includes cameras"""
        assert "camera1" in points
        assert "camera2" in points
        assert "camera3" in points

    def test_points_values_are_tuples(self):
        """Test that all point values are tuples of 4 integers"""
        for point_id, coords in points.items():
            assert isinstance(coords, tuple), f"{point_id} coords not tuple"
            assert len(coords) == 4, f"{point_id} coords not length 4"
            assert all(isinstance(c, int) for c in coords), f"{point_id} coords not all ints"

    def test_points_coordinates_are_positive(self):
        """Test that all coordinates are positive"""
        for point_id, (x, y, rx, ry) in points.items():
            assert x >= 0, f"{point_id} x coordinate negative"
            assert y >= 0, f"{point_id} y coordinate negative"
            assert rx > 0, f"{point_id} rx not positive"
            assert ry > 0, f"{point_id} ry not positive"

    def test_motion_sensor_2_has_all_segments(self):
        """Test that motionSensor2 has all 6 segments"""
        motion2_points = [k for k in points.keys() if "motionSensor2-" in k]
        assert len(motion2_points) == 6

        for i in range(1, 7):
            assert f"motionSensor2-{i}" in points


class TestProjectRoot:
    """Unit tests for PROJECT_ROOT constant"""

    def test_project_root_is_string(self):
        """Test that PROJECT_ROOT is a string"""
        assert isinstance(PROJECT_ROOT, str)

    def test_project_root_is_absolute_path(self):
        """Test that PROJECT_ROOT is an absolute path"""
        assert os.path.isabs(PROJECT_ROOT)

    def test_project_root_exists(self):
        """Test that PROJECT_ROOT directory exists"""
        assert os.path.exists(PROJECT_ROOT)
