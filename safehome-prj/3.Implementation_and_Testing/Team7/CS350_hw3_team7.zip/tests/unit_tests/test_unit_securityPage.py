import pytest
import tkinter as tk
from safehome.web.pages.securityPage import SecurityPage


@pytest.fixture
def root():
    root = tk.Tk()
    root.withdraw()
    yield root
    root.destroy()


def test_return_button_calls_prev_page(root):
    called = {}

    def switch_page_callback(pid):
        called["pid"] = pid

    page = SecurityPage(root, switch_page_callback=switch_page_callback, prev_page="home")
    # The last button is the return button
    return_btn = [w for w in page.frame.winfo_children() if isinstance(w, tk.Button)][-1]
    return_btn.invoke()
    assert called["pid"] == "home"
