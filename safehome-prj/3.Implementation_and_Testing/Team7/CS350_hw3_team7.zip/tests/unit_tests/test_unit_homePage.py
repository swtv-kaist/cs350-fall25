import pytest
import tkinter as tk
from safehome.web.pages.homePage import HomePage


# Fixture to create Tk root once per module
@pytest.fixture(scope="module")
def root():
    root = tk.Tk()
    yield root
    root.destroy()


def test_switch_page_callback_called(root):
    """Test that _switch_page calls the callback with correct id."""
    called = {}

    def callback(page_id):
        called["page_id"] = page_id

    page = HomePage(root, switch_page_callback=callback)
    page._switch_page("security")
    assert called["page_id"] == "security"


def test_on_add_user_creates_setNewUserPage(root, monkeypatch):
    """Test that _on_add_user triggers SetNewUserPage.drawPage without errors."""
    from safehome.web.pages.setNewUserPage import SetNewUserPage

    # Patch drawPage to record call
    called = {}

    def fake_drawPage(self):
        called["called"] = True

    monkeypatch.setattr(SetNewUserPage, "drawPage", fake_drawPage)

    page = HomePage(root)
    page._on_add_user()
    assert called.get("called", False) is True
