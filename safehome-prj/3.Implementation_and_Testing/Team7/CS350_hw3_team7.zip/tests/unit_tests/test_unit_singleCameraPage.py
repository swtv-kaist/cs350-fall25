# unit_tests/test_unit_singleCameraPage.py
import pytest
import tkinter as tk

from safehome.web.pages.camera.singleCameraPage import SingleCameraPage


class MockSetCameraPassPage:
    """Lightweight stand-in that immediately triggers the submit callback."""

    def __init__(self, root, selected_camera=None, prev_page=None, submit_callback=None):
        self.selected_camera = selected_camera
        self.submit_callback = submit_callback
        self.drawn = False

    def drawPage(self):
        self.drawn = True
        if self.submit_callback:
            self.submit_callback("new_password")


class MockCamera:
    """Simplified camera object for enable/disable/remove password tests."""

    def __init__(self, cam_id):
        self.cam_id = cam_id
        self._password = "old_pw"
        self.enabled = True
        self.has_password = True

    def pan_left(self):
        pass

    def pan_right(self):
        pass

    def zoom_in(self):
        pass

    def zoom_out(self):
        pass

    def enable(self):
        self.enabled = True

    def disable(self):
        self.enabled = False

    def remove_password(self):
        self.has_password = False

    def get_view(self):
        from PIL import Image

        return Image.new("RGB", (100, 100), (0, 0, 0))


class MockCameraObj:
    """Camera mock that exposes set_password for password flow tests."""

    def __init__(self):
        self._password = "old_pw"
        self.enabled = True
        self.has_password = True

    def set_password(self, new_pw):
        self._password = new_pw

    def pan_left(self):
        pass

    def pan_right(self):
        pass

    def zoom_in(self):
        pass

    def zoom_out(self):
        pass

    def enable(self):
        self.enabled = True

    def disable(self):
        self.enabled = False

    def remove_password(self):
        self.has_password = False

    def get_view(self):
        from PIL import Image

        return Image.new("RGB", (100, 100), (0, 0, 0))


@pytest.fixture
def root():
    root = tk.Tk()
    root.withdraw()
    yield root
    root.destroy()


@pytest.fixture(autouse=True)
def suppress_draw(monkeypatch):
    """Prevent SingleCameraPage.drawPage from opening real windows during tests."""
    monkeypatch.setattr(SingleCameraPage, "drawPage", lambda self: None)


def test_single_camera_change_password_flow(root, monkeypatch):
    cam_obj = MockCameraObj()
    cam_info = {
        "id": "Cam1",
        "location": [0, 0],
        "enabled": True,
        "hasPassword": True,
        "obj": cam_obj,
    }

    # Patch cameraManager
    from safehome.web.pages.camera import singleCameraPage

    monkeypatch.setattr(
        singleCameraPage,
        "cameraManager",
        type(
            "MockManager",
            (),
            {
                "load_cameras": lambda self: None,
                "save_cameras": lambda self: None,
                "get_camera_by_id": lambda self, cam_id: cam_obj,
            },
        )(),
    )

    # Patch SetCameraPassPage
    monkeypatch.setattr(
        "safehome.web.pages.camera.singleCameraPage.SetCameraPassPage", MockSetCameraPassPage
    )

    page = SingleCameraPage(root, selected_camera=cam_info)

    # Trigger password change
    page._change_password()

    # The page should call SetCameraPassPage.drawPage
    # The callback should update the camera password
    assert cam_obj._password == "new_password"


def test_camera_action_enable_disable(root, monkeypatch):
    cam_obj = MockCamera("Cam1")
    cam_info = {
        "id": "Cam1",
        "hasPassword": True,
        "location": [0, 0],
        "enabled": False,
        "obj": cam_obj,
    }

    # Patch cameraManager to return our mock camera
    from safehome.web.pages.camera import singleCameraPage

    monkeypatch.setattr(
        singleCameraPage,
        "cameraManager",
        type(
            "MockManager",
            (),
            {
                "load_cameras": lambda self: None,
                "save_cameras": lambda self: None,
                "get_camera_by_id": lambda self, cam_id: cam_obj,
            },
        )(),
    )

    page = SingleCameraPage(root, selected_camera=cam_info)

    # Enable camera
    page._action("enable")
    assert cam_info["enabled"] is True
    # Disable camera
    page._action("disable")
    assert cam_info["enabled"] is False


def test_camera_action_remove_password(root, monkeypatch):
    cam_obj = MockCamera("Cam1")
    cam_info = {
        "id": "Cam1",
        "hasPassword": True,
        "location": [0, 0],
        "enabled": True,
        "obj": cam_obj,
    }

    from safehome.web.pages.camera import singleCameraPage

    monkeypatch.setattr(
        singleCameraPage,
        "cameraManager",
        type(
            "MockManager",
            (),
            {
                "load_cameras": lambda self: None,
                "save_cameras": lambda self: None,
                "get_camera_by_id": lambda self, cam_id: cam_obj,
            },
        )(),
    )

    page = SingleCameraPage(root, selected_camera=cam_info)

    page._action("remove_password")
    assert cam_info["hasPassword"] is False


def test_camera_view_show_disabled(root):
    cam_info = {"id": "Cam1", "hasPassword": True, "location": [0, 0], "enabled": False}
    page = SingleCameraPage(root, selected_camera=cam_info)
    page._show()
    assert page.status_label.cget("text") == "Camera is disabled."
