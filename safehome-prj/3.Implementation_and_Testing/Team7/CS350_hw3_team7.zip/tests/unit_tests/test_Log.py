# test_log.py
import pytest
from safehome.log.Log import Log  # adjust import path if needed


@pytest.fixture
def sample_log():
    """Return a sample Log instance for testing."""
    return Log(log_id=1, datetime="2025-11-30 16:00:00", description="Test log")


def test_getters(sample_log):
    """Test getter methods."""
    assert sample_log.getID() == 1
    assert sample_log.getDateTime() == "2025-11-30 16:00:00"
    assert sample_log.getDescription() == "Test log"


def test_setters(sample_log):
    """Test setter methods."""
    sample_log.setID(99)
    sample_log.setDateTime("2025-12-01 12:00:00")
    sample_log.setDescription("Updated log")

    assert sample_log.getID() == 99
    assert sample_log.getDateTime() == "2025-12-01 12:00:00"
    assert sample_log.getDescription() == "Updated log"


def test_to_dict(sample_log):
    """Test serialization to dict."""
    d = sample_log.to_dict()
    assert d == {"id": 1, "datetime": "2025-11-30 16:00:00", "description": "Test log"}


def test_from_dict():
    """Test deserialization from dict."""
    data = {"id": 42, "datetime": "2025-12-01 08:30:00", "description": "From dict log"}
    log = Log.from_dict(data)
    assert log.getID() == 42
    assert log.getDateTime() == "2025-12-01 08:30:00"
    assert log.getDescription() == "From dict log"


def test_from_dict_defaults():
    """Test from_dict with missing keys uses defaults."""
    log = Log.from_dict({})
    assert log.getID() == 0
    assert log.getDateTime() == ""
    assert log.getDescription() == ""
