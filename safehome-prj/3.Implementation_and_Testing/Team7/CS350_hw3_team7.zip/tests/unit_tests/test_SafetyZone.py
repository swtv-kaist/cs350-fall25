import pytest

from safehome.config.SafetyZone import SafetyZone


class DummySensor:
    """Lightweight stand-in for Sensor that tracks arm/disarm calls."""

    def __init__(self, sensor_type="motion", name="s1", sensor_id=1, location=None):
        self._type = sensor_type
        self._name = name
        self._id = sensor_id
        self._location = location or [0, 0, 1, 1]
        self.arm_calls = 0
        self.disarm_calls = 0
        self.armed = False

    def get_type(self):
        return self._type

    def get_name(self):
        return self._name

    def get_id(self):
        return self._id

    def get_location(self):
        return self._location

    def arm(self):
        self.armed = True
        self.arm_calls += 1

    def disarm(self):
        self.armed = False
        self.disarm_calls += 1


@pytest.fixture(autouse=True)
def reset_zone_counter():
    """Ensure the class-level ID counter does not leak between tests."""
    SafetyZone._zone_id_counter = 0
    yield
    SafetyZone._zone_id_counter = 0


def test_auto_assignment_of_zone_ids():
    z1 = SafetyZone("Front Door")
    z2 = SafetyZone("Back Door")

    assert z1.get_id() == 1
    assert z2.get_id() == 2


def test_zone_respects_provided_id_and_updates_counter():
    zone = SafetyZone("Garage", zone_id=10)

    assert zone.get_id() == 10
    assert SafetyZone._zone_id_counter == 10

    another = SafetyZone("Kitchen")
    assert another.get_id() == 11


def test_arm_and_disarm_invokes_sensor_methods():
    sensors = [DummySensor(name="s1"), DummySensor(name="s2")]
    zone = SafetyZone("Living Room", sensor_list=sensors, arm_status=False)

    zone.armSafetyZone()
    assert zone.is_armed() is True
    assert all(sensor.arm_calls == 1 for sensor in sensors)

    zone.disarmSafetyZone()
    assert zone.is_armed() is False
    assert all(sensor.disarm_calls == 1 for sensor in sensors)


def test_to_dict_serializes_all_fields():
    sensors = [
        DummySensor(sensor_type="motion", name="m1", sensor_id=5, location=[1, 2, 3, 4]),
        DummySensor(sensor_type="door", name="d1", sensor_id=6, location=[5, 6, 7, 8]),
    ]
    zone = SafetyZone("Basement", sensor_list=sensors, arm_status=True)

    data = zone.to_dict()

    assert data["name"] == "Basement"
    assert data["id"] == zone.get_id()
    assert data["arm_status"] is True
    assert data["sensor_list"] == [
        {
            "sensor_type": "motion",
            "sensor_name": "m1",
            "sensor_id": 5,
            "sensor_location": [1, 2, 3, 4],
        },
        {
            "sensor_type": "door",
            "sensor_name": "d1",
            "sensor_id": 6,
            "sensor_location": [5, 6, 7, 8],
        },
    ]


def test_from_dict_creates_sensors_and_respects_arm_status(monkeypatch):
    created_sensors = []

    class SensorStub:
        def __init__(self, sensor_type, sensor_name, sensor_id, sensor_location):
            self._type = sensor_type
            self._name = sensor_name
            self._id = sensor_id
            self._location = sensor_location
            self.arm_called = False
            created_sensors.append(self)

        def arm(self):
            self.arm_called = True

        def disarm(self):
            self.arm_called = False

        def get_type(self):
            return self._type

        def get_name(self):
            return self._name

        def get_id(self):
            return self._id

        def get_location(self):
            return self._location

    monkeypatch.setattr("safehome.config.SafetyZone.Sensor", SensorStub)

    payload = {
        "name": "Hallway",
        "id": 42,
        "arm_status": True,
        "sensor_list": [
            {
                "sensor_type": "motion",
                "sensor_name": "m-hall",
                "sensor_id": 101,
                "sensor_location": [0, 0, 2, 2],
            }
        ],
    }

    zone = SafetyZone.from_dict(payload)

    assert zone.get_name() == "Hallway"
    assert zone.get_id() == 42
    assert len(created_sensors) == 1
    assert created_sensors[0].arm_called is True
    assert zone.get_sensor_list()[0] is created_sensors[0]
