from unittest.mock import patch
from safehome.cameras.Camera import Camera


# ----------------------------------------------------------------------
# Construction / Basic Fields
# ----------------------------------------------------------------------
def test_camera_init_basic():
    with patch("safehome.cameras.Camera.DeviceCamera") as MockDev:
        dev = MockDev.return_value

        cam = Camera(
            camera_id=5,
            location=[10, 20],
            is_enabled=1,
            password="abc",
            zoom=3,
            pan=1,
        )

        assert cam.get_id() == 5
        assert cam.get_location() == [10, 20]
        assert cam.is_enabled() is True
        assert cam.has_password() is True
        assert cam.verify_password("abc") is True
        assert dev.set_id.called
        assert dev.zoom == 3
        assert dev.pan == 1


def test_camera_copy_location():
    with patch("safehome.cameras.Camera.DeviceCamera"):
        loc = [10, 20]
        cam = Camera(1, loc)
        loc.append(99)
        assert cam.get_location() == [10, 20]  # internal copy protected


# ----------------------------------------------------------------------
# Password Management
# ----------------------------------------------------------------------
def test_password_verify_and_change():
    with patch("safehome.cameras.Camera.DeviceCamera"):
        cam = Camera(1, [0, 0], password="pw")

        assert cam.verify_password("pw") is True
        assert cam.verify_password("wrong") is False

        cam.set_password("newpw")
        assert cam.verify_password("newpw") is True
        assert cam.verify_password("pw") is False


def test_password_remove():
    with patch("safehome.cameras.Camera.DeviceCamera"):
        cam = Camera(1, [0, 0], password="pw")
        assert cam.has_password() is True

        cam.remove_password()
        assert cam.has_password() is False
        assert cam.verify_password("anything") is True  # no password required


# ----------------------------------------------------------------------
# Enable / Disable
# ----------------------------------------------------------------------
def test_enable_disable():
    with patch("safehome.cameras.Camera.DeviceCamera"):
        cam = Camera(1, [0, 0], is_enabled=0)

        assert cam.is_enabled() is False
        cam.enable()
        assert cam.is_enabled() is True
        cam.disable()
        assert cam.is_enabled() is False


# ----------------------------------------------------------------------
# Device Delegation — get_view, pan, zoom
# ----------------------------------------------------------------------
def test_camera_operations_enabled_only():
    with patch("safehome.cameras.Camera.DeviceCamera") as MockDev:
        dev = MockDev.return_value

        dev.get_view.return_value = "img"
        dev.pan_right.return_value = True
        dev.pan_left.return_value = True
        dev.zoom_in.return_value = True
        dev.zoom_out.return_value = True

        cam = Camera(1, [0, 0], is_enabled=1)

        assert cam.get_view() == "img"
        assert cam.pan_right() is True
        assert cam.pan_left() is True
        assert cam.zoom_in() is True
        assert cam.zoom_out() is True


def test_camera_operations_disabled():
    with patch("safehome.cameras.Camera.DeviceCamera") as MockDev:
        cam = Camera(1, [0, 0], is_enabled=0)

        assert cam.get_view() is None
        assert cam.pan_right() is False
        assert cam.pan_left() is False
        assert cam.zoom_in() is False
        assert cam.zoom_out() is False


# ----------------------------------------------------------------------
# stop()
# ----------------------------------------------------------------------
def test_stop_calls_device_stop():
    with patch("safehome.cameras.Camera.DeviceCamera") as MockDev:
        dev = MockDev.return_value
        cam = Camera(1, [0, 0])
        cam.stop()
        dev.stop.assert_called_once()


# ----------------------------------------------------------------------
# to_dict()
# ----------------------------------------------------------------------
def test_to_dict():
    with patch("safehome.cameras.Camera.DeviceCamera") as MockDev:
        dev = MockDev.return_value
        dev.zoom = 4
        dev.pan = 9

        cam = Camera(7, [5, 6], is_enabled=1, password="pw")
        d = cam.to_dict()

        assert d["camera_id"] == 7
        assert d["location"] == [5, 6]
        assert d["is_enabled"] == 1
        assert d["password"] == "pw"
        assert d["zoom"] == 2
        assert d["pan"] == 0


# ----------------------------------------------------------------------
# from_dict()
# ----------------------------------------------------------------------
def test_from_dict_roundtrip():
    with patch("safehome.cameras.Camera.DeviceCamera"):
        orig = Camera(2, [10, 20], is_enabled=1, password="pw", zoom=5, pan=3)
        d = orig.to_dict()

        new_cam = Camera.from_dict(d)

        assert new_cam.get_id() == 2
        assert new_cam.get_location() == [10, 20]
        assert new_cam.is_enabled() is True
        assert new_cam.verify_password("pw")
        assert new_cam._device.zoom == d["zoom"]
        assert new_cam._device.pan == d["pan"]
