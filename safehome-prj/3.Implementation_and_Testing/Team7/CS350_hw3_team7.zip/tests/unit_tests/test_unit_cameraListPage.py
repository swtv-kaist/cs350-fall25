# test_unit_cameraListPage.py
import tkinter as tk
import pytest
from safehome.web.pages.camera.cameraListPage import CameraListPage


@pytest.fixture
def root():
    root = tk.Tk()
    root.withdraw()
    yield root
    root.destroy()


def test_camera_buttons_render(root):
    # Mock camera list
    mock_cameras = [
        {"id": "Cam1", "hasPassword": False},
        {"id": "Cam2", "hasPassword": True},
    ]

    page = CameraListPage(root, page_id=0, switch_page_callback=lambda x: None)
    page.camera_list = mock_cameras
    page._update_camera_buttons()

    children = page.camera_container.winfo_children()
    # There should be 2 buttons (no label "No cameras found")
    assert all(isinstance(c, tk.Button) for c in children)
    assert len(children) == 2
    assert children[0].cget("text") == "Cam1"
    assert children[1].cget("text") == "Cam2"
