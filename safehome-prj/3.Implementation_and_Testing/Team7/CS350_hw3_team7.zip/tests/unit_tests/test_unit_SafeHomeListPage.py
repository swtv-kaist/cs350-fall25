import pytest
import tkinter as tk
from safehome.web.pages.safeHomeModeListPage import SafeHomeModeListPage


@pytest.fixture
def root():
    root = tk.Tk()
    root.withdraw()
    yield root
    root.destroy()


def test_widgets_created(root):
    page = SafeHomeModeListPage(root)
    assert isinstance(page.current_mode_label, tk.Label)
    assert isinstance(page.selected_mode, tk.StringVar)
    assert page.selected_mode.get() == "Home"
    assert len(page.modes) > 0


def test_change_mode_logic(root):
    called = {}

    def on_change_mode(mode_name):
        called["mode"] = mode_name

    page = SafeHomeModeListPage(root, on_change_mode_callback=on_change_mode)

    # Change selected mode
    page.selected_mode.set("Away")
    page._on_change_mode_pressed()

    # Label should update
    assert page.current_mode_label.cget("text") == "Current Mode: Away"
    # Callback should be called
    assert called.get("mode") == "Away"
