# test_alarm.py
import pytest
from safehome.alarm.Alarm import Alarm


@pytest.fixture
def alarm():
    """Return a fresh Alarm instance for each test."""
    return Alarm()


def test_initial_state(alarm):
    """Test that a new alarm starts as not alerting."""
    assert alarm.read_alarm() is False


def test_up_alarm_sets_alert(alarm):
    """Test that up_alarm sets the alarm."""
    alarm.up_alarm()
    assert alarm.read_alarm() is True


def test_down_alarm_resets_alert(alarm):
    """Test that down_alarm clears the alarm."""
    alarm.up_alarm()
    alarm.down_alarm()
    assert alarm.read_alarm() is False


def test_multiple_operations(alarm):
    """Test combination of up and down operations."""
    alarm.up_alarm()
    assert alarm.read_alarm() is True
    alarm.down_alarm()
    assert alarm.read_alarm() is False
    alarm.up_alarm()
    assert alarm.read_alarm() is True
