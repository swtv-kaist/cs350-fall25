import json
from unittest.mock import MagicMock, mock_open, patch
from safehome.storage.StorageManager import StorageManager


def test_storage_manager_file_path():
    sm = StorageManager("TestStore")
    p = sm._file("users")
    assert str(p).endswith("TestStore/users.json")


def test_load_json_file_not_exist():
    sm = StorageManager("TestStore")

    fake_path = MagicMock()
    fake_path.exists.return_value = False

    with patch.object(sm, "_file", return_value=fake_path):
        result = sm.load_json("whatever")
        assert result is None


def test_load_json_empty_file():
    sm = StorageManager("TestStore")

    fake_path = MagicMock()
    fake_path.exists.return_value = True
    fake_path.stat.return_value.st_size = 0

    with patch.object(sm, "_file", return_value=fake_path):
        result = sm.load_json("empty")
        assert result is None


def test_load_json_valid():
    sm = StorageManager("TestStore")

    fake_data = {"k": 1}
    fake_file = mock_open(read_data=json.dumps(fake_data))

    fake_path = MagicMock()
    fake_path.exists.return_value = True
    fake_path.stat.return_value.st_size = 10

    with patch.object(sm, "_file", return_value=fake_path):
        with patch("builtins.open", fake_file):
            result = sm.load_json("data")
            assert result == fake_data


def test_save_json_success():
    sm = StorageManager("TestStore")

    fake_file = mock_open()
    with patch("builtins.open", fake_file):
        ok = sm.save_json("abc", {"a": 1})
        assert ok is True


def test_save_json_failure():
    sm = StorageManager("TestStore")

    with patch("builtins.open", side_effect=Exception("failure")):
        ok = sm.save_json("abc", {"a": 1})
        assert ok is False
