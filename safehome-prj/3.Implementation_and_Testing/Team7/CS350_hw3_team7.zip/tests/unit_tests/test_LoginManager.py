import pytest
from safehome.login.LoginManager import LoginManager
from safehome.login.UserEntry import UserEntry


@pytest.fixture
def login_manager_no_storage():
    """LoginManager without persisting storage for pure unit tests"""
    mgr = LoginManager(storage_dir="TempStorage")  # temp storage, but we won't test persistence
    # Prepopulate users
    user1 = UserEntry(username="alice", password="secret1", type="admin")
    user2 = UserEntry(username="bob", password="secret2", type="guest")
    mgr._users = [user1, user2]
    return mgr


def test_login_success(login_manager_no_storage):
    success, user = login_manager_no_storage.login("alice", "secret1")
    assert success is True
    assert user.getUsername() == "alice"
    assert "alice" in login_manager_no_storage.active_sessions


def test_login_fail_wrong_password(login_manager_no_storage):
    success, user = login_manager_no_storage.login("alice", "wrong")
    assert success is False
    assert user is None


def test_login_fail_unknown_user(login_manager_no_storage):
    success, user = login_manager_no_storage.login("charlie", "whatever")
    assert success is False
    assert user is None


def test_logout_success(login_manager_no_storage):
    login_manager_no_storage.login("bob", "secret2")
    user = login_manager_no_storage.getUserbyUsername("bob")
    result = login_manager_no_storage.logout(user)
    assert result is True
    assert "bob" not in login_manager_no_storage.active_sessions


def test_logout_fail_not_logged_in(login_manager_no_storage):
    user = login_manager_no_storage.getUserbyUsername("alice")
    result = login_manager_no_storage.logout(user)
    assert result is False


def test_change_password_fail_short(login_manager_no_storage):
    login_manager_no_storage.login("alice", "secret1")
    user = login_manager_no_storage.getUserbyUsername("alice")
    result = login_manager_no_storage.change_password(user, "123")
    assert result is False


def test_change_password_fail_not_logged_in(login_manager_no_storage):
    user = login_manager_no_storage.getUserbyUsername("bob")
    result = login_manager_no_storage.change_password(user, "longenough")
    assert result is False
