import pytest
import tkinter as tk
from safehome.web.pages.setNewUserPage import SetNewUserPage


@pytest.fixture
def root():
    root = tk.Tk()
    root.withdraw()  # hide main window during tests
    yield root
    root.destroy()


def test_submit_success(root):
    submitted = {}

    def submit_cb(username, password, user_type, image_path):
        submitted.update(
            {"username": username, "password": password, "type": user_type, "image": image_path}
        )

    # Use a dummy image callback
    page = SetNewUserPage(
        root, submit_callback=submit_cb, user_image_callback=lambda: "/dummy/path.png"
    )
    page._test_mode = True  # prevent window destruction

    # Fill entries
    page.username_entry.insert(0, "user1")
    page.password_entry.insert(0, "1234")
    page.confirm_password_entry.insert(0, "1234")
    page.user_type_var.set("Guest")

    # Simulate selecting image
    page._select_user_image()

    page._submit()

    assert submitted["username"] == "user1"
    assert submitted["password"] == "1234"
    assert submitted["type"] == "Guest"
    assert submitted["image"] == "/dummy/path.png"


def test_submit_validation(root):
    submitted = {}

    page = SetNewUserPage(root, submit_callback=lambda *args: submitted.update({"called": True}))
    page._test_mode = True  # prevent window destruction

    # Empty fields
    page._submit()
    assert "called" not in submitted

    # Password mismatch
    page.username_entry.insert(0, "user1")
    page.password_entry.insert(0, "123")
    page.confirm_password_entry.insert(0, "321")
    page.user_image_path = "/dummy/path.png"
    page._submit()
    assert "called" not in submitted
