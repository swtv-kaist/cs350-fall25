from unittest.mock import MagicMock, patch

from safehome.system.System import System


def _make_mock_sensor(armed=False):
    sensor = MagicMock()
    sensor.isArmed.return_value = armed
    return sensor


def test_turn_on_off_and_is_on():
    system = System(storage_dir="TempStorage")

    system.turn_off()
    assert system.is_on() is False

    system.turn_on()
    assert system.is_on() is True


def test_arm_sensors_valid_ids_calls_arm_and_persists():
    system = System(storage_dir="TempStorage")

    s1 = _make_mock_sensor()
    s2 = _make_mock_sensor()

    system._sensor_mng.getSensorById = MagicMock(side_effect=[s1, s2])
    system._sensor_mng.save_sensors = MagicMock(return_value=True)

    result = system.armSensors([1, 2])

    assert result is True
    assert s1.arm.called
    assert s2.arm.called
    system._sensor_mng.save_sensors.assert_called_once()


def test_arm_sensors_invalid_id_range_returns_false_and_does_not_call_manager():
    system = System(storage_dir="TempStorage")

    system._sensor_mng.getSensorById = MagicMock()
    system._sensor_mng.save_sensors = MagicMock()

    result = system.armSensors([0, 11])

    assert result is False
    system._sensor_mng.getSensorById.assert_not_called()
    system._sensor_mng.save_sensors.assert_not_called()


def test_disarm_sensors_valid_ids_calls_disarm_and_persists():
    system = System(storage_dir="TempStorage")

    s1 = _make_mock_sensor(armed=True)
    s2 = _make_mock_sensor(armed=True)

    system._sensor_mng.getSensorById = MagicMock(side_effect=[s1, s2])
    system._sensor_mng.save_sensors = MagicMock(return_value=True)

    result = system.disarmSensors([1, 2])

    assert result is True
    assert s1.disarm.called
    assert s2.disarm.called
    system._sensor_mng.save_sensors.assert_called_once()


@patch("safehome.system.System.time.sleep", return_value=None)
def test_make_panic_phone_call_uses_system_settings_and_timestamp(mock_sleep):
    system = System(storage_dir="TempStorage")

    mock_sys_settings = MagicMock()
    mock_sys_settings.getAlarmTimeBeforePhoneCall.return_value = 0.1
    mock_sys_settings.getPanicPhoneNumber.return_value = "010-1234-5678"
    system._config_mng.getSystemSettings = MagicMock(return_value=mock_sys_settings)

    msg, phone = system.makePanicPhoneCall()

    mock_sleep.assert_called_once_with(0.1)
    assert phone == "010-1234-5678"
    assert "PANIC PHONE CALL to" in msg["description"]
    assert "010-1234-5678" in msg["description"]
