import pytest
import tkinter as tk
from safehome.web.pages.safeHomeModeConfigPage import SafeHomeModeConfigPage


@pytest.fixture
def root():
    root = tk.Tk()
    root.withdraw()
    yield root
    root.destroy()


@pytest.fixture
def selected_mode():
    return {"name": "Night Mode", "sensor_list": ["sensor1", "sensor2"]}


def test_widgets_created(root, selected_mode):
    page = SafeHomeModeConfigPage(root, selected_mode)
    assert isinstance(page.id_label, tk.Label)
    assert isinstance(page.sensor_frame, tk.LabelFrame)
    assert isinstance(page.enable_frame, tk.LabelFrame)
    assert isinstance(page.status_label, tk.Label)


def test_update_mode_info(root, selected_mode):
    page = SafeHomeModeConfigPage(root, selected_mode)
    page._update_mode_info()
    assert page.id_label.cget("text") == f"Mode: {selected_mode['name']}"


def test_populate_sensors(root, selected_mode):
    page = SafeHomeModeConfigPage(root, selected_mode)
    page._populate_sensors()
    # Check that Labels for each sensor exist
    labels = [w for w in page.sensor_frame.winfo_children() if isinstance(w, tk.Label)]
    assert len(labels) == len(selected_mode["sensor_list"])
