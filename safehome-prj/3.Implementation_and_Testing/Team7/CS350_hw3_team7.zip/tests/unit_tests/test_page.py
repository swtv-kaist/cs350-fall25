import pytest
import tkinter as tk
from unittest.mock import Mock, patch
from safehome.web.page import Page


@pytest.fixture
def root():
    """Create a Tk root for testing."""
    root = tk.Tk()
    yield root
    root.destroy()


@pytest.fixture
def mock_callback():
    """Create a mock callback function."""
    return Mock()


@pytest.fixture
def page(root, mock_callback):
    """Create a Page instance for testing."""
    return Page(root, page_id=1, switch_page_callback=mock_callback)


class TestPageInitialization:
    """Test Page initialization."""

    def test_init_with_defaults(self, root):
        """Test initialization with default parameters."""
        page = Page(root)
        assert page.root == root
        assert page._id == 0
        assert page.switch_page_callback is None
        assert page.frame is not None
        assert page.parameters is None
        assert page.video_frames == []
        assert page.prev_page is None

    def test_init_with_custom_params(self, root, mock_callback):
        """Test initialization with custom parameters."""
        page = Page(root, page_id=5, switch_page_callback=mock_callback)
        assert page._id == 5
        assert page.switch_page_callback == mock_callback

    def test_frame_created(self, page):
        """Test that frame is created and placed."""
        assert isinstance(page.frame, tk.Frame)
        assert page.frame.winfo_parent() == str(page.root)

    def test_label_created(self, page):
        """Test that label is created with correct text."""
        assert isinstance(page.label, tk.Label)
        assert page.label.cget("text") == "Page 1"

    def test_status_label_created(self, page):
        """Test that status label is created."""
        assert isinstance(page.status_label, tk.Label)
        assert page.status_label.cget("text") == ""
        assert page.status_label.cget("fg") == "red"


class TestPageIDManagement:
    """Test page ID getter and setter."""

    def test_get_id(self, page):
        """Test getID method."""
        assert page.getID() == 1

    def test_set_id(self, page):
        """Test setID method."""
        page.setID(10)
        assert page._id == 10
        assert page.getID() == 10

    def test_set_id_updates_label(self, page):
        """Test that setID updates the label."""
        page.setID(99)
        assert "Page 99" in page.label.cget("text")


class TestPageDrawing:
    """Test page drawing and visibility."""

    @patch("builtins.print")
    def test_draw_page(self, mock_print, page):
        """Test drawPage method."""
        page.drawPage()
        mock_print.assert_called_with("[DEBUG] Drawing Page 1")

    def test_draw_page_raises_frame(self, page):
        """Test that drawPage raises the frame to front."""
        # Create another frame to ensure page.frame can be raised
        other_frame = tk.Frame(page.root)
        other_frame.place(relx=0, rely=0, relwidth=1, relheight=1)
        other_frame.lift()

        page.drawPage()
        # After drawPage, page.frame should be on top
        # Note: Testing tkraise is tricky, so we mainly test it doesn't error


class TestUpdateLabel:
    """Test label update functionality."""

    def test_update_label_basic(self, page):
        """Test update_label with no parameters."""
        page.update_label()
        assert page.label.cget("text") == "Page 1"

    def test_update_label_with_parameters(self, page):
        """Test update_label with parameters."""
        page.parameters = {"key": "value"}
        page.update_label()
        expected = "Page 1 Params: {'key': 'value'}"
        assert page.label.cget("text") == expected


class TestHeaderCallbacks:
    """Test header button callbacks."""

    @patch("builtins.print")
    def test_on_home(self, mock_print, page):
        """Test _on_home callback."""
        page._on_home()
        mock_print.assert_called_with("Home clicked")
        page.switch_page_callback.assert_called_once_with("home")

    @patch("builtins.print")
    def test_on_security(self, mock_print, page):
        """Test _on_security callback."""
        page._on_security()
        mock_print.assert_called_with("Security clicked")
        page.switch_page_callback.assert_called_once_with("security")

    @patch("builtins.print")
    def test_on_camera(self, mock_print, page):
        """Test _on_camera callback."""
        page._on_camera()
        mock_print.assert_called_with("Camera clicked")
        page.switch_page_callback.assert_called_once_with("camera")

    @patch("builtins.print")
    def test_on_user(self, mock_print, page):
        """Test _on_user callback."""
        page._on_user()
        mock_print.assert_called_with("User clicked")
        page.switch_page_callback.assert_called_once_with("user_settings")

    @patch("builtins.print")
    def test_on_logout(self, mock_print, page):
        """Test _on_logout callback."""
        page._on_logout()
        mock_print.assert_called_with("Log out clicked")
        page.switch_page_callback.assert_called_once_with("login")

    def test_button_commands_connected(self, page):
        """Test that button commands are properly connected."""
        # Invoke buttons programmatically
        page.home_btn.invoke()
        page.switch_page_callback.assert_called_with("home")

        page.security_btn.invoke()
        page.switch_page_callback.assert_called_with("security")

        page.camera_btn.invoke()
        page.switch_page_callback.assert_called_with("camera")


class TestParameterManagement:
    """Test parameter setting and handling."""

    @patch("builtins.print")
    def test_set_page_parameters(self, mock_print, page):
        """Test setPageParameters method."""
        params = {"user": "test", "level": 5}
        page.setPageParameters(params)

        assert page.parameters == params
        mock_print.assert_called_with(
            "[DEBUG] Page 1 received parameters: {'user': 'test', 'level': 5}"
        )

    def test_set_page_parameters_updates_label(self, page):
        """Test that setPageParameters updates the label."""
        params = {"setting": "value"}
        page.setPageParameters(params)
        assert "Params:" in page.label.cget("text")


class TestMessageReceiving:
    """Test message receiving functionality."""

    @patch("builtins.print")
    def test_receive_message(self, mock_print, page):
        """Test receive_message method."""
        message = "Test message"
        page.receive_message(message)
        mock_print.assert_called_with("[DEBUG] Page 1 received system message: Test message")

    @patch("builtins.print")
    def test_receive_video(self, mock_print, page):
        """Test receive_video method."""
        frames = [1, 2, 3, 4, 5]
        page.receive_video(frames)

        assert page.video_frames == frames
        mock_print.assert_called_with("[DEBUG] Page 1 received 5 video frames")

    def test_receive_empty_video(self, page):
        """Test receiving empty video frames."""
        page.receive_video([])
        assert page.video_frames == []


class TestReturnFunctionality:
    """Test return to previous page functionality."""

    @patch("builtins.print")
    def test_return_with_prev_page(self, mock_print, page):
        """Test _return with previous page set."""
        page.prev_page = "home"
        page._return()

        mock_print.assert_called_with("Returning to previous page")
        page.switch_page_callback.assert_called_once_with("home")

    @patch("builtins.print")
    def test_return_without_prev_page(self, mock_print, page):
        """Test _return without previous page set."""
        page.prev_page = None
        page._return()

        mock_print.assert_called_with("Returning to previous page")
        assert page.status_label.cget("text") == "No previous page to return to."
        assert page.status_label.cget("fg") == "red"


class TestIntegration:
    """Integration tests for Page class."""

    def test_full_workflow(self, root, mock_callback):
        """Test a full workflow: create, set params, draw, return."""
        page = Page(root, page_id=2, switch_page_callback=mock_callback)

        # Set parameters
        params = {"test": True}
        page.setPageParameters(params)
        assert page.parameters == params

        # Draw page
        page.drawPage()

        # Set previous page and return
        page.prev_page = "login"
        page._return()
        mock_callback.assert_called_with("login")

    def test_multiple_pages(self, root, mock_callback):
        """Test creating multiple pages."""
        page1 = Page(root, page_id=1, switch_page_callback=mock_callback)
        page2 = Page(root, page_id=2, switch_page_callback=mock_callback)

        assert page1.getID() == 1
        assert page2.getID() == 2

        page1.drawPage()
        page2.drawPage()

        # Both pages should exist and be accessible


class TestEdgeCases:
    """Test edge cases and error conditions."""

    def test_none_callback_doesnt_crash(self, root):
        """Test that None callback doesn't cause errors."""
        page = Page(root, page_id=0, switch_page_callback=None)
        # These should not crash even with None callback
        # (they will fail if invoked, but creation should work)
        assert page.switch_page_callback is None

    def test_negative_page_id(self, root, mock_callback):
        """Test page with negative ID."""
        page = Page(root, page_id=-1, switch_page_callback=mock_callback)
        assert page.getID() == -1
        assert "Page -1" in page.label.cget("text")

    def test_large_video_frames(self, page):
        """Test receiving large video frame list."""
        large_frames = list(range(1000))
        page.receive_video(large_frames)
        assert len(page.video_frames) == 1000

    def test_special_characters_in_parameters(self, page):
        """Test parameters with special characters."""
        params = {"key": "value with spaces", "number": 123, "nested": {"a": 1}}
        page.setPageParameters(params)
        assert page.parameters == params
