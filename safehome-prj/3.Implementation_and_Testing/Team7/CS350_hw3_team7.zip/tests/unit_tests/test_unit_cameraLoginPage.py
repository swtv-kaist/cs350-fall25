# test_unit_cameraLoginPage.py
import tkinter as tk
import pytest
from safehome.web.pages.camera.cameraLoginPage import CameraLoginPage


@pytest.fixture
def root():
    root = tk.Tk()
    root.withdraw()
    yield root
    root.destroy()


def test_camera_login_correct_password(root, monkeypatch):
    # Mock camera and callback
    cam = {"id": "Cam1", "password": "1234"}
    callback_called = []

    def mock_auth(password, camera):
        callback_called.append((password, camera))
        return password == camera["password"]

    # Mock SingleCameraPage to avoid opening window
    called_pages = []

    class MockSingleCameraPage:
        def __init__(self, root, selected_camera):
            called_pages.append(selected_camera)

        def drawPage(self):
            called_pages.append("drawn")

    monkeypatch.setattr(
        "safehome.web.pages.camera.cameraLoginPage.SingleCameraPage",
        MockSingleCameraPage,
    )

    page = CameraLoginPage(root, selected_camera=cam, camera_auth_callback=mock_auth)
    page.password_var.set("1234")
    page._submit()

    # Check callback called
    assert callback_called[0] == ("1234", cam)
    # Check SingleCameraPage was instantiated and drawPage called
    assert called_pages[0] == cam
    assert called_pages[1] == "drawn"


def test_camera_login_incorrect_password(root):
    cam = {"id": "Cam1", "password": "1234"}
    page = CameraLoginPage(root, selected_camera=cam)
    page.password_var.set("wrong")
    page._submit()
    assert page.status_label.cget("text") == "Incorrect password."
