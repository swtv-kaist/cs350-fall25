import pytest
import tkinter as tk
from safehome.web.pages.safeHomeModeRemovePage import SafeHomeModeRemovePage


@pytest.fixture
def root():
    root = tk.Tk()
    root.withdraw()
    yield root
    root.destroy()


@pytest.fixture
def selected_mode():
    return {"name": "Night Mode", "sensor_list": ["sensor1", "sensor2"]}


def test_widgets_created(root, selected_mode):
    page = SafeHomeModeRemovePage(root, selected_mode)
    assert isinstance(page.id_label, tk.Label)
    assert isinstance(page.sensor_frame, tk.LabelFrame)
    assert isinstance(page.status_label, tk.Label)
    assert isinstance(page.sensor_vars, dict)
    assert len(page.sensor_vars) == len(selected_mode["sensor_list"])


def test_update_mode_info(root, selected_mode):
    page = SafeHomeModeRemovePage(root, selected_mode)
    page._update_mode_info()
    assert page.id_label.cget("text") == f"Mode: {selected_mode['name']}"


def test_populate_sensors(root, selected_mode):
    page = SafeHomeModeRemovePage(root, selected_mode)
    page._populate_sensors()
    # Check that checkbuttons for each sensor exist
    checkbuttons = [w for w in page.sensor_frame.winfo_children() if isinstance(w, tk.Checkbutton)]
    assert len(checkbuttons) == len(selected_mode["sensor_list"])
