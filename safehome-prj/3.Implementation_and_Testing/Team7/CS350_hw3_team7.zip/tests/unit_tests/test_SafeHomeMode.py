import pytest

from safehome.config.SafeHomeMode import SafeHomeMode


class DummySensor:
    def __init__(self, sensor_type="motion", name="sensor", sensor_id=1, location=None):
        self._type = sensor_type
        self._name = name
        self._id = sensor_id
        self._location = location or [0, 0, 1, 1]

    def get_type(self):
        return self._type

    def get_name(self):
        return self._name

    def get_id(self):
        return self._id

    def get_location(self):
        return self._location


@pytest.fixture(autouse=True)
def reset_mode_counter():
    SafeHomeMode._mode_id_counter = 0
    yield
    SafeHomeMode._mode_id_counter = 0


def test_auto_id_assignment():
    mode1 = SafeHomeMode("Home")
    mode2 = SafeHomeMode("Away")

    assert mode1.get_id() == 1
    assert mode2.get_id() == 2


def test_respects_existing_id_and_updates_counter():
    persisted = SafeHomeMode("Persisted", mode_id=5)
    assert persisted.get_id() == 5
    assert SafeHomeMode._mode_id_counter == 5

    new_mode = SafeHomeMode("New Mode")
    assert new_mode.get_id() == 6


def test_setters_and_getters_with_sensor_list():
    sensors = [DummySensor(name="s1"), DummySensor(name="s2")]
    mode = SafeHomeMode("Initial", sensor_list=sensors)

    assert mode.get_name() == "Initial"
    assert mode.get_sensor_list() == sensors

    new_sensors = [DummySensor(name="s3")]
    mode.set_name("Updated")
    mode.set_sensor_list(new_sensors)

    assert mode.get_name() == "Updated"
    assert mode.get_sensor_list() == new_sensors
    assert mode.get_sensor_list() is not new_sensors  # defensive copy


def test_to_dict_serializes_sensor_details():
    sensors = [
        DummySensor(sensor_type="motion", name="m1", sensor_id=1, location=[1, 2, 3, 4]),
        DummySensor(sensor_type="door", name="d1", sensor_id=2, location=[4, 5, 6, 7]),
    ]
    mode = SafeHomeMode("Travel", sensor_list=sensors)

    data = mode.to_dict()

    assert data["name"] == "Travel"
    assert data["id"] == mode.get_id()
    assert data["sensor_list"] == [
        {
            "sensor_type": "motion",
            "sensor_name": "m1",
            "sensor_id": 1,
            "sensor_location": [1, 2, 3, 4],
        },
        {
            "sensor_type": "door",
            "sensor_name": "d1",
            "sensor_id": 2,
            "sensor_location": [4, 5, 6, 7],
        },
    ]


def test_from_dict_builds_sensors(monkeypatch):
    constructed = []

    class SensorStub:
        def __init__(self, sensor_type, sensor_name, sensor_id, sensor_location):
            self._type = sensor_type
            self._name = sensor_name
            self._id = sensor_id
            self._location = sensor_location
            constructed.append(self)

        def get_type(self):
            return self._type

        def get_name(self):
            return self._name

        def get_id(self):
            return self._id

        def get_location(self):
            return self._location

    monkeypatch.setattr("safehome.config.SafeHomeMode.Sensor", SensorStub)

    payload = {
        "name": "Overnight",
        "id": 9,
        "sensor_list": [
            {
                "sensor_type": "motion",
                "sensor_name": "hall-motion",
                "sensor_id": 77,
                "sensor_location": [0, 0, 2, 2],
            }
        ],
    }

    mode = SafeHomeMode.from_dict(payload)

    assert mode.get_name() == "Overnight"
    assert mode.get_id() == 9
    assert len(mode.get_sensor_list()) == 1
    assert mode.get_sensor_list()[0] is constructed[0]
