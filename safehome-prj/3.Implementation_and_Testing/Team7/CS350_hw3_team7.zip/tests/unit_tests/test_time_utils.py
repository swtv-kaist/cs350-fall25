# tests/unit_tests/test_time_utils.py

from datetime import datetime
from safehome.utils.time_utils import current_timestamp


def test_current_timestamp_format_and_validity():
    """
    Unit test for current_timestamp().
    Verifies:
    - Output is a string
    - Matches expected timestamp format
    - Can be parsed back by datetime.strptime()
    - Timestamp is close to actual system time
    """
    ts = current_timestamp()

    # 1. type check
    assert isinstance(ts, str)

    # 2. format check
    try:
        parsed = datetime.strptime(ts, "%Y-%m-%d %H:%M:%S")
    except ValueError:
        raise AssertionError("Timestamp does not match expected format 'YYYY-MM-DD HH:MM:SS'")

    # 3. timestamp must be close to now (within ±2 seconds)
    now = datetime.now()
    delta = abs((now - parsed).total_seconds())
    assert delta < 2, f"Timestamp drift too large: {delta} seconds"
