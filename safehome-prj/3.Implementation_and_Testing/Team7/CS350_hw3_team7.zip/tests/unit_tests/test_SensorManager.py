from unittest.mock import MagicMock
from safehome.sensors.SensorManager import SensorManager
from safehome.sensors.Sensor import Sensor


def test_sensor_manager_load_sensors():
    mock_storage = MagicMock()
    mock_storage.load_json.return_value = [
        {
            "sensor_type": "motion",
            "sensor_name": "m1",
            "sensor_id": 1,
            "sensor_location": [0, 0, 5, 5],
            "is_armed": 1,
        }
    ]

    manager = SensorManager.__new__(SensorManager)
    manager.storage = mock_storage
    manager._sensors = []
    SensorManager._load_sensors(manager)

    assert len(manager.getAllSensors()) == 1
    sensor = manager.getAllSensors()[0]
    assert sensor.get_name() == "m1"
    assert sensor.get_id() == 1
    assert sensor.isArmed() is True


def test_get_sensor_by_name_and_id():
    s1 = Sensor("motion", "m1", 1, [0, 0, 5, 5])
    s2 = Sensor("door", "d1", 2, [1, 1, 6, 6])

    manager = SensorManager.__new__(SensorManager)
    manager._sensors = [s1, s2]

    assert manager.getSensorbyName("m1") is s1
    assert manager.getSensorbyName("unknown") is None

    assert manager.getSensorById(2) is s2
    assert manager.getSensorById(5) is None


def test_arm_disarm_all_sensors_calls_device_methods():
    s1 = Sensor("motion", "m1", 1, [0, 0, 5, 5])
    s2 = Sensor("door", "d1", 2, [1, 1, 6, 6])

    s1._device.arm = MagicMock()
    s2._device.arm = MagicMock()
    s1._device.disarm = MagicMock()
    s2._device.disarm = MagicMock()

    manager = SensorManager.__new__(SensorManager)
    manager._sensors = [s1, s2]
    manager.save_sensors = MagicMock()

    manager.armAllSensors()

    s1._device.arm.assert_called_once()
    s2._device.arm.assert_called_once()
    manager.save_sensors.assert_called_once()

    manager.save_sensors = MagicMock()
    manager.disarmAllSensors()
    s1._device.disarm.assert_called_once()
    s2._device.disarm.assert_called_once()
    manager.save_sensors.assert_called_once()


def test_read_all_sensors():
    s1 = Sensor("motion", "m1", 1, [0, 0, 5, 5])
    s2 = Sensor("door", "d1", 2, [1, 1, 6, 6])

    s1.read = MagicMock(return_value=True)
    s2.read = MagicMock(return_value=False)

    manager = SensorManager.__new__(SensorManager)
    manager._sensors = [s1, s2]

    result = manager.readAllSensors()
    assert result == [True, False]
