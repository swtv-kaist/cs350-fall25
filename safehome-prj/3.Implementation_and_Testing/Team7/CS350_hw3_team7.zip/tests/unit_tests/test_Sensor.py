from safehome.sensors.Sensor import Sensor


def test_sensor_initialization_and_getters():
    s = Sensor("motion", "motion1", 1, [0, 0, 10, 10], is_armed=True)

    assert s.get_type() == "motion"
    assert s.get_name() == "motion1"
    assert s.get_id() == 1
    assert s.get_location() == [0, 0, 10, 10]
    assert s.isArmed() is True


def test_sensor_set_location():
    s = Sensor("door", "door1", 2, [0, 0, 5, 5])
    assert s.set_location([1, 2, 3, 4]) is True
    assert s.get_location() == [1, 2, 3, 4]

    # Invalid locations
    assert s.set_location([1, 2, 3]) is False
    assert s.set_location("invalid") is False
    assert s.set_location([1, 2, 3, "a"]) is False


def test_sensor_arm_disarm():
    s = Sensor("window", "win1", 3, [0, 0, 5, 5])
    s.arm()
    assert s.isArmed() is True
    s.disarm()
    assert s.isArmed() is False


def test_sensor_to_dict_and_from_dict():
    s1 = Sensor("motion", "m1", 4, [0, 0, 10, 10], is_armed=True)
    d = s1.to_dict()

    assert d["sensor_type"] == "motion"
    assert d["sensor_name"] == "m1"
    assert d["sensor_id"] == 4
    assert d["sensor_location"] == [0, 0, 10, 10]
    assert d["is_armed"] == 1

    # recreate from dict
    s2 = Sensor.from_dict(d)
    assert s2.get_type() == "motion"
    assert s2.get_name() == "m1"
    assert s2.get_id() == 4
    assert s2.get_location() == [0, 0, 10, 10]
    assert s2.isArmed() is True
