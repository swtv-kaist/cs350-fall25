import pytest
import tkinter as tk
from safehome.web.pages.loginPage import LoginPage


@pytest.fixture(scope="module")
def root():
    root = tk.Tk()
    yield root
    root.destroy()


def test_widgets_created(root):
    """Test that username, password entries and login button exist"""
    page = LoginPage(root)

    assert isinstance(page.username_entry, tk.Entry)
    assert isinstance(page.password_entry, tk.Entry)
    assert isinstance(page.login_button, tk.Button)
    assert isinstance(page.status_label, tk.Label)


def test_clear_entry(root):
    """Test that clear_entry clears the input fields"""
    page = LoginPage(root)
    page.username_entry.insert(0, "user")
    page.password_entry.insert(0, "pass")

    page.clear_entry()
    assert page.username_entry.get() == ""
    assert page.password_entry.get() == ""


def test_on_login_empty_fields(root):
    """Test _on_login with empty username/password"""
    page = LoginPage(root)
    page.clear_entry()
    page._on_login()
    assert "Please enter both username and password" in page.status_label.cget("text")


def test_on_login_wrong_credentials(root):
    """Test _on_login with incorrect credentials"""

    def fake_system_callback(u, p):
        return False

    page = LoginPage(root, system_callback=fake_system_callback)
    page.username_entry.insert(0, "user")
    page.password_entry.insert(0, "wrongpass")
    page._on_login()
    assert "Incorrect username or password" in page.status_label.cget("text")


def test_on_login_correct_credentials(root):
    """Test _on_login with correct credentials and next_page_callback"""
    called = {}

    def fake_system_callback(u, p):
        return True

    def next_page():
        called["next"] = True

    page = LoginPage(root, system_callback=fake_system_callback, next_page_callback=next_page)
    page.username_entry.insert(0, "user")
    page.password_entry.insert(0, "pass")
    page._on_login()

    assert "Login successful" in page.status_label.cget("text")
    assert called.get("next", False) is True
