import pytest
import tkinter as tk
from safehome.web.pages.setUserNewPassPage import SetUserNewPassPage


@pytest.fixture
def root():
    root = tk.Tk()
    root.withdraw()  # hide main window during tests
    yield root
    root.destroy()


def test_submit_success(root):
    submitted = {}

    def submit_cb(new_pw):
        submitted["pw"] = new_pw

    page = SetUserNewPassPage(root, submit_callback=submit_cb)
    page._test_mode = True  # prevent window destruction

    page.new_pass_entry.insert(0, "5678")
    page.confirm_pass_entry.insert(0, "5678")
    page._submit()

    assert submitted["pw"] == "5678"


def test_submit_validation(root):
    submitted = {}

    page = SetUserNewPassPage(root, submit_callback=lambda pw: submitted.update({"called": True}))
    page._test_mode = True  # prevent window destruction

    # Empty fields
    page._submit()
    assert "called" not in submitted

    # Password mismatch
    page.new_pass_entry.insert(0, "abc")
    page.confirm_pass_entry.insert(0, "def")
    page._submit()
    assert "called" not in submitted
