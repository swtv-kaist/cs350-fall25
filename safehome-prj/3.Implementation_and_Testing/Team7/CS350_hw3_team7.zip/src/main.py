from multiprocessing import Process
import tkinter as tk

#entry point
from safehome.config.ConfigurationManager import ConfigurationManager

from safehome.web.webInterface import WebInterface
from safehome.controlPanel import MyControlPanel

import os
import sys

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)


def run_control_panel():
    root = tk.Tk()
    root.withdraw()

    app = MyControlPanel()
    app.mainloop()


def main():
    print("Starting SafeHome test...")
    config_mgr = ConfigurationManager()
    zones = config_mgr.getAllSafetyZones()
    print("Loaded zones:", zones)

    p = Process(target=run_control_panel)
    p.start()

    # WebInterface stays in main process
    webInterface = WebInterface()
    webInterface.run()

    p.join()


if __name__ == "__main__":
    main()
