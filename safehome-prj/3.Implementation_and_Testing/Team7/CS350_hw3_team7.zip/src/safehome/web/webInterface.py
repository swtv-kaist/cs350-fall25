import tkinter as tk
from typing import List
from .page import Page
import os

# Import all page classes here
# Initial Page class
from .pages.loginPage import LoginPage

# Base Page class
from .pages.homePage import HomePage
from .pages.userSettingPage import UserSettingPage
from .pages.securityPage import SecurityPage
from .pages.camera.cameraListPage import CameraListPage
from .pages.viewLogPage import ViewLogPage

# Security Child Pages
from .pages.floorPlan.floorPlanPage import FloorPlanPage
from .pages.floorPlan.safetyZoneListPage import SafetyZoneListPage
from .pages.safeHomeModeListPage import SafeHomeModeListPage

from .pages.camera.thumbnailViewPage import ThumbnailViewPage

# User Manager
from ..login.LoginManager import LoginManager

# Sensor manager
from ..sensors.SensorManager import SensorManager
from ..cameras.CameraManager import CameraManager

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
STORAGE_PATH = os.path.join(PROJECT_ROOT, "storage")

loginManager = LoginManager(storage_dir=STORAGE_PATH)

sensorManager = SensorManager(storage_dir=STORAGE_PATH)
cameraManager = CameraManager(storage_dir=STORAGE_PATH)


def device_info(deviceName):
    if "camera" in deviceName:
        cameraManager.load_cameras()
        camera_id = int(deviceName.replace("camera", ""))
        return cameraManager.get_camera_by_id(camera_id)
    else:
        sensorManager._load_sensors()
        return sensorManager.getSensorbyName(deviceName)


class WebInterface:
    def __init__(self, system=None):
        """
        Initialize WebInterface.
        :param system: System object to communicate with (can be mocked)
        """
        self.system = system
        self.pages = {}  # Dictionary: page_key -> Page object
        self.current_page = None
        self.current_user = None  # Set after login

        self.root = tk.Tk()
        self.root.title("SafeHome")
        self.root.geometry("800x800")
        self.root.minsize(800, 600)

        # container holds all pages
        self.container = tk.Frame(self.root)
        self.container.pack(fill="both", expand=True)
        self.container.pack_propagate(False)  # keep frame size fixed

        self.root.update_idletasks()

        self._initialize_pages()

    def _initialize_pages(self):
        # Initialize and add all pages to the pages dictionary
        self.addPage(
            "login",
            LoginPage(
                self.container,
                page_id=0,
                next_page_callback=lambda: self.switchToPage("home"),
                system_callback=self._handle_login,
            ),
        )
        self.addPage(
            "home", HomePage(self.container, page_id=1, switch_page_callback=self.switchToPage)
        )
        self.addPage(
            "user_settings",
            UserSettingPage(
                self.container,
                page_id=2,
                switch_page_callback=self.switchToPage,
                prev_page="home",
                selected_user=self.current_user,
                user_data_callback=self.user_data_callback,
            ),
        )
        self.addPage(
            "security",
            SecurityPage(
                self.container, page_id=3, prev_page="home", switch_page_callback=self.switchToPage
            ),
        )
        self.addPage(
            "camera",
            CameraListPage(
                self.container, page_id=4, prev_page="home", switch_page_callback=self.switchToPage
            ),
        )
        self.addPage(
            "view_log",
            ViewLogPage(
                self.container, page_id=5, prev_page="home", switch_page_callback=self.switchToPage
            ),
        )
        self.addPage(
            "floor_plan",
            FloorPlanPage(
                self.container,
                page_id=6,
                prev_page="security",
                switch_page_callback=self.switchToPage,
                point_click_callback=device_info,
            ),
        )
        self.addPage(
            "safety_zone_list",
            SafetyZoneListPage(
                self.container,
                page_id=7,
                prev_page="security",
                switch_page_callback=self.switchToPage,
            ),
        )
        self.addPage(
            "safe_home_mode_list",
            SafeHomeModeListPage(
                self.container,
                page_id=8,
                prev_page="security",
                switch_page_callback=self.switchToPage,
            ),
        )
        self.addPage(
            "thumbnail",
            ThumbnailViewPage(
                self.container,
                page_id=9,
                prev_page="camera",
                switch_page_callback=self.switchToPage,
            ),
        )

    # --- Page rendering ---
    def drawPage(self, pageNumber: List[int]) -> bool:
        if not pageNumber:
            return False
        page_key = str(pageNumber[0])
        if page_key in self.pages:
            self.current_page = self.pages[page_key]
            self.current_page.drawPage()
            return True
        return False

    def switchToPage(self, page_key: str) -> bool:
        if page_key in self.pages:
            # Lower all pages (hide all)
            for p in self.pages.values():
                p.frame.lower()

            if page_key == "login":
                # clear entry
                if "login" in self.pages:
                    self.pages["login"].clear_entry()
                self.current_user = None  # Clear current user on logout

            # Raise only the target page
            self.current_page = self.pages[page_key]
            self.current_page.frame.tkraise()
            self.current_page.drawPage()
            return True

        return False

    def run(self):
        self.switchToPage("login")  # show first page
        self.root.mainloop()

    # --- Page management ---
    def addPage(self, page_key: str, page_obj: Page) -> None:
        self.pages[page_key] = page_obj

    def _handle_login(self, username, password):
        success, user = loginManager.login(username, password)
        if success and user:
            self.current_user = {
                "name": user.getUsername(),
                "type": user.getType(),
                "password": user.getPassword(),
                "image_path": getattr(user, "image_path", ""),
            }
            return True

        self.current_user = None
        return False

    def user_data_callback(self):
        return self.current_user

    # # --- Event handling ---
    # def processButtonEvent(self, eventID: int, returnData: Any = None) -> None:
    #     if self.system:
    #         self.system.handle_event(eventID, returnData)
    #     else:
    #         print(f"[DEBUG] Button event {eventID}, data {returnData}")

    # # --- Video frame sending ---
    # def sendVideoImages(self, images: List[Any]) -> None:
    #     if self.current_page:
    #         self.current_page.receive_video(images)

    # # --- Message exchange with system ---
    # def sendMessageToSystem(self, message: Any) -> None:
    #     if self.system:
    #         self.system.receive_message(message)
    #     else:
    #         print(f"[DEBUG] Sending message to system: {message}")

    # def receiveMessageFromSystem(self, message: Any) -> None:
    #     if self.current_page:
    #         self.current_page.receive_message(message)
    #     else:
    #         print(f"[DEBUG] No current page to receive system message: {message}")
