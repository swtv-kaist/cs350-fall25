import tkinter as tk
from PIL import Image, ImageTk
import os

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

# Assume sensor and camera positions on the floorplan are predefined
points = {
    "motionSensor1": (300, 105, 300, 16),
    "motionSensor2-1": (47, 305, 20, 20),
    "motionSensor2-2": (77, 279, 20, 20),
    "motionSensor2-3": (108, 257, 20, 20),
    "motionSensor2-4": (138, 235, 20, 20),
    "motionSensor2-5": (169, 213, 20, 20),
    "motionSensor2-6": (199, 191, 20, 20),
    "doorSensor1": (295, 20, 40, 20),
    "doorSensor2": (105, 350, 60, 20),
    "window1": (15, 106, 20, 40),
    "window2": (75, 20, 40, 20),
    "window3": (15, 258, 20, 40),
    "window4": (460, 20, 100, 20),
    "window5": (580, 106, 20, 40),
    "window6": (580, 258, 20, 40),
    "camera1": (130, 40, 20, 40),
    "camera2": (265, 240, 20, 40),
    "camera3": (470, 320, 20, 40),
}


class SafetyZoneView(tk.Canvas):
    def __init__(
        self,
        parent,
        floor_image_path=os.path.join(PROJECT_ROOT, "virtual_device_v3/floorplan.png"),
        points_dict=points,
        safetyZone_add_callback=None,
        safetyZone_click_callback=None,
        safetyZone_remove_callback=None,
        safetyZone_update_callback=None,
        zone_list=[],
    ):
        super().__init__(parent, bg="white", highlightthickness=0)

        self.safetyZone_add_callback = safetyZone_add_callback
        self.safetyZone_click_callback = safetyZone_click_callback
        self.safetyZone_remove_callback = safetyZone_remove_callback
        self.safetyZone_update_callback = safetyZone_update_callback
        self.floor_image_path = floor_image_path
        self.points = points_dict
        self.zones = {}
        self.zone_list = zone_list
        self.zone_labels = {}
        self.temp_zone = None  # for previewing new zones

        self.zone_counter = 1
        self._load_image()

    def _load_image(self):
        """Load and render the floorplan image."""
        try:
            img = Image.open(self.floor_image_path)
            self.orig_width, self.orig_height = img.size

            self.floor_image_tk = ImageTk.PhotoImage(img)
            self.image_id = self.create_image(0, 0, anchor="nw", image=self.floor_image_tk)

            # Resize canvas to match image
            self.config(width=self.orig_width, height=self.orig_height)

        except Exception as e:
            print("Failed to load floorplan image:", e)

    # Compute bounding box for selected points
    def _compute_bbox(self, selected_points):
        xs, ys = [], []

        for pid in selected_points:
            if pid == "motionSensor2":
                # Special case: include all motionSensor2 sub-points
                for sub_id in self.points:
                    if sub_id.startswith("motionSensor2-"):
                        x, y, rx, ry = self.points[sub_id]
                        xs.extend([x - rx, x + rx])
                        ys.extend([y - ry, y + ry])
                continue

            if pid not in self.points:
                continue

            if "camera" in pid:
                # Skip cameras for safety zones
                continue

            x, y, rx, ry = self.points[pid]
            xs.extend([x - rx, x + rx])
            ys.extend([y - ry, y + ry])

        if not xs:
            return None

        return min(xs), min(ys), max(xs), max(ys)

    # Draw-only zone (does NOT store)
    def draw_zone(self, selected_points):
        bbox = self._compute_bbox(selected_points)
        if not bbox:
            print("draw_zone: No valid points")
            return None

        x1, y1, x2, y2 = bbox

        # Remove old preview zone
        if self.temp_zone:
            self.delete(self.temp_zone)
            self.temp_zone = None

        self.temp_zone = self.create_rectangle(
            x1,
            y1,
            x2,
            y2,
            fill="red",
            outline="red",
            width=2,
            stipple="gray25",  # 10–25% transparency effect
        )

        # Keep points above temp zone
        for pid in self.points:
            self.tag_raise(pid)

        return self.temp_zone

    # Add + save zone permanently
    def add_zone(self, selected_points):
        if len(selected_points) < 2:
            print("add_zone: Require at least 2 sensors")
            return None

        bbox = self._compute_bbox(selected_points)
        if not bbox:
            print("add_zone: No valid points")
            return None

        x1, y1, x2, y2 = bbox

        rect_id = self.create_rectangle(
            x1, y1, x2, y2, fill="red", outline="red", width=2, stipple="gray25"
        )

        zone_id = f"zone_{self.zone_counter}"
        self.zone_counter += 1
        self.zones[zone_id] = rect_id

        self.zone_list.append(
            {"id": zone_id, "name": "Unknown", "sensor_list": selected_points, "arm_status": True}
        )

        # Add label text
        text_id = self.create_text(
            (x1 + x2) / 2, (y1 + y2) / 2, text=zone_id, fill="white", font=("Arial", 12, "bold")
        )
        self.zone_labels[zone_id] = text_id

        # Bring points above zone
        for pid in self.points:
            self.tag_raise(pid)

        if self.safetyZone_add_callback:
            self.safetyZone_add_callback(zone_id, selected_points)

        return zone_id

    # Remove zone by id
    def remove_zone(self, zone_data):
        zone_id = zone_data["id"]
        if zone_id in self.zones:
            self.delete(self.zones[zone_id])
            del self.zones[zone_id]
        if zone_id in self.zone_labels:
            self.delete(self.zone_labels[zone_id])
            del self.zone_labels[zone_id]

        self.zone_list = [z for z in self.zone_list if z["id"] != zone_id]

        if self.safetyZone_remove_callback:
            self.safetyZone_remove_callback(zone_id)

    # Redraw all permanent zones
    def draw_all_zones(self):
        for zone_id, rect in list(self.zones.items()):
            coords = self.coords(rect)

            self.delete(rect)
            self.delete(self.zone_labels.get(zone_id, None))

            # New Rectangle
            new_rect = self.create_rectangle(
                *coords, fill="red", outline="red", width=2, stipple="gray25"
            )

            self.zones[zone_id] = new_rect

            # New label
            x1, y1, x2, y2 = coords
            new_text = self.create_text(
                (x1 + x2) / 2, (y1 + y2) / 2, text=zone_id, fill="white", font=("Arial", 12, "bold")
            )
            self.zone_labels[zone_id] = new_text

        # Bring points above all zones
        for pid in self.points:
            self.tag_raise(pid)

    def allow_zone_clicks(self):
        for zone_id, rect in self.zones.items():
            self.tag_bind(
                rect, "<Button-1>", lambda e, zid=zone_id: self.safetyZone_click_callback(zid)
            )
            self.tag_bind(
                self.zone_labels[zone_id],
                "<Button-1>",
                lambda e, zid=zone_id: self.safetyZone_click_callback(zid),
            )

    def set_points(self, click_callback):
        """Add multiple clickable points onto the image."""
        for point_id, (x, y, rx, ry) in self.points.items():
            if point_id.startswith("camera"):
                continue  # Skip cameras

            oval = self.create_oval(
                x - rx, y - ry, x + rx, y + ry, fill="", outline="", width=0.1, tags=point_id
            )

            # All motionSensor2-* map to the same id
            mapped_id = point_id if "motionSensor2" not in point_id else "motionSensor2"

            self.tag_bind(point_id, "<Button-1>", lambda e, pid=mapped_id: click_callback(pid))

    def get_zone_by_id(self, zone_id):
        """Return the rectangle coords of a zone by its ID."""
        for zone in self.zone_list:
            if zone["id"] == zone_id:
                return zone
        return None

    # def zone_add_point(self, zone_id, point_id):
    #     if zone_id not in self.zones or point_id not in self.points:
    #         return

    #     # Get current coords
    #     rect = self.zones[zone_id]
    #     coords = self.canvas.coords(rect)

    #     # Get point coords
    #     x, y, rx, ry = self.points[point_id]
    #     px1, py1, px2, py2 = x - rx, y - ry, x + rx, y + ry

    #     # Update bounding box
    #     new_x1 = min(coords[0], px1)
    #     new_y1 = min(coords[1], py1)
    #     new_x2 = max(coords[2], px2)
    #     new_y2 = max(coords[3], py2)

    #     # Update rectangle
    #     self.canvas.coords(rect, new_x1, new_y1, new_x2, new_y2)

    #     if self.safetyZone_update_callback:
    #         name = point_id if "motionSensor2" not in point_id else "motionSensor2"
    #         self.safetyZone_update_callback(zone_id, "add", name)

    # def zone_remove_point(self, zone_id, point_id):
    #     if zone_id not in self.zones or point_id not in self.points:
    #         return

    #     # Get current coords
    #     rect = self.zones[zone_id]
    #     coords = self.canvas.coords(rect)

    #     # Get point coords
    #     x, y, rx, ry = self.points[point_id]
    #     px1, py1, px2, py2 = x - rx, y - ry, x + rx, y + ry

    #     # If point is not affecting the bounding box, do nothing
    #     if (px1 > coords[0] and px2 < coords[2] and
    #         py1 > coords[1] and py2 < coords[3]):
    #         return

    #     # Recompute bounding box excluding this point
    #     # This is a simple but inefficient way; for large numbers of points,
    #     # consider storing point-zone relationships for faster updates.
    #     all_points_in_zone = []
    #     for pid in self.points:
    #         if pid == point_id:
    #             continue
    #         x_pt, y_pt, rx_pt, ry_pt = self.points[pid]
    #         if (x_pt - rx_pt >= coords[0] and x_pt + rx_pt <= coords[2] and
    #             y_pt - ry_pt >= coords[1] and y_pt + ry_pt <= coords[3]):
    #             all_points_in_zone.append(pid)

    #     bbox = self._compute_bbox(all_points_in_zone)
    #     if not bbox:
    #         # No points left; remove zone
    #         self.remove_zone(zone_id)
    #         return

    #     new_x1, new_y1, new_x2, new_y2 = bbox

    #     # Update rectangle
    #     self.canvas.coords(rect, new_x1, new_y1, new_x2, new_y2)

    #     if self.safetyZone_update_callback:
    #         name = point_id if "motionSensor2" not in point_id else "motionSensor2"
    #         self.safetyZone_update_callback(zone_id, "remove", name)
