import tkinter as tk
from PIL import Image, ImageTk
import os

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

# Assume sensor and camera positions on the floorplan are predefined
points = {
    "motionSensor1": (300, 105, 300, 16),
    "motionSensor2-1": (47, 305, 20, 20),
    "motionSensor2-2": (77, 279, 20, 20),
    "motionSensor2-3": (108, 257, 20, 20),
    "motionSensor2-4": (138, 235, 20, 20),
    "motionSensor2-5": (169, 213, 20, 20),
    "motionSensor2-6": (199, 191, 20, 20),
    "doorSensor1": (295, 20, 40, 20),
    "doorSensor2": (105, 350, 60, 20),
    "window1": (15, 106, 20, 40),
    "window2": (75, 20, 40, 20),
    "window3": (15, 258, 20, 40),
    "window4": (460, 20, 100, 20),
    "window5": (580, 106, 20, 40),
    "window6": (580, 258, 20, 40),
    "camera1": (130, 40, 20, 40),
    "camera2": (265, 240, 20, 40),
    "camera3": (470, 320, 20, 40),
}


class FloorPlanView(tk.Canvas):
    def __init__(
        self,
        parent,
        floor_image_path=os.path.join(PROJECT_ROOT, "virtual_device_v3/floorplan.png"),
        points_dict=points,
        point_click_callback=None,
    ):
        super().__init__(parent, bg="white", highlightthickness=0)

        self.point_click_callback = point_click_callback
        self.floor_image_path = floor_image_path
        self.points = points_dict

        self._load_image()

        # Load floorplan image
        self.after(10, self._load_image)

    def _load_image(self):
        """Load and render the floorplan image."""
        try:
            img = Image.open(self.floor_image_path)
            self.orig_width, self.orig_height = img.size

            self.floor_image_tk = ImageTk.PhotoImage(img)
            self.image_id = self.create_image(0, 0, anchor="nw", image=self.floor_image_tk)

            # Resize canvas to match image
            self.config(width=self.orig_width, height=self.orig_height)

            # Add points after image is loaded
            self.set_points(self.points)

        except Exception as e:
            print("Failed to load floorplan image:", e)

    def set_points(self, points_dict):
        """Add multiple clickable points onto the image."""
        for point_id, (x, y, rx, ry) in points_dict.items():
            oval = self.create_oval(
                x - rx, y - ry, x + rx, y + ry, fill="", outline="", width=0.1, tags=point_id
            )

            # All motionSensor2-* map to the same id
            mapped_id = point_id if "motionSensor2" not in point_id else "motionSensor2"

            self.tag_bind(point_id, "<Button-1>", lambda e, pid=mapped_id: self._clicked(pid))

    def _clicked(self, point_id):
        print(f"Clicked point: {point_id}")
        if self.point_click_callback:
            self.point_click_callback(point_id)
