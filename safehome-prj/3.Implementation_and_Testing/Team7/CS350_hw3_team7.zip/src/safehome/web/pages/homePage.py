import tkinter as tk
from ..page import Page  # adjust import according to your project structure
from .setNewUserPage import SetNewUserPage


class HomePage(Page):
    def __init__(self, root, page_id=0, switch_page_callback=None):
        super().__init__(root, page_id)
        self.root = root
        self.switch_page_callback = switch_page_callback

        # Remove default Page label
        self.label.pack_forget()

        # Title
        tk.Label(self.frame, text="SafeHome", font=("Arial", 24, "bold")).pack(pady=20)

        # Buttons container
        btn_frame = tk.Frame(self.frame)
        btn_frame.pack(pady=10)

        # Button list: (Text, callback page id)
        buttons = [
            ("User Setting", "user_settings"),
            ("Security", "security"),
            ("Camera", "camera"),
            ("View Log", "view_log"),
            ("Add User", "set_new_user"),
            ("Log Out", "logout"),
        ]

        for i, (text, page_id) in enumerate(buttons):
            if text == "Log Out":
                b = tk.Button(btn_frame, text=text, width=20, command=self._on_logout)
            elif text == "Add User":
                b = tk.Button(btn_frame, text=text, width=20, command=self._on_add_user)
            else:
                b = tk.Button(
                    btn_frame,
                    text=text,
                    width=20,
                    command=lambda pid=page_id: self._switch_page(pid),
                )
            b.grid(row=i, column=0, pady=5)

    def _switch_page(self, page_id):
        if self.switch_page_callback:
            self.switch_page_callback(page_id)

    def _on_add_user(self):
        set_new_user_page = SetNewUserPage(
            self.root,
            submit_callback=None,
        )
        set_new_user_page.drawPage()
