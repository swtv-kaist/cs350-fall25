import tkinter as tk
from ..page import Page  # adjust import according to your project structure


class SecurityPage(Page):
    def __init__(self, root, page_id=0, switch_page_callback=None, prev_page=None):
        super().__init__(root, page_id, switch_page_callback)
        self.root = root
        self.switch_page_callback = switch_page_callback

        self.prev_page = prev_page

        # Remove default Page label
        self.label.pack_forget()

        # Title
        tk.Label(self.frame, text="Security", font=("Arial", 24, "bold")).pack(pady=20)

        # Buttons container
        btn_frame = tk.Frame(self.frame)
        btn_frame.pack(pady=10)

        # Button list: (Text, callback page id)
        buttons = [
            ("All Sensors/Cameras", "floor_plan"),
            ("Safety Zone", "safety_zone_list"),
            ("SafeHome Mode", "safe_home_mode_list"),
        ]

        for i, (text, page_id) in enumerate(buttons):
            b = tk.Button(
                btn_frame, text=text, width=20, command=lambda pid=page_id: self._switch_page(pid)
            )
            b.grid(row=i, column=0, pady=5)

        # Return button
        tk.Button(self.frame, text="Return", command=self._return).pack(pady=5)

    def _switch_page(self, page_id):
        if self.switch_page_callback:
            self.switch_page_callback(page_id)
