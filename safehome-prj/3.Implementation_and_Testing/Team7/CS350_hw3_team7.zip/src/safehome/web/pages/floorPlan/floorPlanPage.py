import tkinter as tk
from ...page import Page  # base Page class
from ...floorPlan import FloorPlanView
from ..camera.singleCameraPage import SingleCameraPage
from ..camera.cameraLoginPage import CameraLoginPage
from .singleSensorViewPage import SingleSensorPage
import os

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../.."))


class FloorPlanPage(Page):
    def __init__(
        self,
        root,
        page_id=0,
        switch_page_callback=None,
        point_click_callback=None,
        floor_image_path=os.path.join(PROJECT_ROOT, "virtual_device_v3/floorplan.png"),
        prev_page=None,
    ):
        """
        :param switch_page_callback: function to switch page in WebInterface
        :param point_click_callback: function(point_id) called when a floor point is clicked
        :param floor_image_path: optional blueprint image path
        """
        super().__init__(root, page_id)
        self.switch_page_callback = switch_page_callback
        self.point_click_callback = point_click_callback
        self.floor_image_path = floor_image_path

        self.prev_page = prev_page

        # Clear default label
        self.label.pack_forget()

        # Title
        tk.Label(self.frame, text="All Sensors/Cameras", font=("Arial", 16)).pack(pady=10)

        # Floor Plan View
        self.floor = FloorPlanView(
            self.frame,
            floor_image_path=self.floor_image_path,
            point_click_callback=self._point_clicked,
        )
        self.floor.pack(pady=10)

        # Return button
        self.return_button = tk.Button(self.frame, text="Return", command=self._return)
        self.return_button.pack(pady=5)

        # Message label for status
        self.status_label = tk.Label(self.frame, text="", fg="red")
        self.status_label.pack(pady=5)

    def _point_clicked(self, point_id):
        if not self.point_click_callback:
            return
        if "camera" in point_id:
            cam_obj = self.point_click_callback(point_id)
            cam_info = {
                "id": cam_obj.get_id(),
                "name": cam_obj.get_id(),
                "location": cam_obj.get_location()[:2],
                "enabled": cam_obj.is_enabled(),
                "hasPassword": cam_obj.has_password(),
                "password": cam_obj._password,
                "obj": cam_obj,
            }
            if cam_info and cam_info.get("hasPassword"):
                caemraLoginPage = CameraLoginPage(
                    self.root,
                    selected_camera=cam_info,
                )
                caemraLoginPage.drawPage()
            else:
                # Password is set, go to single camera view
                singleCameraPage = SingleCameraPage(
                    self.root,
                    selected_camera=cam_info,
                )
                singleCameraPage.drawPage()
        else:
            sensor_info = self.point_click_callback(point_id)
            sensor_dict = {
                "id": sensor_info.get_id(),
                "name": sensor_info.get_name(),
                "location": sensor_info.get_location()[:2],
                "enabled": sensor_info.isArmed(),
                "obj": sensor_info,
            }
            if sensor_info:
                singleSensorPage = SingleSensorPage(
                    self.root,
                    selected_sensor=sensor_dict,
                )
                singleSensorPage.drawPage()
            else:
                print("Can't find sensor")
        # if self.point_click_callback:
        #     self.point_click_callback(point_id)
