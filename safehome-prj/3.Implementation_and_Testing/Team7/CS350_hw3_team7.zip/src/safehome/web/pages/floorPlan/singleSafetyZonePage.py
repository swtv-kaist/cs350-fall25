import tkinter as tk
from ...page import Page
from ...SafetyZone import SafetyZoneView
import os


from ....sensors.SensorManager import SensorManager

PROJECT_ROOT_STORAGE = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../.."))
STORAGE_PATH = os.path.join(PROJECT_ROOT_STORAGE, "storage")
sensorManager = SensorManager(storage_dir=STORAGE_PATH)

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../.."))


class SingleSafetyZonePage(Page):
    def __init__(
        self, root, selected_zone, safetyZone_remove_callback=None, zone_action_callback=None
    ):
        """
        :param switch_page_callback: function to switch page in WebInterface
        :param point_click_callback: function(point_id) called when a floor point is clicked
        :param floor_image_path: optional blueprint image path
        """
        self.root = root
        self.window = tk.Toplevel(root)  # create a new window
        self.window.title(f"Safety Zone {selected_zone.get('id', '')}")
        self.window.geometry("800x730")

        self.safetyZone_remove_callback = safetyZone_remove_callback
        self.zone_action_callback = zone_action_callback
        self.selected_zone = selected_zone

        # Info Frame
        self.info_frame = tk.Frame(self.window)
        self.info_frame.pack(pady=10)
        self.id_label = tk.Label(self.info_frame, text="", font=("Arial", 12))
        self.id_label.pack()
        self.enabled_label = tk.Label(self.info_frame, text="", font=("Arial", 12))
        self.enabled_label.pack()

        # Sensor List Frame
        self.sensor_frame = tk.LabelFrame(self.window, text="Sensors in Zone", padx=10, pady=10)
        self.sensor_frame.pack(pady=5, fill="x")
        self._populate_sensors()

        # Enable Setting
        self.enable_frame = tk.LabelFrame(self.window, text="Enable Setting", padx=10, pady=10)
        self.enable_frame.pack(pady=5, fill="x")
        tk.Button(
            self.enable_frame, text="Enable", width=10, command=lambda: self._action("enable")
        ).pack(side="left", padx=5)
        tk.Button(
            self.enable_frame, text="Disable", width=10, command=lambda: self._action("disable")
        ).pack(side="left", padx=5)

        # Floor Plan View
        self.floor = SafetyZoneView(self.window)

        self.floor.pack(pady=10)

        # Remove button
        self.remove_button = tk.Button(
            self.window, text="Remove Safety Zone", command=self._delete_zone
        )
        self.remove_button.pack(pady=5)

        # Return button
        self.return_button = tk.Button(self.window, text="Return", command=self._return)
        self.return_button.pack(pady=5)

        # Message label for status
        self.status_label = tk.Label(self.window, text="", fg="red")
        self.status_label.pack(pady=5)

        self._update_zone_info()

    def _update_zone_info(self):
        if not self.selected_zone:
            return
        cam = self.selected_zone
        self.id_label.config(text=f"Zone ID: {cam.get('id', '')}")
        self.enabled_label.config(
            text=f"Enabled: {'Yes' if cam.get('arm_status', False) else 'No'}"
        )

    def _delete_zone(self):
        if self.safetyZone_remove_callback and self.selected_zone:
            self.safetyZone_remove_callback(self.selected_zone)
            self.status_label.config(text="Zone removed.", fg="green")
            self._cancel()
        else:
            self.status_label.config(text="No callback defined for remove", fg="red")

    def _populate_sensors(self):
        # Clear any existing widgets in sensor_frame
        for widget in self.sensor_frame.winfo_children():
            widget.destroy()

        sensors = self.selected_zone.get("sensor_list", [])
        if not sensors:
            tk.Label(self.sensor_frame, text="No sensors assigned").pack(anchor="w")
            return

        for sid in sensors:
            tk.Label(self.sensor_frame, text=f"Sensor: {sid}", anchor="w").pack(fill="x")

    def _cancel(self):
        self.window.destroy()

    def drawPage(self):
        self.window.tkraise()  # bring this page to front
        self.floor.draw_zone(self.selected_zone.get("sensor_list", []))

    def _return(self):
        self.window.destroy()

    def _action(self, action):
        if action not in ["enable", "disable"]:
            print("Unknown action")
            return

        sensorManager._load_sensors()
        for sensor_name in self.selected_zone.get("sensor_list", []):
            sensorObj = sensorManager.getSensorbyName(sensor_name)
            if action == "enable":
                sensorObj.arm()
            elif action == "disable":
                sensorObj.disarm()
        sensorManager.save_sensors()
        self._update_zone_info()

        # if self.zone_action_callback and self.selected_zone:
        #     self.zone_action_callback(self.selected_zone, action)
        #     self.status_label.config(text=f"Action {action} sent.", fg="green")
        # else:
        #     self.status_label.config(text=f"No callback defined for {action}", fg="red")
