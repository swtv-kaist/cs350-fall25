import tkinter as tk
from tkinter import ttk
from ..page import Page


class ViewLogPage(Page):
    def __init__(
        self,
        root,
        page_id=0,
        logs_callback=None,
        refresh_interval=1000,
        prev_page=None,
        switch_page_callback=None,
    ):
        """
        :param logs_callback: function that returns list of logs, each log is dict with keys 'id', 'dateTime', 'description'
        :param refresh_interval: refresh interval in ms
        """
        super().__init__(root, page_id, switch_page_callback)
        self.root = root
        self.logs_callback = logs_callback
        self.refresh_interval = refresh_interval
        self.prev_page = prev_page

        # Remove default Page label
        self.label.pack_forget()

        # Title
        tk.Label(self.frame, text="View Logs", font=("Arial", 16, "bold")).pack(pady=10)

        # Table frame
        table_frame = tk.Frame(self.frame)
        table_frame.pack(fill="both", expand=True, padx=10, pady=10)

        # Scrollbar
        self.scrollbar_y = tk.Scrollbar(table_frame)
        self.scrollbar_y.pack(side="right", fill="y")
        self.scrollbar_x = tk.Scrollbar(table_frame, orient="horizontal")
        self.scrollbar_x.pack(side="bottom", fill="x")

        # Treeview
        self.tree = ttk.Treeview(
            table_frame,
            columns=("ID", "Date/Time", "Description"),
            show="headings",
            yscrollcommand=self.scrollbar_y.set,
            xscrollcommand=self.scrollbar_x.set,
        )
        self.tree.heading("ID", text="ID")
        self.tree.heading("Date/Time", text="Date/Time")
        self.tree.heading("Description", text="Description")
        self.tree.column("ID", width=80, anchor="center")
        self.tree.column("Date/Time", width=150, anchor="center")
        self.tree.column("Description", width=400, anchor="w")
        self.tree.pack(fill="both", expand=True)

        self.scrollbar_y.config(command=self.tree.yview)
        self.scrollbar_x.config(command=self.tree.xview)

        # Return button
        tk.Button(self.frame, text="Return", command=self._return).pack(pady=5)

        # Start refreshing table
        self._refresh_table()

    def _refresh_table(self):
        """Get logs from callback and update treeview."""
        if self.logs_callback:
            logs = self.logs_callback()
            self._populate_table(logs)
        self.frame.after(self.refresh_interval, self._refresh_table)

    def _populate_table(self, logs):
        """Fill the treeview with log data."""
        self.tree.delete(*self.tree.get_children())
        for log in logs:
            self.tree.insert(
                "",
                "end",
                values=(log.get("id", ""), log.get("dateTime", ""), log.get("description", "")),
            )
