import tkinter as tk
from ..page import Page  # adjust import depending on your package


class LoginPage(Page):
    def __init__(self, root, page_id=0, system_callback=None, next_page_callback=None):
        """
        :param system_callback: function(username, password) -> bool
                                Returns True if login is correct, False otherwise
        :param next_page_callback: function() to call when login is successful
        """
        super().__init__(root, page_id)

        self.system_callback = system_callback
        self.next_page_callback = next_page_callback

        # Clear default label from Page
        self.label.pack_forget()
        self.header_frame.pack_forget()

        # Username
        tk.Label(self.frame, text="Username:").pack(pady=5)
        self.username_entry = tk.Entry(self.frame)
        self.username_entry.pack(pady=5)

        # Password
        tk.Label(self.frame, text="Password:").pack(pady=5)
        self.password_entry = tk.Entry(self.frame, show="*")
        self.password_entry.pack(pady=5)

        # Login button
        self.login_button = tk.Button(self.frame, text="Login", command=self._on_login)
        self.login_button.pack(pady=10)

        # Message label for status
        self.status_label = tk.Label(self.frame, text="", fg="red")
        self.status_label.pack(pady=5)

    def clear_entry(self):
        self.username_entry.delete(0, tk.END)
        self.password_entry.delete(0, tk.END)

    def _on_login(self):
        """Called when Login button is pressed"""
        username = self.username_entry.get().strip()
        password = self.password_entry.get().strip()

        # Ensure both fields are filled
        if not username or not password:
            self.status_label.config(text="Please enter both username and password.")
            return

        # Call system callback to validate credentials
        if self.system_callback:
            result = self.system_callback(username, password)
            if result:  # success
                self.status_label.config(text="Login successful!", fg="green")
                if self.next_page_callback:
                    self.next_page_callback()  # move to next page
            else:  # failure
                self.status_label.config(text="Incorrect username or password.", fg="red")
        else:
            self.status_label.config(text="No system callback defined.", fg="red")

    def drawPage(self):
        """Raise frame and focus on username entry"""
        self.frame.tkraise()
        self.username_entry.focus_set()
        print(f"[DEBUG] Drawing LoginPage (id={self._id})")

    def setPageParameters(self, parameters):
        """Display messages from system if needed"""
        super().setPageParameters(parameters)
        if isinstance(parameters, str):
            self.status_label.config(text=parameters)
        elif isinstance(parameters, dict) and "message" in parameters:
            self.status_label.config(text=parameters["message"])
        else:
            self.status_label.config(text="")
