import tkinter as tk
from ..page import Page
import os

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../.."))


class SafeHomeModeRemovePage(Page):
    """
    Page to remove sensors from a given mode.
    selected_mode: dict with at least "id" and "sensor_ids" list
    remove_action_callback(selected_mode, remove_list) is called on remove
    """

    def __init__(self, root, selected_mode, remove_action_callback=None, mode_infos=None):
        self.mode_infos = mode_infos
        # Independent window
        self.root = root
        self.window = tk.Toplevel(root)
        self.window.title(f"Remove Sensors from Mode: {selected_mode['name']}")
        self.window.geometry("600x550")

        self.selected_mode = selected_mode
        self.remove_action_callback = remove_action_callback

        # Track Checkbutton variables
        self.sensor_vars = {}  # sensor_id -> tk.IntVar()

        # ---------- Title ----------
        tk.Label(self.window, text="Remove Sensors", font=("Arial", 16)).pack(pady=10)

        # ---------- Mode Info ----------
        self.info_frame = tk.Frame(self.window)
        self.info_frame.pack(pady=(10, 5))
        self.id_label = tk.Label(self.info_frame, text="", font=("Arial", 14, "bold"))
        self.id_label.pack()

        # ---------- Sensor List Frame ----------
        self.sensor_frame = tk.LabelFrame(
            self.window, text="Sensors in this mode", padx=10, pady=10
        )
        self.sensor_frame.pack(pady=10, fill="x")
        self._populate_sensors()

        # ---------- Status Message ----------
        self.status_label = tk.Label(self.window, text="", fg="green")
        self.status_label.pack(pady=8)

        # ---------- Buttons ----------
        btn_frame = tk.Frame(self.window)
        btn_frame.pack(pady=(0, 10))
        tk.Button(btn_frame, text="Remove Sensors", width=15, command=self._remove).pack(
            side="left", padx=5
        )
        tk.Button(btn_frame, text="Cancel", width=12, command=self._cancel).pack(
            side="left", padx=5
        )

        # Update mode info
        self._update_mode_info()

    # ------------------ Internal Updates ------------------
    def _update_mode_info(self):
        """Refresh mode info labels."""
        mode_id = self.selected_mode.get("name", "")
        self.id_label.config(text=f"Mode: {mode_id}")

    def _populate_sensors(self):
        """List all sensors inside this mode as checkboxes."""
        for w in self.sensor_frame.winfo_children():
            w.destroy()

        sensors = self.selected_mode.get("sensor_list", [])
        if not sensors:
            tk.Label(self.sensor_frame, text="(No sensors assigned)", fg="gray").pack(anchor="w")
            return

        for sid in sensors:
            var = tk.IntVar(value=0)
            chk = tk.Checkbutton(self.sensor_frame, text=sid, variable=var, anchor="w")
            chk.pack(fill="x", padx=5, pady=2, anchor="w")
            self.sensor_vars[sid] = var

    # ------------------ Button Actions ------------------
    def _cancel(self):
        """Close only this config window."""
        self.window.destroy()

    def drawPage(self):
        """Bring this window to front."""
        self.window.deiconify()
        self.window.lift()

    def _remove(self):
        """Trigger remove sensors action."""
        remove_list = [sid for sid, var in self.sensor_vars.items() if var.get()]
        if not remove_list:
            self.status_label.config(text="No sensors selected to remove.", fg="red")
            return

        # Call callback if defined
        # if self.remove_action_callback:
        #     try:
        #         self.remove_action_callback(self.selected_mode, remove_list)
        #         self.status_label.config(text=f"Removed sensors: {', '.join(remove_list)}", fg="green")
        #     except Exception as e:
        #         self.status_label.config(text=f"Error removing sensors: {e}", fg="red")
        # else:
        #     self.status_label.config(text="No remove action defined.", fg="red")

        for sensor in remove_list:
            self.selected_mode["sensor_list"].remove(sensor)

        self.remove_action_callback()

        # Done
        self._cancel()
