# web/pages/thumbnailViewPage.py
import tkinter as tk
from ...page import Page
from PIL import Image, ImageTk, ImageDraw
from .singleCameraPage import SingleCameraPage
from .cameraLoginPage import CameraLoginPage
import os

from ....cameras.CameraManager import CameraManager

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../.."))
STORAGE_PATH = os.path.join(PROJECT_ROOT, "storage")

cameraManager = CameraManager(storage_dir=STORAGE_PATH)


class ThumbnailViewPage(Page):
    def __init__(
        self,
        root,
        page_id=0,
        camera_list_callback=None,
        switch_page_callback=None,
        prev_page=None,
        get_view_callback=None,
    ):
        super().__init__(root, page_id)
        self.camera_list_callback = camera_list_callback
        self.switch_page_callback = switch_page_callback
        self.prev_page = prev_page
        self.get_view_callback = get_view_callback

        self.label.pack_forget()

        # Title
        tk.Label(self.frame, text="Camera Thumbview", font=("Arial", 16)).pack(pady=10)

        # Return button
        self.return_button = tk.Button(self.frame, text="Return", command=self._return)
        self.return_button.pack(pady=5)

        # Container for thumbnails
        self.thumb_frame = tk.Frame(self.frame)
        self.thumb_frame.pack(pady=10)

        # Keep references to images
        self.thumbnail_images = []

        self.status_label = tk.Label(self.frame, text="", fg="red")
        self.status_label.pack(pady=5)

    def drawPage(self):
        # Clear previous thumbnails
        for widget in self.thumb_frame.winfo_children():
            widget.destroy()
        self.thumbnail_images.clear()

        cameras = []
        # if self.camera_list_callback:
        #     cameras = self.camera_list_callback()
        cameraManager.load_cameras()
        for cam_obj in cameraManager.get_all_cameras():
            cam_info = {
                "id": cam_obj.get_id(),
                "name": cam_obj.get_id(),
                "location": cam_obj.get_location()[:2],
                "enabled": cam_obj.is_enabled(),
                "hasPassword": cam_obj.has_password(),
                "password": cam_obj._password,
                "obj": cam_obj,
            }
            cameras.append(cam_info)

        col_count = 2
        row = 0
        col = 0

        thumbnail_size = (240, 200)

        for cam in cameras:
            # Determine image to show
            if not cam.get("enabled", False):
                img = Image.new("RGB", thumbnail_size, color="gray")
                draw = ImageDraw.Draw(img)
                draw.text((10, 40), "Camera is disabled", fill="white")
            elif cam.get("hasPassword", False):
                img = Image.new("RGB", thumbnail_size, color="gray")
                draw = ImageDraw.Draw(img)
                draw.text((10, 40), "Requires password", fill="white")
            elif cam["obj"]:
                img = cam["obj"].get_view().resize((240, 200))
            else:
                img = Image.new("RGB", thumbnail_size, color="black")
                draw = ImageDraw.Draw(img)
                draw.text((10, 40), "No View Available", fill="white")

            # Overlay camera ID at top-left
            draw = ImageDraw.Draw(img)
            draw.text((5, 0), f"ID: {cam.get('id', '')}", fill="yellow")

            tk_img = ImageTk.PhotoImage(img)
            self.thumbnail_images.append(tk_img)

            btn = tk.Button(
                self.thumb_frame,
                image=tk_img,
                text=cam.get("name", ""),
                compound="top",
                command=lambda c=cam: self._on_thumbnail_click(c),
            )
            btn.grid(row=row, column=col, padx=10, pady=10)

            col += 1
            if col >= col_count:
                col = 0
                row += 1

        self.frame.tkraise()

    def _on_thumbnail_click(self, cam):
        # if self.switch_page_callback:
        #     self.switch_page_callback(cam)
        if cam.get("hasPassword"):
            cameraLoginPage = CameraLoginPage(
                self.root,
                selected_camera=cam,
            )
            cameraLoginPage.drawPage()
        else:
            singleCameraPage = SingleCameraPage(
                self.root,
                selected_camera=cam,
                get_view_callback=self.get_view_callback,  # Comment out if not needed
            )
            singleCameraPage.drawPage()
