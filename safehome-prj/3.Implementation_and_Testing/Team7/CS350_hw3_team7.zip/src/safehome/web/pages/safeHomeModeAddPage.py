import tkinter as tk
from ..page import Page
from ..floorPlan import FloorPlanView
import os

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../.."))


class SafeHomeModeAddPage(Page):
    """
    Page to add sensors to a given mode.
    selected_mode: dict with at least "id" and "sensor_ids" list
    add_action_callback(selected_mode, add_list) is called on add
    """

    def __init__(self, root, selected_mode, add_action_callback=None, mode_infos=None):
        self.mode_infos = mode_infos
        # Independent window
        self.root = root
        self.window = tk.Toplevel(root)
        self.window.title(f"Add Sensors to Mode: {selected_mode['name']}")
        self.window.geometry("700x800")

        self.selected_mode = selected_mode
        self.add_action_callback = add_action_callback

        # Track Checkbutton variables for new sensors
        self.new_sensor_vars = {}  # sensor_id -> tk.IntVar()

        # ---------- Title ----------
        tk.Label(self.window, text="Add Sensors", font=("Arial", 16)).pack(pady=10)

        # ---------- Mode Info ----------
        self.info_frame = tk.Frame(self.window)
        self.info_frame.pack(pady=(10, 5))
        self.id_label = tk.Label(self.info_frame, text="", font=("Arial", 14, "bold"))
        self.id_label.pack()

        # ---------- Existing Sensor List ----------
        self.sensor_frame = tk.LabelFrame(self.window, text="Existing Sensors", padx=10, pady=10)
        self.sensor_frame.pack(pady=10, fill="x")
        self._populate_sensors()

        # ---------- New Sensor List ----------
        self.new_sensor_frame = tk.LabelFrame(
            self.window, text="New Sensors to Add", padx=10, pady=10
        )
        self.new_sensor_frame.pack(pady=10, fill="x")

        # ---------- Floor Plan View ----------
        self.floor_frame = tk.Frame(self.window)
        self.floor_frame.pack(pady=10)
        self.floor = FloorPlanView(self.floor_frame, point_click_callback=self.point_click_callback)
        self.floor.pack()

        # ---------- Status Message ----------
        self.status_label = tk.Label(self.window, text="", fg="green")
        self.status_label.pack(pady=8)

        # ---------- Buttons ----------
        btn_frame = tk.Frame(self.window)
        btn_frame.pack(pady=(0, 10))
        tk.Button(btn_frame, text="Add Selected Sensors", width=20, command=self._add).pack(
            side="left", padx=5
        )
        tk.Button(btn_frame, text="Cancel", width=12, command=self._cancel).pack(
            side="left", padx=5
        )

        # Fill info
        self._update_mode_info()

    # ------------------ Internal Updates ------------------
    def _update_mode_info(self):
        """Refresh mode info labels."""
        mode_id = self.selected_mode.get("name", "")
        self.id_label.config(text=f"Mode: {mode_id}")

    def _populate_sensors(self):
        """List all sensors inside this mode."""
        for w in self.sensor_frame.winfo_children():
            w.destroy()

        sensors = self.selected_mode.get("sensor_ids", [])
        if not sensors:
            tk.Label(self.sensor_frame, text="(No sensors assigned)", fg="gray").pack(anchor="w")
            return

        # Display 4 columns
        for idx, sid in enumerate(sensors):
            row, col = divmod(idx, 4)
            tk.Label(self.sensor_frame, text=f"• {sid}", anchor="w").grid(
                row=row, column=col, sticky="w", padx=10, pady=2
            )

    def _populate_new_sensors(self):
        """Refresh the New Sensors frame from currently selected new sensors."""
        # Clear frame first
        for w in self.new_sensor_frame.winfo_children():
            w.destroy()

        if not self.new_sensor_vars:
            tk.Label(self.new_sensor_frame, text="(No new sensors selected)", fg="gray").pack(
                anchor="w"
            )
            return

        # 4 columns layout
        for idx, (sid, var) in enumerate(self.new_sensor_vars.items()):
            row, col = divmod(idx, 4)
            # tk.Label(self.new_sensor_frame, text=f"• {sid}", anchor="w").grid(row=row, column=col, sticky="w", padx=10, pady=2)
            tk.Checkbutton(self.new_sensor_frame, text=sid, variable=var).grid(
                row=row, column=col, sticky="w", padx=10, pady=2
            )

        # for sid, var in self.new_sensor_vars.items():
        #     cb = tk.Checkbutton(self.new_sensor_frame, text=sid, variable=var)
        #     cb.pack(anchor="w")

    # ------------------ FloorPlan Callback ------------------
    def point_click_callback(self, point_id):
        """Called when a point on the floor plan is clicked."""
        if "camera" in point_id:
            self.status_label.config(text="Cannot add cameras as sensors.", fg="red")
            return

        # Avoid duplicate sensors
        if point_id in self.selected_mode.get("sensor_ids", []) or point_id in self.new_sensor_vars:
            self.status_label.config(text=f"{point_id} already in mode or selected.", fg="red")
            return

        # Add new sensor to list
        self.new_sensor_vars[point_id] = tk.IntVar(value=1)
        self._populate_new_sensors()  # refresh the frame
        self.status_label.config(text=f"{point_id} added to selection.", fg="green")

    # ------------------ Button Actions ------------------
    def _cancel(self):
        """Close only this window."""
        self.window.destroy()

    def drawPage(self):
        """Bring this window to front."""
        self.window.deiconify()
        self.window.lift()

    def _add(self):
        """Add selected sensors to mode."""
        add_list = [sid for sid, var in self.new_sensor_vars.items() if var.get()]
        if not add_list:
            self.status_label.config(text="No sensors selected to add.", fg="red")
            return

        # Call callback if defined
        # if self.add_action_callback:
        #     try:
        #         self.add_action_callback(self.selected_mode, add_list)
        #         self.status_label.config(text=f"Added sensors: {', '.join(add_list)}", fg="green")
        #     except Exception as e:
        #         self.status_label.config(text=f"Error adding sensors: {e}", fg="red")
        # else:
        #     self.status_label.config(text="No add action defined.", fg="red")

        for sensor in add_list:
            self.selected_mode["sensor_list"].append(sensor)

        self.add_action_callback()

        # Clear new sensor selection
        for w in self.new_sensor_frame.winfo_children():
            w.destroy()
        self.new_sensor_vars.clear()

        self._cancel()
