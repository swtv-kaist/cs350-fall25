# web/pages/setUserNewPassPage.py
import tkinter as tk
from ...page import Page
import os

from ....cameras.CameraManager import CameraManager

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../.."))
STORAGE_PATH = os.path.join(PROJECT_ROOT, "storage")

cameraManager = CameraManager(storage_dir=STORAGE_PATH)


def _change_password_callback(camera_info, new_password):
    print(f"[DEBUG] Change password for camera: {camera_info['id']} to {new_password}")


class SetCameraPassPage(Page):
    def __init__(
        self,
        root,
        prev_page=None,
        selected_camera=None,
        submit_callback=_change_password_callback,  # submit_callback(new_password)
    ):
        self.root = root
        self.window = tk.Toplevel(root)  # create a new window
        self.window.title("Camera Login")
        self.window.geometry("400x300")

        self.prev_page = prev_page
        self.selected_camera = selected_camera
        self.submit_callback = submit_callback

        # Title
        tk.Label(self.window, text="Set Camera Password", font=("Arial", 16)).pack(pady=10)

        # New password
        tk.Label(self.window, text="Password:").pack(pady=5)
        self.new_pass_entry = tk.Entry(self.window, show="*")
        self.new_pass_entry.pack(pady=5)

        # Confirm new password
        tk.Label(self.window, text="Confirm Password:").pack(pady=5)
        self.confirm_pass_entry = tk.Entry(self.window, show="*")
        self.confirm_pass_entry.pack(pady=5)

        # Submit button
        self.submit_button = tk.Button(self.window, text="Submit", command=self._submit)
        self.submit_button.pack(pady=10)

        # Return button
        self.return_button = tk.Button(self.window, text="Cancel", command=self._cancel)
        self.return_button.pack(pady=5)

        # Status label
        self.status_label = tk.Label(self.window, text="", fg="red")
        self.status_label.pack(pady=5)

    def drawPage(self):
        self.window.tkraise()  # bring this page to front

    def _cancel(self):
        self.window.destroy()

    def _submit(self):
        """Validate and call callback"""
        new_pw = self.new_pass_entry.get()
        confirm_pw = self.confirm_pass_entry.get()

        if not new_pw or not confirm_pw:
            self.status_label.config(text="Please fill all fields", fg="red")
            return

        if new_pw != confirm_pw:
            self.status_label.config(text="Passwords do not match", fg="red")
            return

        # Callback
        cameraManager.load_cameras()
        sensorObj = cameraManager.get_camera_by_id(self.selected_camera.get("id", ""))
        sensorObj.set_password(new_pw)
        cameraManager.save_cameras()

        self.status_label.config(text="Password updated successfully!", fg="green")
        self._cancel()

    def setPageParameters(self, parameters=None):
        """
        Optional: allow system to prefill or clear fields.
        Example parameters: {"clear": True}
        """
        if parameters and parameters.get("clear"):
            self.new_pass_entry.delete(0, tk.END)
            self.confirm_pass_entry.delete(0, tk.END)
        print(f"[DEBUG] SetCameraPassPage setPageParameters called with: {parameters}")
