import tkinter as tk
from ...page import Page
import os

from ....sensors.SensorManager import SensorManager

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../.."))
STORAGE_PATH = os.path.join(PROJECT_ROOT, "storage")

sensorManager = SensorManager(storage_dir=STORAGE_PATH)


class SingleSensorPage(Page):
    def __init__(
        self, root, switch_page_callback=None, sensor_action_callback=None, selected_sensor=None
    ):
        """
        :param root: Tk root
        :param page_id: Page ID
        :param switch_page_callback: function to switch to other page
        :param sensor_action_callback: function(sensor, action) for sensor buttons
        :param selected_sensor: dict with sensor info
        """
        self.root = root
        self.window = tk.Toplevel(root)  # create a new window
        self.window.title(f"Sensor {selected_sensor.get('id', '')}")
        self.window.geometry("300x300")

        self.switch_page_callback = switch_page_callback
        self.sensor_action_callback = sensor_action_callback
        self.selected_sensor = selected_sensor

        # Sensor info labels
        self.info_frame = tk.Frame(self.window)
        self.info_frame.pack(pady=10)
        self.id_label = tk.Label(self.info_frame, text="", font=("Arial", 12))
        self.id_label.pack()
        self.name_label = tk.Label(self.info_frame, text="", font=("Arial", 12))
        self.name_label.pack()
        self.location_label = tk.Label(self.info_frame, text="", font=("Arial", 12))
        self.location_label.pack()
        self.enabled_label = tk.Label(self.info_frame, text="", font=("Arial", 12))
        self.enabled_label.pack()

        # Enable Setting
        self.enable_frame = tk.LabelFrame(self.window, text="Enable Setting", padx=10, pady=10)
        self.enable_frame.pack(pady=5, fill="x")
        tk.Button(
            self.enable_frame, text="Enable", width=10, command=lambda: self._action("enable")
        ).pack(side="left", padx=5)
        tk.Button(
            self.enable_frame, text="Disable", width=10, command=lambda: self._action("disable")
        ).pack(side="left", padx=5)

        # Return Button
        tk.Button(self.window, text="Return", width=10, command=self._cancel).pack(pady=10)

        # Status label
        self.status_label = tk.Label(self.window, text="", fg="red")
        self.status_label.pack(pady=5)

        # Draw camera info initially
        self._update_sensor_info()

    def drawPage(self):
        self.window.tkraise()  # bring this page to front

    def _cancel(self):
        self.window.destroy()

    def _update_sensor_info(self):
        if not self.selected_sensor:
            return
        cam = self.selected_sensor
        self.id_label.config(text=f"Sensor ID: {cam.get('id', '')}")
        self.name_label.config(text=f"Sensor Name: {cam.get('name', '')}")
        location = cam.get("location", {})
        self.location_label.config(text=f"Location: ({location[0]}, {location[1]})")
        self.enabled_label.config(text=f"Enabled: {'Yes' if cam.get('enabled', False) else 'No'}")

    def _action(self, action):
        if action == "enable" and self.selected_sensor.get("enabled", False):
            self.status_label.config(text="Camera is already enable.", fg="red")
            return

        if action == "disable" and not self.selected_sensor.get("enabled", False):
            self.status_label.config(text="Camera is already disable.", fg="red")
            return

        sensorManager._load_sensors()
        sensorObj = sensorManager.getSensorbyName(self.selected_sensor.get("name", ""))
        if action == "enable":
            sensorObj.arm()
            self.selected_sensor["enabled"] = True
        elif action == "disable":
            sensorObj.disarm()
            self.selected_sensor["enabled"] = False
        else:
            print("[singleSensorViewPage] Unkown action")
        sensorManager.save_sensors()
        self._update_sensor_info()

        # if self.sensor_action_callback and self.selected_sensor:
        #     self.sensor_action_callback(self.selected_sensor, action)
        #     self.status_label.config(text=f"Action {action} sent.", fg="green")
        # else:
        #     self.status_label.config(text=f"No callback defined for {action}", fg="red")
