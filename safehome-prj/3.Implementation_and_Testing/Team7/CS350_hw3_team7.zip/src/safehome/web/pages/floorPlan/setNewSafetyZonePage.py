import tkinter as tk
from ...page import Page
from ...SafetyZone import SafetyZoneView
import os

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../.."))


class SetNewSafetyZonePage(Page):
    def __init__(
        self,
        root,
        switch_page_callback=None,
        safetyZone_add_callback=None,
        safetyZone_click_callback=None,
        safetyZone_remove_callback=None,
        safetyZone_update_callback=None,
    ):
        """
        :param switch_page_callback: function to switch page in WebInterface
        :param point_click_callback: function(point_id) called when a floor point is clicked
        :param floor_image_path: optional blueprint image path
        """
        self.root = root
        self.window = tk.Toplevel(root)  # create a new window
        self.window.title("New Safety Zone")
        self.window.geometry("800x650")

        self.switch_page_callback = switch_page_callback
        self.safetyZone_add_callback = safetyZone_add_callback
        self.selected_sensors = []

        # Title
        tk.Label(self.window, text="New Safety Zone", font=("Arial", 16)).pack(pady=10)

        # Floor Plan View
        self.floor = SafetyZoneView(
            self.window,
            safetyZone_add_callback=safetyZone_add_callback,
            safetyZone_click_callback=safetyZone_click_callback,
            safetyZone_remove_callback=safetyZone_remove_callback,
            safetyZone_update_callback=safetyZone_update_callback,
        )
        self.floor.set_points(self.point_click_callback)
        self.floor.pack(pady=10)

        # Submit button
        self.submit_button = tk.Button(self.window, text="Submit", command=self._submit)
        self.submit_button.pack(pady=10)

        # Message label for status
        self.status_label = tk.Label(self.window, text="", fg="red")
        self.status_label.pack(pady=5)

        # Return button
        self.return_button = tk.Button(self.window, text="Cancel", command=self._cancel)
        self.return_button.pack(pady=5)

    def _cancel(self):
        self.window.destroy()

    def drawPage(self):
        self.window.tkraise()  # bring this page to front
        self.floor.draw_zone(self.selected_sensors)

    def _submit(self):
        if len(self.selected_sensors) < 2:
            self.status_label.config(
                text="Please select at least two sensors to define a safety zone.", fg="red"
            )
            return
        else:
            if self.floor and self.safetyZone_add_callback:
                self.safetyZone_add_callback(self.selected_sensors)
                self._cancel()
            else:
                self.status_label.config(text="Error adding safety zone.", fg="red")

    def point_click_callback(self, point_id):
        print(f"Sensor point clicked: {point_id}")
        if point_id not in self.selected_sensors:
            self.selected_sensors.append(point_id)
        if len(self.selected_sensors) >= 2:
            self.drawPage()
