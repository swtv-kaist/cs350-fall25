import tkinter as tk
from ...page import Page
from .singleCameraPage import SingleCameraPage


class CameraLoginPage(Page):
    def __init__(
        self,
        root,
        switch_page_callback=None,
        camera_auth_callback=None,
        selected_camera=None,
        update_camera_callback=None,
    ):
        self.root = root
        self.window = tk.Toplevel(root)  # create a new window
        self.window.title("Camera Login")
        self.window.geometry("400x300")

        self.switch_page_callback = switch_page_callback
        self.camera_auth_callback = camera_auth_callback
        self.selected_camera = selected_camera

        self.update_camera_callback = update_camera_callback

        self.password_var = tk.StringVar()

        # Title
        tk.Label(self.window, text="Camera Login", font=("Arial", 18, "bold")).pack(pady=10)

        # Password field
        tk.Label(self.window, text="Password:", font=("Arial", 12)).pack()
        tk.Entry(self.window, textvariable=self.password_var, show="*").pack(pady=5)

        # Submit button
        tk.Button(self.window, text="Submit", width=15, command=self._submit).pack(pady=10)

        # Cancel button
        tk.Button(self.window, text="Cancel", width=15, command=self._cancel).pack(pady=10)

        # Status label
        self.status_label = tk.Label(self.window, text="", fg="red")
        self.status_label.pack(pady=5)

    def drawPage(self):
        self.window.tkraise()  # bring this page to front

    def _cancel(self):
        self.window.destroy()

    def _submit(self):
        password = self.password_var.get()
        success = False

        if not password:
            self.status_label.config(text="Please enter the password.", fg="red")
            return

        # Camera authentication happens through callback
        if self.camera_auth_callback:
            success = self.camera_auth_callback(password, self.selected_camera)

        if password == self.selected_camera.get("password"):
            self.status_label.config(text="Camera unlocked successfully!", fg="green")
            singleCameraPage = SingleCameraPage(self.root, selected_camera=self.selected_camera)
            singleCameraPage.drawPage()
            self.window.destroy()
            # self.switch_page_callback(self.selected_camera)
        else:
            self.status_label.config(text="Incorrect password.", fg="red")
