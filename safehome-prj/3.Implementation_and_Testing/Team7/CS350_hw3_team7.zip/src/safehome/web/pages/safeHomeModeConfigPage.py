import tkinter as tk
from ..page import Page
import os
from .safeHomeModeAddPage import SafeHomeModeAddPage
from .safeHomeModeRemovePage import SafeHomeModeRemovePage

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../.."))


class SafeHomeModeConfigPage(Page):
    def __init__(
        self,
        root,
        selected_mode,
        get_mode_callback=None,
        mode_action_callback=None,
        mode_infos=None,
    ):
        self.mode_infos = mode_infos

        # This page creates its own independent window
        self.root = root
        self.window = tk.Toplevel(root)
        self.window.title(f"Mode: {selected_mode.get('id', '')}")
        self.window.geometry("600x500")

        # Mode data + callbacks
        self.selected_mode = selected_mode
        self.get_mode_callback = get_mode_callback
        self.mode_action_callback = mode_action_callback

        # ---------- Mode Info ----------
        self.info_frame = tk.Frame(self.window)
        self.info_frame.pack(pady=(10, 5))

        self.id_label = tk.Label(self.info_frame, text="", font=("Arial", 14, "bold"))
        self.id_label.pack()

        # ---------- Sensor List ----------
        self.sensor_frame = tk.LabelFrame(
            self.window, text="Sensors in this mode", padx=10, pady=10
        )
        self.sensor_frame.pack(pady=10, fill="x")
        self._populate_sensors()

        # ---------- Arm/Disarm Controls ----------
        self.enable_frame = tk.LabelFrame(
            self.window, text="Add / Remove Sensors", padx=10, pady=10
        )
        self.enable_frame.pack(pady=10, fill="x")

        tk.Button(
            self.enable_frame, text="Add sensors", width=12, command=lambda: self._action("add")
        ).pack(side="left", padx=10)

        tk.Button(
            self.enable_frame,
            text="Remove sensors",
            width=12,
            command=lambda: self._action("remove"),
        ).pack(side="left", padx=10)

        # ---------- Status Message ----------
        self.status_label = tk.Label(self.window, text="", fg="green")
        self.status_label.pack(pady=8)

        # ---------- Return Button ----------
        tk.Button(self.window, text="Return", width=12, command=self._cancel).pack(pady=(0, 10))

        # Fill info text
        self._update_mode_info()

    # ------------------ Internal Updates ------------------

    def _update_mode_info(self):
        """Refresh mode info labels."""
        if not self.selected_mode:
            return

        mode_name = self.selected_mode.get("name", "")
        self.id_label.config(text=f"Mode: {mode_name}")

    def _populate_sensors(self):
        """List all sensors inside this mode."""
        for w in self.sensor_frame.winfo_children():
            w.destroy()

        sensors = self.selected_mode.get("sensor_list", [])

        if not sensors:
            tk.Label(self.sensor_frame, text="(No sensors assigned)", fg="gray").pack(anchor="w")
            return

        for sid in sensors:
            tk.Label(self.sensor_frame, text=f"• {sid}", anchor="w").pack(fill="x")

    # ------------------ Button Actions ------------------

    def _cancel(self):
        """Close only this config window."""
        self.window.destroy()

    def drawPage(self):
        """Bring this window to front."""
        self.window.deiconify()
        self.window.lift()

    def _action(self, action):
        """Send enable/disable request back to logic controller."""
        # if self.mode_action_callback and self.selected_mode:
        #     self.mode_action_callback(self.selected_mode, action)
        #     self.status_label.config(text=f"Action '{action}' sent.", fg="green")
        # else:
        #     self.status_label.config(text=f"No callback for action '{action}'", fg="red")

        if action in ["add", "remove"]:
            # Refresh sensor list after action
            if action == "add":
                add_page = SafeHomeModeAddPage(
                    self.root,
                    selected_mode=self.selected_mode,
                    mode_infos=self.mode_infos,
                    add_action_callback=self._populate_sensors,
                )
                add_page.drawPage()
            elif action == "remove":
                remove_page = SafeHomeModeRemovePage(
                    self.root,
                    selected_mode=self.selected_mode,
                    mode_infos=self.mode_infos,
                    remove_action_callback=self._populate_sensors,
                )
                remove_page.drawPage()

            self._populate_sensors()
        else:
            self.status_label.config(text=f"Unknown action '{action}'", fg="red")
