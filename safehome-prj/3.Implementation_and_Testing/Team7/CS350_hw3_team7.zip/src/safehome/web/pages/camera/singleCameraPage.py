import tkinter as tk
from ...page import Page
from .setCameraPassPage import SetCameraPassPage
import os

from ....cameras.CameraManager import CameraManager

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../.."))
STORAGE_PATH = os.path.join(PROJECT_ROOT, "storage")

cameraManager = CameraManager(storage_dir=STORAGE_PATH)


def _get_view_camera(selected_camera):
    """Placeholder function to get camera view image"""
    from PIL import Image, ImageDraw

    img = Image.new("RGB", (400, 300), color=(73, 109, 137))
    d = ImageDraw.Draw(img)
    d.text((10, 10), "Camera View", fill=(255, 255, 0))
    return img


def _camera_action_placeholder(camera, action):
    print(f"Camera Action: Camera ID {camera.get('id')} - Action: {action}")


class SingleCameraPage(Page):
    def __init__(
        self,
        root,
        switch_page_callback=None,
        camera_action_callback=_camera_action_placeholder,
        selected_camera=None,
        get_view_callback=_get_view_camera,
        update_camera_callback=None,
    ):
        """
        :param root: Tk root
        :param page_id: Page ID
        :param switch_page_callback: function to switch to other page
        :param camera_action_callback: function(camera_id, action) for camera buttons
        :param selected_camera: dict with camera info
        """
        self.root = root
        self.window = tk.Toplevel(root)  # create a new window
        self.window.title(f"Camera {selected_camera.get('id', '')}")
        self.window.geometry("500x500")

        self.switch_page_callback = switch_page_callback
        self.camera_action_callback = camera_action_callback
        self.selected_camera = selected_camera
        self.get_view_callback = get_view_callback
        self.update_camera_callback = update_camera_callback
        self.camera_window = None

        # Camera info labels
        self.info_frame = tk.Frame(self.window)
        self.info_frame.pack(pady=10)
        self.id_label = tk.Label(self.info_frame, text="", font=("Arial", 12))
        self.id_label.pack()
        self.location_label = tk.Label(self.info_frame, text="", font=("Arial", 12))
        self.location_label.pack()
        self.enabled_label = tk.Label(self.info_frame, text="", font=("Arial", 12))
        self.enabled_label.pack()
        self.has_pw_label = tk.Label(self.info_frame, text="", font=("Arial", 12))
        self.has_pw_label.pack()

        # Enable Setting
        self.enable_frame = tk.LabelFrame(self.window, text="Enable Setting", padx=10, pady=10)
        self.enable_frame.pack(pady=5, fill="x")
        tk.Button(
            self.enable_frame, text="Enable", width=10, command=lambda: self._action("enable")
        ).pack(side="left", padx=5)
        tk.Button(
            self.enable_frame, text="Disable", width=10, command=lambda: self._action("disable")
        ).pack(side="left", padx=5)

        # View Setting
        self.view_frame = tk.LabelFrame(self.window, text="View Setting", padx=10, pady=10)
        self.view_frame.pack(pady=5, fill="x")
        tk.Button(self.view_frame, text="Show", width=10, command=lambda: self._show()).pack(
            side="left", padx=5
        )
        tk.Button(
            self.view_frame, text="Pan Left", width=10, command=lambda: self._action("pan_left")
        ).pack(side="left", padx=5)
        tk.Button(
            self.view_frame, text="Pan Right", width=10, command=lambda: self._action("pan_right")
        ).pack(side="left", padx=5)
        tk.Button(
            self.view_frame, text="Zoom In", width=10, command=lambda: self._action("zoom_in")
        ).pack(side="left", padx=5)
        tk.Button(
            self.view_frame, text="Zoom Out", width=10, command=lambda: self._action("zoom_out")
        ).pack(side="left", padx=5)

        # # Record Setting
        # self.record_frame = tk.LabelFrame(self.frame, text="Record Setting", padx=10, pady=10)
        # self.record_frame.pack(pady=5, fill="x")
        # tk.Button(self.record_frame, text="Start Record", width=12,
        #           command=lambda: self._action("start_record")).pack(side="left", padx=5)
        # tk.Button(self.record_frame, text="Stop Record", width=12,
        #           command=lambda: self._action("stop_record")).pack(side="left", padx=5)
        # tk.Button(self.record_frame, text="Show Record", width=12,
        #           command=lambda: self._action("show_record")).pack(side="left", padx=5)

        # Password Setting
        self.pw_frame = tk.LabelFrame(self.window, text="Password Setting", padx=10, pady=10)
        self.pw_frame.pack(pady=5, fill="x")
        tk.Button(self.pw_frame, text="Set Password", width=12, command=self._change_password).pack(
            side="left", padx=5
        )
        tk.Button(
            self.pw_frame,
            text="Remove Password",
            width=15,
            command=lambda: self._action("remove_password"),
        ).pack(side="left", padx=5)

        # Return Button
        tk.Button(self.window, text="Return", width=10, command=self._cancel).pack(pady=10)

        # Status label
        self.status_label = tk.Label(self.window, text="", fg="red")
        self.status_label.pack(pady=5)

        # Draw camera info initially
        self._update_camera_info()

    def _update_camera_info(self):
        if not self.selected_camera:
            return
        cam = self.selected_camera
        self.id_label.config(text=f"Camera ID: {cam.get('id', '')}")
        location = cam.get("location", {})
        self.location_label.config(text=f"Location: ({location[0]}, {location[1]})")
        self.enabled_label.config(text=f"Enabled: {'Yes' if cam.get('enabled', False) else 'No'}")
        self.has_pw_label.config(
            text=f"Has Password: {'Yes' if cam.get('hasPassword', False) else 'No'}"
        )
        self.drawPage()

    def _action(self, action):
        if action == "enable" and self.selected_camera.get("enabled", False):
            self.status_label.config(text="Camera is already enable.", fg="red")
            return

        if action == "disable" and not self.selected_camera.get("enabled", False):
            self.status_label.config(text="Camera is already disable.", fg="red")
            return

        if action == "remove_password" and not self.selected_camera.get("hasPassword", False):
            self.status_label.config(text="Camera has no password to remove.", fg="red")
            return

        cameraManager.load_cameras()
        sensorObj = cameraManager.get_camera_by_id(self.selected_camera.get("id", ""))
        if action == "pan_left":
            sensorObj.pan_left()
        elif action == "pan_right":
            sensorObj.pan_right()
        elif action == "zoom_in":
            sensorObj.zoom_in()
        elif action == "zoom_out":
            sensorObj.zoom_out()
        elif action == "enable":
            sensorObj.enable()
            self.selected_camera["enabled"] = True
        elif action == "disable":
            sensorObj.disable()
            self.selected_camera["enabled"] = False
        elif action == "remove_password":
            sensorObj.remove_password()
            self.selected_camera["hasPassword"] = False
        else:
            print("[singleSensorViewPage] Unkown action")

        if self.camera_window and action in ["pan_left", "pan_right", "zoom_in", "zoom_out"]:
            self.selected_camera["obj"] = sensorObj
            new_pil_image = sensorObj.get_view()
            from PIL import ImageTk

            new_tk_image = ImageTk.PhotoImage(new_pil_image)
            self.tk_image = new_tk_image  # keep reference!
            self.label_cam.config(image=self.tk_image)
        cameraManager.save_cameras()
        self._update_camera_info()

        # if self.camera_action_callback and self.selected_camera:
        #     self.camera_action_callback(self.selected_camera, action)
        #     self.status_label.config(text=f"Action {action} sent.", fg="green")
        # else:
        #     self.status_label.config(text=f"No callback defined for {action}", fg="red")

    def _change_password(self):
        """Open SetCameraPassPage to change password"""
        print("Changing camera password")
        if self.selected_camera:
            # Callback used mainly for tests and higher-level coordination.
            # The real SetCameraPassPage handles persistence itself.
            def _on_new_password(new_pw):
                cam_obj = self.selected_camera.get("obj")
                if cam_obj is not None and hasattr(cam_obj, "set_password"):
                    cam_obj.set_password(new_pw)
                    self.selected_camera["hasPassword"] = True

            setPassPage = SetCameraPassPage(
                self.root,
                selected_camera=self.selected_camera,
                submit_callback=_on_new_password,
            )
            setPassPage.drawPage()
        else:
            self.status_label.config(text="No callback defined for changing password", fg="red")

    def _show(self):
        """Show camera feed in a new window"""
        cam = self.selected_camera
        enable = cam.get("enabled", False) if cam else False
        if not enable:
            self.status_label.config(text="Camera is disabled.", fg="red")
            return
        if self.camera_window:
            self.status_label.config(text="Camera window already open.", fg="red")
            return
        self.drawPage()

    def _cancel(self):
        self.window.destroy()

    def drawPage(self):
        """Show control window and camera window"""
        self.window.tkraise()  # raise control page
        cam = self.selected_camera
        enable = cam.get("enabled", False) if cam else False
        if not self.camera_window and enable:
            self.camera_window = tk.Toplevel(self.window)
            self.camera_window.title(f"Camera {self.selected_camera['id']} View")
            self.camera_window.protocol("WM_DELETE_WINDOW", self._close_both)

            cameraManager.load_cameras()
            self.selected_camera["obj"] = cameraManager.get_camera_by_id(
                self.selected_camera.get("id", "")
            )
            pil_image = self.selected_camera["obj"].get_view()
            # pil_image = self.get_view_callback(self.selected_camera)
            from PIL import ImageTk

            self.tk_image = ImageTk.PhotoImage(pil_image)
            self.label_cam = tk.Label(self.camera_window, image=self.tk_image)
            self.label_cam.pack()
            print("show camera view")

        if self.camera_window and not enable:
            self.camera_window.destroy()
            self.camera_window = None
            return

    def _return(self):
        """Go back to previous page."""
        print("Returning to previous page")
        # self.frame.pack_forget()
        if self.prev_page:
            if self.camera_window:
                self.camera_window.destroy()
                self.camera_window = None
            self.prev_page.drawPage()
        else:
            self.status_label.config(text="No previous page to return to.", fg="red")

    def _close_both(self):
        """Close camera window and control page"""
        if self.camera_window:
            self.camera_window.destroy()
            self.camera_window = None
