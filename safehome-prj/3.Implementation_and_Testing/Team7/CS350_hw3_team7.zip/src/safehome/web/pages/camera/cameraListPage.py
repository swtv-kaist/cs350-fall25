# web/pages/cameraListPage.py
import tkinter as tk
from ...page import Page
from .singleCameraPage import SingleCameraPage
from .cameraLoginPage import CameraLoginPage
import os

from ....cameras.CameraManager import CameraManager

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../.."))
STORAGE_PATH = os.path.join(PROJECT_ROOT, "storage")

cameraManager = CameraManager(storage_dir=STORAGE_PATH)


class CameraListPage(Page):
    def __init__(
        self,
        root,
        page_id=0,
        prev_page=None,
        switch_page_callback=None,
        camera_list_callback=None,  # () -> list[dict]
        camera_add_callback=None,  # (new_camera) ->
        view_as_thumbnail_callback=None,  # () ->
    ):
        super().__init__(root, page_id, switch_page_callback)

        self.prev_page = prev_page
        self.camera_add_callback = camera_add_callback
        self.camera_list_callback = camera_list_callback
        self.view_as_thumbnail_callback = view_as_thumbnail_callback

        # clear default label
        self.label.pack_forget()

        # Title
        tk.Label(self.frame, text="Camera List", font=("Arial", 16)).pack(pady=10)

        # Top button row
        top_btn_frame = tk.Frame(self.frame)
        top_btn_frame.pack(pady=5)

        self.thumbnail_button = tk.Button(
            top_btn_frame, text="View as Thumbnail", command=self._view_thumbnail
        )
        self.thumbnail_button.grid(row=0, column=0, padx=10)

        # self.add_camera_button = tk.Button(
        #     top_btn_frame,
        #     text="Add Camera",
        #     command=self.camera_add_callback
        # )
        # self.add_camera_button.grid(row=0, column=1, padx=10)

        self.return_button = tk.Button(top_btn_frame, text="Return", command=self._return)
        self.return_button.grid(row=0, column=2, padx=10)

        # Container for camera buttons
        self.camera_container = tk.Frame(self.frame)
        self.camera_container.pack(pady=10)

        # Store list of cameras
        self.camera_list = []

        # Status label
        self.status_label = tk.Label(self.frame, text="", fg="red")
        self.status_label.pack(pady=5)

    def _view_thumbnail(self):
        # if self.view_as_thumbnail_callback:
        #     self.view_as_thumbnail_callback()
        # else:
        #     self.status_label.config(text="Thumbnail view not implemented")

        self.switch_page_callback("thumbnail")

    def _select_camera(self, cam_info):
        """Called when user clicks a camera button"""
        if cam_info.get("hasPassword"):
            cameraLoginPage = CameraLoginPage(
                self.root,
                selected_camera=cam_info,
                switch_page_callback=lambda: self.drawPage(),
            )
            cameraLoginPage.drawPage()
        else:
            singleCameraPage = SingleCameraPage(
                self.root,
                selected_camera=cam_info,
            )
            singleCameraPage.drawPage()

    def _update_camera_buttons(self):
        """Render camera buttons in 2-column grid"""
        for widget in self.camera_container.winfo_children():
            widget.destroy()

        if not self.camera_list:
            tk.Label(self.camera_container, text="No cameras found").pack()
            return

        for i, cam in enumerate(self.camera_list):
            row = i // 2
            col = i % 2

            btn = tk.Button(
                self.camera_container,
                text=cam.get("id", f"Camera {i + 1}"),
                width=20,
                command=lambda c=cam: self._select_camera(c),
            )
            btn.grid(row=row, column=col, padx=10, pady=10)

    def drawPage(self):
        """Override drawPage to refresh camera list dynamically."""
        super().drawPage()

        if not self.camera_list:
            cameraManager.load_cameras()
            for cam_obj in cameraManager.get_all_cameras():
                cam_info = {
                    "id": cam_obj.get_id(),
                    "name": cam_obj.get_id(),
                    "location": cam_obj.get_location()[:2],
                    "enabled": cam_obj.is_enabled(),
                    "hasPassword": cam_obj.has_password(),
                    "password": cam_obj._password,
                    "obj": cam_obj,
                }
                self.camera_list.append(cam_info)

        # if self.camera_list_callback:
        #     try:
        #         # self.camera_list = self.camera_list_callback()
        #         self.camera_list = cameraManager.get_all_cameras()
        #     except Exception as e:
        #         self.status_label.config(text=f"Error loading cameras: {e}")
        #         self.camera_list = []

        self._update_camera_buttons()
