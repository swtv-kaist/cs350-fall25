import tkinter as tk
from PIL import Image, ImageTk, ImageDraw
from ..page import Page
from .setUserNewPassPage import SetUserNewPassPage


class UserSettingPage(Page):
    def __init__(
        self,
        root,
        page_id=0,
        prev_page=None,
        switch_page_callback=None,
        change_pass_callback=None,
        remove_user_callback=None,
        user_data_callback=None,
        selected_user=None,
    ):
        """
        :param prev_page: Page object to return to
        :param change_pass_callback: function(user_data) -> None
        :param remove_user_callback: function(user_data) -> None
        :param user_data_callback: function() -> dict with keys 'name', 'type', 'image_path'
        :param selected_user: optional static user data when callback is not provided
        """
        super().__init__(root, page_id, switch_page_callback)
        self.prev_page = prev_page
        self.change_pass_callback = change_pass_callback
        self.remove_user_callback = remove_user_callback
        self.user_data_callback = user_data_callback
        self.selected_user = selected_user

        # Clear default label
        self.label.pack_forget()

        # User Icon
        self.icon_label = tk.Label(self.frame)
        self.icon_label.pack(pady=10)

        # User Info Labels
        self.name_label = tk.Label(self.frame, text="Name: ")
        self.name_label.pack(pady=2)
        self.type_label = tk.Label(self.frame, text="Type: ")
        self.type_label.pack(pady=2)

        # Change password button
        self.change_pw_button = tk.Button(
            self.frame, text="Change Password", command=self._change_password
        )
        self.change_pw_button.pack(pady=5)

        # Delete user button
        self.delete_user_button = tk.Button(
            self.frame, text="Delete User", command=self._delete_user
        )
        self.delete_user_button.pack(pady=5)

        # Return button
        self.return_button = tk.Button(self.frame, text="Return", command=self._return)
        self.return_button.pack(pady=5)

        # Message label for status
        self.status_label = tk.Label(self.frame, text="", fg="red")
        self.status_label.pack(pady=5)

    def _get_current_user(self):
        if self.user_data_callback:
            return self.user_data_callback()
        return self.selected_user

    def _change_password(self):
        user = self._get_current_user()
        if user and self.change_pass_callback:
            change_pass_page = SetUserNewPassPage(
                self.root, submit_callback=lambda new_pw: self.change_pass_callback(user, new_pw)
            )
            change_pass_page.drawPage()

    def _delete_user(self):
        user = self._get_current_user()
        if not user:
            return
        if user.get("type") == "Homeowner":
            self.status_label.config(text="Cannot delete Homeowner!")
            return
        if self.remove_user_callback:
            self.remove_user_callback(user)

    def drawPage(self):
        """Update display with current user info whenever page is drawn."""
        super().drawPage()
        user = self._get_current_user()
        if not user:
            self.status_label.config(text="No user data available")
            return

        self.name_label.config(text=f"Name: {user.get('name', '')}")
        self.type_label.config(text=f"Type: {user.get('type', '')}")

        # Load user icon with circular crop
        try:
            image_path = user.get("image_path", "")
            if image_path:
                image = Image.open(image_path).resize((100, 100))
                mask = Image.new("L", (100, 100), 0)
                draw = ImageDraw.Draw(mask)
                draw.ellipse((0, 0, 100, 100), fill=255)
                image.putalpha(mask)
                self.user_icon = ImageTk.PhotoImage(image)
                self.icon_label.config(image=self.user_icon)
        except Exception as e:
            self.status_label.config(text=f"Failed to load icon: {e}")
