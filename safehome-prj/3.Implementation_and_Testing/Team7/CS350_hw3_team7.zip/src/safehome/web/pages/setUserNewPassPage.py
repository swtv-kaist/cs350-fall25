# web/pages/setUserNewPassPage.py
import tkinter as tk
from ..page import Page


class SetUserNewPassPage(Page):
    def __init__(
        self,
        root,
        submit_callback=None,  # submit_callback(new_password)
    ):
        self.root = root
        self.window = tk.Toplevel(root)  # create a new window
        self.window.title("Set New User")
        self.window.geometry("400x300")

        self.submit_callback = submit_callback

        # Title
        tk.Label(self.window, text="Set New Password", font=("Arial", 16)).pack(pady=10)

        # New password
        tk.Label(self.window, text="New Password:").pack(pady=5)
        self.new_pass_entry = tk.Entry(self.window, show="*")
        self.new_pass_entry.pack(pady=5)

        # Confirm new password
        tk.Label(self.window, text="Confirm Password:").pack(pady=5)
        self.confirm_pass_entry = tk.Entry(self.window, show="*")
        self.confirm_pass_entry.pack(pady=5)

        # Submit button
        self.submit_button = tk.Button(self.window, text="Submit", command=self._submit)
        self.submit_button.pack(pady=10)

        # Status label
        self.status_label = tk.Label(self.window, text="", fg="red")
        self.status_label.pack(pady=5)

        # Return button
        self.return_button = tk.Button(self.window, text="Return", command=self._cancel)
        self.return_button.pack(pady=5)

    def drawPage(self):
        self.window.tkraise()  # bring this page to front

    def _cancel(self):
        self.window.destroy()

    def _submit(self):
        """Validate and call callback"""
        new_pw = self.new_pass_entry.get()
        confirm_pw = self.confirm_pass_entry.get()

        if not new_pw or not confirm_pw:
            self.status_label.config(text="Please fill all fields", fg="red")
            return

        if new_pw != confirm_pw:
            self.status_label.config(text="Passwords do not match", fg="red")
            return

        # Callback
        if self.submit_callback:
            self.submit_callback(new_pw)

        self.status_label.config(text="Password updated successfully!", fg="green")
        self._cancel()

    def setPageParameters(self, parameters=None):
        """
        Optional: allow system to prefill or clear fields.
        Example parameters: {"clear": True}
        """
        if parameters and parameters.get("clear"):
            self.new_pass_entry.delete(0, tk.END)
            self.confirm_pass_entry.delete(0, tk.END)
        print(f"[DEBUG] SetUserNewPassPage setPageParameters called with: {parameters}")
