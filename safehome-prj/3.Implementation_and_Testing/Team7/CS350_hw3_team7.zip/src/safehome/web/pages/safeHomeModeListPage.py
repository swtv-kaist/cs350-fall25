import tkinter as tk
from ..page import Page  # adjust import depending on your package
from .safeHomeModeConfigPage import SafeHomeModeConfigPage


class SafeHomeModeListPage(Page):
    def __init__(
        self,
        root,
        page_id=0,
        current_mode="Home",
        on_change_mode_callback=None,
        on_configure_mode_callback=None,
        prev_page=None,
        switch_page_callback=None,
    ):
        super().__init__(root, page_id, switch_page_callback)

        self.current_mode = current_mode
        self.on_change_mode_callback = on_change_mode_callback
        self.on_configure_mode_callback = on_configure_mode_callback
        self.prev_page = prev_page

        # Clear default label from Page
        self.label.pack_forget()

        self.modes = {
            "Home": "Arms perimeter sensors while you are inside the house.",
            "Away": "Arms all sensors including motion detectors.",
            "Overnight Travel": "Full arm mode with night-optimized sensitivity.",
            "Extended Travel": "Maximum security mode with extra notifications.",
        }

        # Change this to fetch from storage in future
        self.mode_infos = [
            {"id": 1, "name": "Home", "sensor_list": []},
            {"id": 2, "name": "Away", "sensor_list": []},
            {"id": 3, "name": "Overnight Travel", "sensor_list": []},
            {"id": 4, "name": "Extended Travel", "sensor_list": []},
        ]
        self.selected_mode = tk.StringVar(value=current_mode)

        self._build_ui()

    def _build_ui(self):
        # ---------- Title ----------
        tk.Label(self.frame, text="Current Safe Home Mode", font=("Arial", 16, "bold")).pack(
            pady=10
        )

        # ---------- Current Mode Label ----------
        self.current_mode_label = tk.Label(
            self.frame, text=f"Current Mode: {self.current_mode}", font=("Arial", 13)
        )
        self.current_mode_label.pack(pady=10)

        # ---------- Modes List ----------
        modes_frame = tk.Frame(self.frame)
        modes_frame.pack(fill="both", expand=False, pady=(0, 5))

        for mode, desc in self.modes.items():
            self._create_mode_option(modes_frame, mode, desc)

        # ---------- Change Mode Button ----------
        tk.Button(self.frame, text="Change Mode", command=self._on_change_mode_pressed).pack(
            pady=(1, 5)
        )

        tk.Button(self.frame, text="Return", command=self._return).pack(pady=(5, 10))

        # Message label for status
        self.status_label = tk.Label(self.frame, text="", fg="red")
        self.status_label.pack(pady=5)

    def get_mode_info(self, mode_name):
        for mode in self.mode_infos:
            if mode["name"] == mode_name:
                return mode
        return None

    def _create_mode_option(self, parent, mode_name, mode_desc):
        """Single mode selection block."""
        block = tk.Frame(parent, bd=1, relief="solid", padx=12, pady=10)
        block.pack(fill="x", pady=5)

        # Radio button
        rb = tk.Radiobutton(
            block,
            text=mode_name,
            variable=self.selected_mode,
            value=mode_name,
            font=("Arial", 12, "bold"),
        )
        rb.pack(anchor="w")

        # Description
        tk.Label(block, text=mode_desc, font=("Arial", 10), fg="gray").pack(anchor="w", pady=4)

        # Configure button
        tk.Button(
            block,
            text="Configure this mode",
            command=lambda m=mode_name: self._on_configure_pressed(m),
        ).pack(anchor="e")

    def _on_change_mode_pressed(self):
        new_mode = self.selected_mode.get()
        self.current_mode_label.config(text=f"Current Mode: {new_mode}")

        if self.on_change_mode_callback:
            self.on_change_mode_callback(new_mode)

    def _on_configure_pressed(self, mode_name):
        selected_mode = self.get_mode_info(mode_name)
        safeHomeModeConfigPage = SafeHomeModeConfigPage(
            self.root, selected_mode=selected_mode, mode_infos=self.mode_infos
        )
        safeHomeModeConfigPage.drawPage()

        # if self.on_configure_mode_callback:
        #     self.on_configure_mode_callback(mode_name)
