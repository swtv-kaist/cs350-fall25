import tkinter as tk
from ...page import Page
from ...SafetyZone import SafetyZoneView
from .setNewSafetyZonePage import SetNewSafetyZonePage
from .singleSafetyZonePage import SingleSafetyZonePage
import os

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../.."))


class SafetyZoneListPage(Page):
    def __init__(
        self,
        root,
        page_id=0,
        switch_page_callback=None,
        safetyZone_add_callback=None,
        safetyZone_click_callback=None,
        safetyZone_remove_callback=None,
        safetyZone_update_callback=None,
        prev_page=None,
    ):
        """
        :param switch_page_callback: function to switch page in WebInterface
        :param point_click_callback: function(point_id) called when a floor point is clicked
        :param floor_image_path: optional blueprint image path
        """
        super().__init__(root, page_id)
        self.switch_page_callback = switch_page_callback
        self.safetyZone_add_callback = safetyZone_add_callback
        self.safetyZone_click_callback = safetyZone_click_callback
        self.safetyZone_remove_callback = safetyZone_remove_callback
        self.safetyZone_update_callback = safetyZone_update_callback

        self.prev_page = prev_page

        # Clear default label
        self.label.pack_forget()

        # Title
        tk.Label(self.frame, text="All Safety Zones", font=("Arial", 16)).pack(pady=10)

        top_btn_frame = tk.Frame(self.frame)
        top_btn_frame.pack(pady=5)

        self.add_zone_button = tk.Button(
            top_btn_frame, text="Add Safety Zone", command=self._on_add_zone
        )
        self.add_zone_button.grid(row=0, column=1, padx=10)

        # Floor Plan View
        self.floor = SafetyZoneView(
            self.frame,
            safetyZone_add_callback=safetyZone_add_callback,
            safetyZone_click_callback=self._on_click,
            safetyZone_remove_callback=safetyZone_remove_callback,
            safetyZone_update_callback=safetyZone_update_callback,
        )

        self.floor.pack(pady=10)

        # Return button
        self.return_button = tk.Button(self.frame, text="Return", command=self._return)
        self.return_button.pack(pady=5)

        # Message label for status
        self.status_label = tk.Label(self.frame, text="", fg="red")
        self.status_label.pack(pady=5)

    def _on_add_zone(self):
        print("Add Safety Zone button clicked")
        new_zone_page = SetNewSafetyZonePage(
            self.root,
            switch_page_callback=self.switch_page_callback,
            safetyZone_add_callback=self.add_zone,
            safetyZone_click_callback=self.safetyZone_click_callback,
            safetyZone_remove_callback=self.safetyZone_remove_callback,
            safetyZone_update_callback=self.safetyZone_update_callback,
        )
        new_zone_page.drawPage()
        # if self.floor.safetyZone_add_callback:
        #     self.floor.safetyZone_add_callback()

    def _on_click(self, zone_id):
        print(f"Safety Zone clicked: {zone_id}")
        single_zone_page = SingleSafetyZonePage(
            self.root,
            selected_zone=self.floor.get_zone_by_id(zone_id),
            safetyZone_remove_callback=self.remove_zone,
        )
        single_zone_page.drawPage()

    def drawPage(self):
        super().drawPage()
        self.floor.draw_all_zones()
        self.floor.allow_zone_clicks()

    def add_zone(self, zone_data):
        self.floor.add_zone(zone_data)
        self.drawPage()

    def remove_zone(self, zone_data):
        self.floor.remove_zone(zone_data)
        self.drawPage()
