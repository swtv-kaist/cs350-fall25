# web/pages/setNewUserPage.py
import tkinter as tk
from tkinter import filedialog
from ..page import Page  # base Page class


class SetNewUserPage(Page):
    def __init__(self, root, submit_callback=None, user_image_callback=None):
        """
        submit_callback: function(username, password, user_type, user_image_path)
                         called when user submits the new user form
        user_image_callback: function() -> str, returns path to selected image
        """
        self.root = root
        self.window = tk.Toplevel(root)  # create a new window
        self.window.title("Set New User")
        self.window.geometry("400x500")
        self.submit_callback = submit_callback
        # default user image callback opens file dialog
        self.user_image_callback = user_image_callback or self.default_user_image_callback

        # Username
        tk.Label(self.window, text="Username:").pack(pady=5)
        self.username_entry = tk.Entry(self.window)
        self.username_entry.pack(pady=5)

        # Password
        tk.Label(self.window, text="Password:").pack(pady=5)
        self.password_entry = tk.Entry(self.window, show="*")
        self.password_entry.pack(pady=5)

        # Confirm Password
        tk.Label(self.window, text="Confirm Password:").pack(pady=5)
        self.confirm_password_entry = tk.Entry(self.window, show="*")
        self.confirm_password_entry.pack(pady=5)

        # User Type
        tk.Label(self.window, text="User Type:").pack(pady=5)
        self.user_type_var = tk.StringVar(value="Guest")
        tk.Radiobutton(self.window, text="Guest", variable=self.user_type_var, value="Guest").pack()
        tk.Radiobutton(
            self.window, text="Homeowner", variable=self.user_type_var, value="Homeowner"
        ).pack()

        # User image selection
        tk.Label(self.window, text="User Image:").pack(pady=5)
        self.user_image_path = ""
        self.image_button = tk.Button(
            self.window, text="Select Image", command=self._select_user_image
        )
        self.image_button.pack(pady=5)

        # Submit button
        self.submit_button = tk.Button(self.window, text="Submit", command=self._submit)
        self.submit_button.pack(pady=10)

        # Status label
        self.status_label = tk.Label(self.window, text="", fg="red")
        self.status_label.pack(pady=5)

        # Return button
        self.return_button = tk.Button(self.window, text="Return", command=self._cancel)
        self.return_button.pack(pady=5)

    def _select_user_image(self):
        path = self.user_image_callback()
        if path:
            self.user_image_path = path
            self.status_label.config(text=f"Selected image: {path}")

    @staticmethod
    def default_user_image_callback():
        """Default function opens file dialog to select image"""
        return filedialog.askopenfilename(
            title="Select User Image", filetypes=[("Image files", "*.png *.jpg *.jpeg *.bmp *.gif")]
        )

    def drawPage(self):
        self.window.tkraise()  # bring this page to front

    def _cancel(self):
        self.window.destroy()

    def _submit(self):
        username = self.username_entry.get().strip()
        password = self.password_entry.get()
        confirm_password = self.confirm_password_entry.get()
        user_type = self.user_type_var.get()
        user_image = self.user_image_path

        # Validation
        if not username or not password or not confirm_password:
            self.status_label.config(text="Please fill all fields")
            return
        if password != confirm_password:
            self.status_label.config(text="Passwords do not match")
            return
        if not user_image:
            self.status_label.config(text="Please select a user image")
            return

        # Call submit callback
        if self.submit_callback:
            self.submit_callback(username, password, user_type, user_image)
        self.status_label.config(text="User submitted successfully!")
        self._cancel()

    def setPageParameters(self, parameters=None):
        """Optional: show messages or preset values"""
        if parameters:
            self.username_entry.delete(0, tk.END)
            self.username_entry.insert(0, parameters.get("username", ""))
            self.password_entry.delete(0, tk.END)
            self.confirm_password_entry.delete(0, tk.END)
            self.user_type_var.set(parameters.get("type", "Guest"))
            self.user_image_path = parameters.get("image_path", "")
            if self.user_image_path:
                self.status_label.config(text=f"Selected image: {self.user_image_path}")
        print(f"[DEBUG] SetNewUserPage received parameters: {parameters}")
