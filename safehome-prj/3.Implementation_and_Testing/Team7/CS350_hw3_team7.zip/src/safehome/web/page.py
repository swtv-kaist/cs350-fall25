import tkinter as tk


class Page:
    def __init__(self, root, page_id=0, switch_page_callback=None):
        self.root = root  # Tk root or parent frame
        self._id = page_id  # Page ID
        self.frame = tk.Frame(root)
        self.frame.place(relx=0, rely=0, relwidth=1, relheight=1)
        self.frame.lower()  # hide initially
        # self.frame.config(bg="white")

        self.label = tk.Label(self.frame, text=f"Page {self._id}")
        self.label.pack(pady=10)

        self.switch_page_callback = switch_page_callback

        # Header
        self.header_frame = tk.Frame(self.frame, bg="lightblue", height=40)
        self.header_frame.pack(fill="x")

        self.home_btn = tk.Button(self.header_frame, text="Home", command=self._on_home)
        self.home_btn.pack(side="left", padx=5, pady=5)

        self.security_btn = tk.Button(self.header_frame, text="Security", command=self._on_security)
        self.security_btn.pack(side="left", padx=5, pady=5)

        self.camera_btn = tk.Button(self.header_frame, text="Camera", command=self._on_camera)
        self.camera_btn.pack(side="left", padx=5, pady=5)

        self.user_btn = tk.Button(self.header_frame, text="User", command=self._on_user)
        self.user_btn.pack(side="left", padx=5, pady=5)

        self.user_btn = tk.Button(self.header_frame, text="Log out", command=self._on_logout)
        self.user_btn.pack(side="left", padx=5, pady=5)

        # # Content area below header
        # self.content_frame = tk.Frame(self.frame, width=800, height=560)
        # self.content_frame.pack(fill='both', expand=True)
        # self.content_frame.pack_propagate(False)

        # Placeholder for parameters and video
        self.system_callback = None
        self.parameters = None
        self.video_frames = []

        self.prev_page = None  # previous page for return functionality

        self.status_label = tk.Label(self.frame, text="", fg="red")
        self.status_label.pack(pady=5)

    # Default header callbacks (subclasses can override)
    def _on_home(self):
        print("Home clicked")
        self.switch_page_callback("home")

    def _on_security(self):
        print("Security clicked")
        self.switch_page_callback("security")

    def _on_camera(self):
        print("Camera clicked")
        self.switch_page_callback("camera")

    def _on_user(self):
        print("User clicked")
        self.switch_page_callback("user_settings")

    def _on_logout(self):
        print("Log out clicked")
        self.switch_page_callback("login")

    # Draw / raise the page
    def drawPage(self):
        self.frame.tkraise()  # bring this page to front
        self.update_label()
        print(f"[DEBUG] Drawing Page {self._id}")

    def update_label(self):
        text = f"Page {self._id}"
        if self.parameters:
            text += f" Params: {self.parameters}"
        self.label.config(text=text)

    # Get and set page ID
    def getID(self):
        return self._id

    def setID(self, page_id):
        self._id = page_id
        self.update_label()

    def _return(self):
        """Go back to previous page."""
        print("Returning to previous page")
        # self.frame.pack_forget()
        if self.prev_page:
            self.switch_page_callback(self.prev_page)
        else:
            self.status_label.config(text="No previous page to return to.", fg="red")

    # Set parameters from system
    def setPageParameters(self, parameters):
        self.parameters = parameters
        self.update_label()
        print(f"[DEBUG] Page {self._id} received parameters: {parameters}")

    # Receive message from system
    def receive_message(self, message):
        print(f"[DEBUG] Page {self._id} received system message: {message}")

    # Receive video frames
    def receive_video(self, frames):
        self.video_frames = frames
        print(f"[DEBUG] Page {self._id} received {len(frames)} video frames")
