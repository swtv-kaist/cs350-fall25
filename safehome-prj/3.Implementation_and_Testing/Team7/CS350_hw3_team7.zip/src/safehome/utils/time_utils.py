from datetime import datetime


def current_timestamp() -> str:
    """
    Returns the current system time formatted as:
    YYYY-MM-DD HH:MM:SS
    """
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
