"""
Improved Camera System with Password Sessions
"""

from typing import List, Optional

from ..virtual_device_v3.device.device_camera import DeviceCamera


class Camera:
    """
    Wrapper around DeviceCamera with password protection and enable/disable state.
    """

    def __init__(
        self,
        camera_id: int,
        location: List[int],
        is_enabled: int = 0,
        password: Optional[str] = "",
        zoom=2,
        pan=0,
    ):
        """
        Initialize a Camera.

        Args:
            camera_id: Unique camera identifier
            location: [x, y] coordinates
            is_enabled: Whether camera is enabled
            password: Optional password (will be hashed)
        """

        self._device = DeviceCamera()

        self._device.set_id(camera_id)
        self._device.zoom = zoom
        self._device.pan = pan

        self._camera_id = camera_id
        self._location = location.copy()  # Copy to prevent external modification
        self._is_enabled = False if is_enabled == 0 else True

        # Store hashed password (never store plaintext!)
        self._password = None if password == "" else password
        self._has_password = self._password is not None

    # =========================================================================
    # Password Management
    # =========================================================================

    def has_password(self) -> bool:
        """Check if camera is password protected"""
        return self._has_password

    def verify_password(self, password: str) -> bool:
        if not self._has_password:
            return True  # No password required

        if password is None:
            return False

        return self._password == password

    def set_password(self, new_password: Optional[str] = ""):
        if new_password != "":
            self._password = new_password
            self._has_password = True
        else:
            self._password = None
            self._has_password = False

    def remove_password(self):
        self._password = None
        self._has_password = False

    # =========================================================================
    # Camera State
    # =========================================================================

    def is_enabled(self) -> bool:
        """Check if camera is enabled"""
        return self._is_enabled

    def enable(self):
        """Enable the camera"""
        self._is_enabled = True

    def disable(self):
        """Disable the camera"""
        self._is_enabled = False

    def get_id(self) -> int:
        """Get camera ID"""
        return self._camera_id

    def get_location(self) -> List[int]:
        """Get camera location (returns copy)"""
        return self._location.copy()

    # =========================================================================
    # Camera Operations (Delegated to DeviceCamera)
    # =========================================================================

    def get_view(self):
        """Get camera view image (requires camera to be enabled)"""
        if not self._is_enabled:
            return None
        return self._device.get_view()

    def pan_right(self) -> bool:
        """Pan camera right (requires enabled)"""
        if not self._is_enabled:
            return False
        return self._device.pan_right()

    def pan_left(self) -> bool:
        """Pan camera left (requires enabled)"""
        if not self._is_enabled:
            return False
        return self._device.pan_left()

    def zoom_in(self) -> bool:
        """Zoom in (requires enabled)"""
        if not self._is_enabled:
            return False
        return self._device.zoom_in()

    def zoom_out(self) -> bool:
        """Zoom out (requires enabled)"""
        if not self._is_enabled:
            return False
        return self._device.zoom_out()

    def stop(self):
        """Stop the camera device thread"""
        self._device.stop()

    def to_dict(self) -> dict:
        """Convert to dictionary for storage"""
        return {
            "camera_id": self._camera_id,
            "location": self._location,
            "is_enabled": 0 if not self._is_enabled else 1,
            "password": self._password if self._password != None else "",
            "zoom": self._device.zoom,
            "pan": self._device.pan,
        }

    @staticmethod
    def from_dict(data: dict) -> "Camera":
        return Camera(
            camera_id=data["camera_id"],
            location=data["location"],
            is_enabled=data["is_enabled"],
            password=data["password"],
            zoom=data["zoom"],
            pan=data["pan"],
        )
