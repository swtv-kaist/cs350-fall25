from typing import List, Optional
from .Camera import Camera
from ..storage.StorageManager import StorageManager


class CameraManager:
    def __init__(self, storage_dir: str = "Storage"):
        self.storage = StorageManager(storage_dir)
        self._cameras: List[Camera] = []
        self.load_cameras()

    def load_cameras(self):
        """Load default cameras"""
        cameras_data = self.storage.load_json("cameras") or []
        self._cameras = [Camera.from_dict(d) for d in cameras_data]

    def save_cameras(self) -> bool:
        data_list = [c.to_dict() for c in self._cameras]
        return self.storage.save_json("cameras", data_list)

    # =========================================================================
    # Camera Access
    # =========================================================================

    def get_camera_by_id(self, camera_id: int, password: Optional[str] = None) -> Camera:
        for c in self._cameras:
            if c.get_id() == camera_id:
                # if not c.verify_password(password):
                #     return None
                return c

    def get_all_cameras(self, password_list=None):
        cameras = []
        for i in range(3):
            if password_list:
                cam = self.get_camera_by_id(i + 1, password_list[i])
            else:
                cam = self.get_camera_by_id(i + 1)
            cameras.append(cam)
        return cameras
