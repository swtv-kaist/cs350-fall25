# storage_manager.py
import json
from pathlib import Path
from typing import Any


class StorageManager:
    """
    StorageManager: Handles reading/writing JSON files in a dedicated storage directory.
    All objects (users, settings, zones, modes) are persisted as JSON.
    """

    def __init__(self, storage_dir: str = "Storage"):  # Storage directory
        self.base_path = Path(storage_dir)
        self.base_path.mkdir(exist_ok=True)  # Ensure folder exists

    # -----------------------------------------------------------
    # Low-level JSON helpers
    # -----------------------------------------------------------

    def _file(self, name: str) -> Path:
        return self.base_path / f"{name}.json"

    def load_json(self, name: str) -> Any:
        file_path = self._file(name)
        if not file_path.exists() or file_path.stat().st_size == 0:
            return None  # file does not exist or empty
        with open(file_path, "r", encoding="utf-8") as f:
            return json.load(f)

    def save_json(self, name: str, data: Any) -> bool:
        try:
            file_path = self._file(name)
            with open(file_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=4)
            return True
        except Exception:
            return False
