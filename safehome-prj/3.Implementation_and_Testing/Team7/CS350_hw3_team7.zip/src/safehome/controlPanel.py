import sys
import tkinter as tk
from pathlib import Path

# Add parent directory to path for direct script execution
if __name__ == "__main__":
    current_dir = Path(__file__).resolve().parent
    parent_dir = current_dir.parent
    if str(parent_dir) not in sys.path:
        sys.path.insert(0, str(parent_dir))

# Try relative import first (for package execution), fall back to absolute
try:
    from safehome.virtual_device_v3.device.device_control_panel_abstract import (
        DeviceControlPanelAbstract,
    )
except ImportError:
    from ..safehome.virtual_device_v3.device.device_control_panel_abstract import (
        DeviceControlPanelAbstract,
    )

# def system_callback(funct, input):
#     if funct == "login":
#         # TODO
#     elif funct == "cur_mode": # change to mode = input
#     elif funct == "mode": # change to mode = input
#         # TODO
#     elif funct == "on":
#         # TODO
#     elif funct == "off":
#     elif funct == "chnage_pass"
#     elif funct == "panic"


# control panel status: login, main, mode, change_pass
class MyControlPanel(DeviceControlPanelAbstract):
    def __init__(self, master=None, system_callback=None):
        self.system_callback = system_callback
        self.status = "login"
        self.passEnt = ["Enter Password:", "Enter New Password:"]
        self.button_sequence = ""
        super().__init__()

        # 1. Locate the parent's button_frame using place geometry
        button_frame = None
        for w in self.winfo_children():
            if isinstance(w, tk.Frame):
                info = w.place_info()
                if info.get("x") == "300" and info.get("y") == "6":
                    button_frame = w
                    break

        # 2. Remove row-0 widgets
        if button_frame:
            button_frame.grid_slaves(row=0, column=0)[0].config(text="  mode")
            button_frame.grid_slaves(row=0, column=2)[0].config(text="     on")
            button_frame.grid_slaves(row=0, column=4)[0].config(text="    off")

            button_frame.grid_slaves(row=2, column=0)[0].config(text="   arm")
            button_frame.grid_slaves(row=2, column=2)[0].config(text="    dis")
            button_frame.grid_slaves(row=2, column=4)[0].config(text="   pass")

            button_frame.grid_slaves(row=4, column=0)[0].config(text="  reset")
            button_frame.grid_slaves(row=4, column=2)[0].config(text="")
            button_frame.grid_slaves(row=4, column=4)[0].config(text="   ret")

        self.set_display_short_message1("System Ready")
        self.set_display_short_message2("Enter Password")
        self.set_powered_led(True)
        self.set_armed_led(True)

        # Bind the close event to your custom handler
        self.protocol("WM_DELETE_WINDOW", self.on_close)

        self.current_mode = "Home"

    def on_close(self):
        """Close Toplevel and exit safely."""
        self.destroy()
        root = self.master
        if isinstance(root, tk.Tk):
            root.destroy()
        import sys

        sys.exit(0)

    def set_main_display(self):
        self.set_display_short_message1("SafeHome")
        self.set_display_short_message2(
            "1 - Change Mode\
                                        2 - Turn on\
                                        3 - Turn off\
                                        4 - Arm System\
                                        5 - Disarm System\
                                        6 - Change Password\
                                        7 - Log out"
        )

    def set_mode_display(self, mode):
        self.set_display_short_message1(
            f"Select Mode\
                                            Current Mode: {mode}"
        )
        self.set_display_short_message2(
            "1 - Home\
                                        2 - Away\
                                        3 - Overnight travel\
                                        4 - Extended Travel"
        )

    def set_change_pass_display(self):
        self.set_display_short_message1("System Ready")
        self.set_display_short_message2("Enter New Password")

    def _update_display_text(self):
        super()._update_display_text()
        if len(self.button_sequence) == 4 and self.status == "login":
            if self.system_callback:
                result = self.system_callback("login", self.button_sequence)
                if result:
                    self.status = "main"
                    self.set_main_display()

                else:
                    self.set_display_short_message2("Wrong Password. Please enter password again")

                self.button_sequence = ""
                super()._update_display_text()
            else:
                print("[controlPanel] No callback for login control panel")
                # REMOVE THIS----
                self.status = "main"
                self.set_main_display()
                # ---------------
                self.button_sequence = ""
                super()._update_display_text()

        if len(self.button_sequence) == 4 and self.status == "change_pass":
            self.status = "conf_pass"
            self.set_display_short_message1(f"Confirm Password: {self.button_sequence}")
            self.set_display_short_message2(
                "1 - Confirm\
                                            2 - Cancel"
            )

    def button1(self):
        print("Button 1 pressed")
        if self.status == "login" or self.status == "change_pass":
            passEnt = self.passEnt[0] if self.status == "login" else self.passEnt[1]
            self.button_sequence += "1"
            self.set_display_short_message2(f"{passEnt} {self.button_sequence}")
        elif self.status == "main":
            self.status = "mode"
            if self.system_callback:
                self.current_mode = self.system_callback("cur_mode", [])

            self.set_mode_display(self.current_mode)

        elif self.status == "mode":
            if self.system_callback:
                new_mode = self.system_callback("mode", "Home")  # Edit this
            else:
                new_mode = "Home"
            self.current_mode = new_mode
            self.set_mode_display(new_mode)
        elif self.status == "conf_pass":
            if self.system_callback:
                self.system_callback("change_pass", self.button_sequence)
            else:
                print("[controlPanel] No callback for change password control panel")
            self.status = "main"
            self.set_main_display()

    def button2(self):
        print("Button 2 pressed")
        if self.status == "login" or self.status == "change_pass":
            passEnt = self.passEnt[0] if self.status == "login" else self.passEnt[1]
            self.button_sequence += "2"
            self.set_display_short_message2(f"{passEnt} {self.button_sequence}")
        elif self.status == "main":
            self.set_powered_led(True)
            if self.system_callback:
                self.system_callback("on", [])
            else:
                print("[controlPanel] No callback for turn on control panel")
        elif self.status == "mode":
            if self.system_callback:
                new_mode = self.system_callback("mode", "Away")  # Edit this
            else:
                new_mode = "Away"
            self.current_mode = new_mode
            self.set_mode_display(new_mode)
        elif self.status == "conf_pass":
            self.status = "main"
            self.set_main_display()

    def button3(self):
        print("Button 3 pressed")
        if self.status == "login" or self.status == "change_pass":
            passEnt = self.passEnt[0] if self.status == "login" else self.passEnt[1]
            self.button_sequence += "3"
            self.set_display_short_message2(f"{passEnt} {self.button_sequence}")
        elif self.status == "main":
            self.set_powered_led(False)
            if self.system_callback:
                self.system_callback("off", [])
            else:
                print("[controlPanel] No callback for turn off control panel")
        elif self.status == "mode":
            if self.system_callback:
                new_mode = self.system_callback("mode", "Overnight travel")  # Edit this
            else:
                new_mode = "Overnight travel"
            self.current_mode = new_mode
            self.set_mode_display(new_mode)

        # # Simulate arming after 1-2-3
        # if self.button_sequence == "123":
        #     self.set_armed_led(True)
        #     self.set_display_away(True)
        #     self.set_display_short_message1("System Armed")

    def button4(self):
        print("Button 4 pressed")
        if self.status == "login" or self.status == "change_pass":
            passEnt = self.passEnt[0] if self.status == "login" else self.passEnt[1]
            self.button_sequence += "4"
            self.set_display_short_message2(f"{passEnt} {self.button_sequence}")
        elif self.status == "main":
            self.set_armed_led(True)
            if self.system_callback:
                self.system_callback("arm", [])
            else:
                print("[controlPanel] No callback for arm control panel")
        elif self.status == "mode":
            if self.system_callback:
                new_mode = self.system_callback("mode", "Extended Travel")  # Edit this
            else:
                new_mode = "Extended Travel"
            self.current_mode = new_mode
            self.set_mode_display(new_mode)

    def button5(self):
        print("Button 5 pressed")
        if self.status == "login" or self.status == "change_pass":
            passEnt = self.passEnt[0] if self.status == "login" else self.passEnt[1]
            self.button_sequence += "5"
            self.set_display_short_message2(f"{passEnt} {self.button_sequence}")
        elif self.status == "main":
            self.set_armed_led(False)
            if self.system_callback:
                self.system_callback("disarm", [])
            else:
                print("[controlPanel] No callback for disarm control panel")

    def button6(self):
        print("Button 6 pressed")
        if self.status == "login" or self.status == "change_pass":
            passEnt = self.passEnt[0] if self.status == "login" else self.passEnt[1]
            self.button_sequence += "6"
            self.set_display_short_message2(f"{passEnt} {self.button_sequence}")
        elif self.status == "main":
            self.status = "change_pass"
            self.button_sequence = ""
            self.set_change_pass_display()

    def button7(self):
        print("Button 7 pressed")
        if self.status == "login" or self.status == "change_pass":
            passEnt = self.passEnt[0] if self.status == "login" else self.passEnt[1]
            self.button_sequence += "7"
            self.set_display_short_message2(f"{passEnt} {self.button_sequence}")
        elif self.status == "main":
            self.status = "login"
            self.button_sequence = ""
            self.set_display_away(False)
            self.set_display_stay(False)
            self.set_display_not_ready(False)
            self.set_display_short_message1("System Ready")
            self.set_display_short_message2("Enter Password")

    def button8(self):
        print("Button 8 pressed")
        if self.status == "login" or self.status == "change_pass":
            passEnt = self.passEnt[0] if self.status == "login" else self.passEnt[1]
            self.button_sequence += "8"
            self.set_display_short_message2(f"{passEnt} {self.button_sequence}")

    def button9(self):
        print("Button 9 pressed")
        if self.status == "login" or self.status == "change_pass":
            passEnt = self.passEnt[0] if self.status == "login" else self.passEnt[1]
            self.button_sequence += "9"
            self.set_display_short_message2(f"{passEnt} {self.button_sequence}")
        elif self.status == "mode" or self.status == "conf_pass":
            self.status = "main"
            self.set_main_display()
        elif self.status == "panic":
            self._reset_to_login_display()

    def button_star(self):
        print("Button * pressed (Panic)")
        self.set_armed_led(True)
        self.set_display_short_message1("PANIC ALARM!")
        self.set_display_short_message2("Help on the way")
        self.status = "panic"

    def button0(self):
        print("Button 0 pressed")
        if self.status == "login" or self.status == "change_pass":
            passEnt = self.passEnt[0] if self.status == "login" else self.passEnt[1]
            self.button_sequence += "0"
            self.set_display_short_message2(f"{passEnt} {self.button_sequence}")

    def button_sharp(self):
        print("Button # pressed (Reset/Panic)")
        if self.status in {"login", "panic"}:
            self._reset_to_login_display()
            return

        # Treat # as alternate panic trigger when system is armed
        self.button_star()

    def _reset_to_login_display(self):
        self.status = "login"
        self.button_sequence = ""
        self.set_display_away(False)
        self.set_display_stay(False)
        self.set_display_not_ready(False)
        self.set_display_short_message1("System Ready")
        self.set_display_short_message2("Enter Password")
