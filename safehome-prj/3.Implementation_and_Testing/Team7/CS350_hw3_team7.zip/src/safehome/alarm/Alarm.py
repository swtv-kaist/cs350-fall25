class Alarm:
    def __init__(self):
        self.is_alert = False

    def up_alarm(self):
        self.is_alert = True

    def down_alarm(self):
        self.is_alert = False

    def read_alarm(self):
        return self.is_alert
