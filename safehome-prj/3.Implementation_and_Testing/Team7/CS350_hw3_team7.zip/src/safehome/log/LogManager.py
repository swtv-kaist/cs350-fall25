# log_manager.py

from typing import List, Optional
from ..storage.StorageManager import StorageManager
from .Log import Log


class LogManager:
    """
    LogManager: Handles creation, storage, retrieval of Log entries.
    Uses StorageManager JSON persistence.
    """

    def __init__(self, storage_dir: str = "Storage"):
        self.storage = StorageManager(storage_dir)

    # ------------------ Internal helpers ------------------

    def _load_logs(self) -> List[dict]:
        return self.storage.load_json("logs") or []

    def _save_logs(self, logs: List[dict]) -> bool:
        return self.storage.save_json("logs", logs)

    # ------------------ Public API ------------------

    def saveLog(self, log: Log) -> bool:
        logs = self._load_logs()
        logs.append(log.to_dict())
        return self._save_logs(logs)

    def getLogList(self) -> List[Log]:
        logs = self._load_logs()
        return [Log.from_dict(entry) for entry in logs]

    def findLog(self, log_id: int) -> Optional[Log]:
        logs = self._load_logs()
        for entry in logs:
            if entry.get("id") == log_id:
                return Log.from_dict(entry)
        return None

    def deleteLog(self, log_id: int) -> bool:
        logs = self._load_logs()
        new_logs = [entry for entry in logs if entry.get("id") != log_id]

        if len(new_logs) == len(logs):
            return False  # nothing deleted

        return self._save_logs(new_logs)
