# log.py


class Log:
    """
    Log: Represents a single log entry.
    Fields:
      - id: int
      - datetime: str
      - description: str
    """

    def __init__(self, log_id: int, datetime: str, description: str):
        self._id = log_id
        self._datetime = datetime
        self._description = description

    # ------------------ ID ------------------
    def setID(self, log_id: int) -> None:
        self._id = log_id

    def getID(self) -> int:
        return self._id

    # ------------------ DateTime ------------------
    def setDateTime(self, datetime: str) -> None:
        self._datetime = datetime

    def getDateTime(self) -> str:
        return self._datetime

    # ------------------ Description ------------------
    def setDescription(self, desc: str) -> None:
        self._description = desc

    def getDescription(self) -> str:
        return self._description

    # ------------------ Serialization ------------------
    def to_dict(self) -> dict:
        return {"id": self._id, "datetime": self._datetime, "description": self._description}

    @staticmethod
    def from_dict(data: dict) -> "Log":
        return Log(
            log_id=data.get("id", 0),
            datetime=data.get("datetime", ""),
            description=data.get("description", ""),
        )
