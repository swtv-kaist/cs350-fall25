# SensorManager.py
from typing import List, Optional
from ..storage.StorageManager import StorageManager
from .Sensor import Sensor


class SensorManager:
    """
    SensorManager: Responsible for managing all sensor objects.
    Retrieves sensor data from storage and constructs Sensor instances.
    """

    def __init__(self, storage_dir: str = "Storage"):
        self.storage = StorageManager(storage_dir)
        self._sensors: List[Sensor] = []

        # Load sensors on initialization
        self._load_sensors()

    def _load_sensors(self):
        """
        Internal method to read sensors.json and construct Sensor objects.
        """
        sensors_data = self.storage.load_json("sensors") or []
        self._sensors = [Sensor.from_dict(d) for d in sensors_data]

    def save_sensors(self) -> bool:
        """
        Write the full in-memory sensor list back to sensors.json.
        Returns True if save succeeded.
        """
        data = [s.to_dict() for s in self._sensors]
        return self.storage.save_json("sensors", data)

    def getAllSensors(self) -> List[Sensor]:
        """
        Returns a list of all Sensor objects.
        """
        return self._sensors

    def getSensorbyName(self, name: str) -> Optional[Sensor]:
        for s in self._sensors:
            if s.get_name() == name:
                return s
        return None

    def getSensorById(self, sensor_id: int) -> Optional[Sensor]:
        for s in self._sensors:
            if s.get_id() == sensor_id:
                return s
        return None

    def disarmAllSensors(self):
        for s in self._sensors:
            s.disarm()
        self.save_sensors()

    def armAllSensors(self):
        for s in self._sensors:
            s.arm()
        self.save_sensors()

    def readAllSensors(self):
        return [s.read() for s in self._sensors]
