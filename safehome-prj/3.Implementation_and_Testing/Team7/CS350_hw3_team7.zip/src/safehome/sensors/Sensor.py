from typing import List
from ..virtual_device_v3.device.device_motion_detector import DeviceMotionDetector
from ..virtual_device_v3.device.device_windoor_sensor import DeviceWinDoorSensor


class Sensor:
    def __init__(
        self,
        sensor_type: str,
        sensor_name: str,
        sensor_id: int,
        sensor_location: List[int],
        is_armed: bool = False,
    ):
        self._sensor_type = sensor_type
        self._sensor_name = sensor_name
        self._sensor_id = sensor_id
        self._sensor_location = sensor_location

        if self._sensor_type in ("window", "door"):
            self._device = DeviceWinDoorSensor()
        elif self._sensor_type == "motion":
            self._device = DeviceMotionDetector()
        else:
            raise ValueError("Invalid sensor type")

        # apply armed state
        if is_armed:
            self._device.arm()
        else:
            self._device.disarm()

    # ---------------------------------------------------------
    # GETTERS
    # ---------------------------------------------------------
    def get_type(self) -> str:
        return self._sensor_type

    def get_id(self) -> int:
        return self._sensor_id

    def get_name(self) -> str:
        return self._sensor_name

    def get_location(self) -> List[int]:
        return self._sensor_location

    # ---------------------------------------------------------
    # SETTERS
    # ---------------------------------------------------------
    def set_location(self, new_loc: List[int]) -> bool:
        if not isinstance(new_loc, list) or len(new_loc) != 4:
            return False
        if not all(isinstance(x, int) for x in new_loc):
            return False
        self._sensor_location = new_loc
        return True

    # ---------------------------------------------------------
    # DEVICE DELEGATION
    # ---------------------------------------------------------
    def isArmed(self) -> bool:
        return self._device.test_armed_state()

    def arm(self):
        self._device.arm()

    def disarm(self):
        self._device.disarm()

    def read(self) -> bool:
        return self._device.read()

    def intrude(self):
        self._device.intrude()

    def release(self):
        self._device.release()

    # ---------------------------------------------------------
    # DICTIONARY SERIALIZATION
    # ---------------------------------------------------------
    def to_dict(self) -> dict:
        """
        Convert sensor to a JSON-safe dictionary.
        """
        return {
            "sensor_type": self._sensor_type,
            "sensor_name": self._sensor_name,
            "sensor_id": self._sensor_id,
            "sensor_location": self._sensor_location,
            "is_armed": 1 if self.isArmed() else 0,
        }

    @staticmethod
    def from_dict(data: dict) -> "Sensor":
        """
        Create a Sensor object from a dictionary.
        """
        return Sensor(
            sensor_type=data["sensor_type"],
            sensor_name=data["sensor_name"],
            sensor_id=data["sensor_id"],
            sensor_location=data["sensor_location"],
            is_armed=bool(data.get("is_armed", 0)),
        )
