from .SensorManager import SensorManager


def main():
    mng = SensorManager("TempStorage")
    m1 = mng.getSensorbyName("motionSensor1")
    d1 = mng.getSensorById(3)

    mng.armAllSensors()
    m1.intrude()
    d1.intrude()

    mng.save_sensors()
    print(mng.readAllSensors())
    m1.release()
    print(mng.readAllSensors())


if __name__ == "__main__":
    main()
