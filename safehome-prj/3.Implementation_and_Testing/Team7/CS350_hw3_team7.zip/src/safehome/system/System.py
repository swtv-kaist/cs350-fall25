from ..sensors.SensorManager import SensorManager
from ..cameras.CameraManager import CameraManager
from ..config.ConfigurationManager import ConfigurationManager
from ..config.SafeHomeMode import SafeHomeMode
from ..login.LoginManager import LoginManager
from ..alarm.Alarm import Alarm
import time
from typing import List
from ..utils.time_utils import current_timestamp


class System:
    def __init__(self, storage_dir: str = "Storage"):
        self._is_on = True
        self._storage = storage_dir
        self._sensor_mng = SensorManager(self._storage)
        self._camera_mng = CameraManager(self._storage)
        self._config_mng = ConfigurationManager(self._storage)
        self._login_mng = LoginManager(self._storage)
        self._alarm = Alarm()

    def updateSystem(self):
        self._sensor_mng.save_sensors()
        self._camera_mng.save_cameras()
        self._config_mng.save_safehome_modes()
        self._config_mng.save_safety_zones()
        self._config_mng.save_system_settings()

    def turn_on(self):
        self._is_on = True

    def turn_off(self):
        self._is_on = False

    def is_on(self):
        return self._is_on

    def makePanicPhoneCall(self):
        sysSet = self._config_mng.getSystemSettings()
        time.sleep(sysSet.getAlarmTimeBeforePhoneCall())
        panic_phone = sysSet.getPanicPhoneNumber()
        msg = {"datetime": current_timestamp(), "description": "PANIC PHONE CALL to" + panic_phone}
        return msg, panic_phone

    def getAlarminfo(self):
        return self._alarm.read_alarm()

    def armSensors(self, sensor_list: List[int]):
        for id in sensor_list:
            if id < 1 or id > 10:
                return False

        for id in sensor_list:
            sensor = self._sensor_mng.getSensorById(id)
            sensor.arm()

        return self._sensor_mng.save_sensors()

    def disarmSensors(self, sensor_list: List[int]):
        for id in sensor_list:
            if id < 1 or id > 10:
                return False

        for id in sensor_list:
            sensor = self._sensor_mng.getSensorById(id)
            sensor.disarm()

        return self._sensor_mng.save_sensors()

    def readAllSensors(self):
        sensors = self._sensor_mng.getAllSensors()
        return [s.read() for s in sensors]

    def armBySafehomeMode(self, mode: SafeHomeMode):
        sensors = mode.get_sensor_list()
        for s in sensors:
            s.arm()
