# Device Module Summary

This document provides a comprehensive overview of all files in the `device` directory, including their abstract level, inputs, outputs, behaviors, and expected function outputs.

---

## Table of Contents

1. [__init__.py](#__init__py)
2. [interface_camera.py](#interface_camerapy)
3. [interface_sensor.py](#interface_sensorpy)
4. [device_camera.py](#device_camerapy)
5. [device_control_panel_abstract.py](#device_control_panel_abstractpy)
6. [device_motion_detector.py](#device_motion_detectorpy)
7. [device_sensor_tester.py](#device_sensor_testerpy)
8. [device_windoor_sensor.py](#device_windoor_sensorpy)
9. [safehome_sensor_test.py](#safehome_sensor_testpy)
10. [safehome_sensor_test_gui.py](#safehome_sensor_test_guipy)

---

## __init__.py

**Abstract Level**: Package initialization file

**Content**: Empty file (Python package marker)

**Purpose**: Marks the `device` directory as a Python package, allowing imports from this directory.

---

## interface_camera.py

**Abstract Level**: Abstract Base Class (ABC) defining the camera interface contract

**Purpose**: Defines the abstract interface that all camera devices must implement. Uses Python's `ABC` module to enforce interface compliance.

### Functions

#### `set_id(id_)`
- **Input**: `id_` (int or string) - Camera identifier
- **Output**: None
- **Behavior**: Abstract method that should set the camera ID and load associated image
- **Expected Output**: None (abstract, must be implemented by subclasses)

#### `get_id()`
- **Input**: None
- **Output**: Camera ID (type depends on implementation)
- **Behavior**: Abstract method that should return the current camera ID
- **Expected Output**: Camera identifier (abstract, must be implemented by subclasses)

#### `get_view()`
- **Input**: None
- **Output**: PIL Image object
- **Behavior**: Abstract method that should return the current camera view as an image
- **Expected Output**: PIL Image object (abstract, must be implemented by subclasses)

#### `pan_right()`
- **Input**: None
- **Output**: Boolean
- **Behavior**: Abstract method that should pan the camera to the right
- **Expected Output**: `True` if successful, `False` otherwise (abstract, must be implemented by subclasses)

#### `pan_left()`
- **Input**: None
- **Output**: Boolean
- **Behavior**: Abstract method that should pan the camera to the left
- **Expected Output**: `True` if successful, `False` otherwise (abstract, must be implemented by subclasses)

#### `zoom_in()`
- **Input**: None
- **Output**: Boolean
- **Behavior**: Abstract method that should zoom in the camera view
- **Expected Output**: `True` if successful, `False` otherwise (abstract, must be implemented by subclasses)

#### `zoom_out()`
- **Input**: None
- **Output**: Boolean
- **Behavior**: Abstract method that should zoom out the camera view
- **Expected Output**: `True` if successful, `False` otherwise (abstract, must be implemented by subclasses)

---

## interface_sensor.py

**Abstract Level**: Abstract Base Class (ABC) defining the sensor interface contract

**Purpose**: Defines the abstract interface that all sensor devices must implement. Ensures consistent sensor behavior across different sensor types.

### Functions

#### `get_id()`
- **Input**: None
- **Output**: Sensor ID (type depends on implementation)
- **Behavior**: Abstract method that should return the sensor's unique identifier
- **Expected Output**: Sensor identifier (abstract, must be implemented by subclasses)

#### `read()`
- **Input**: None
- **Output**: Boolean or sensor reading value
- **Behavior**: Abstract method that should read the current sensor state
- **Expected Output**: Sensor reading value (abstract, must be implemented by subclasses)

#### `arm()`
- **Input**: None
- **Output**: None
- **Behavior**: Abstract method that should enable/arm the sensor
- **Expected Output**: None (abstract, must be implemented by subclasses)

#### `disarm()`
- **Input**: None
- **Output**: None
- **Behavior**: Abstract method that should disable/disarm the sensor
- **Expected Output**: None (abstract, must be implemented by subclasses)

#### `test_armed_state()`
- **Input**: None
- **Output**: Boolean
- **Behavior**: Abstract method that should test if the sensor is currently armed
- **Expected Output**: `True` if armed, `False` if disarmed (abstract, must be implemented by subclasses)

---

## device_camera.py

**Abstract Level**: Concrete implementation of a virtual camera device with threading

**Purpose**: Implements a virtual camera that can pan, zoom, and display views. Runs in a separate thread to update time counter. Thread-safe operations using locks.

### Class: `DeviceCamera`

**Inherits from**: `threading.Thread`, `InterfaceCamera`

**Key Attributes**:
- `cameraId`: Camera identifier (int)
- `time`: Internal time counter (0-99, cycles)
- `pan`: Pan position (-5 to 5)
- `zoom`: Zoom level (1-9)
- `imgSource`: PIL Image object loaded from camera file
- `_lock`: Thread lock for synchronization

### Functions

#### `__init__()`
- **Input**: None
- **Output**: None
- **Behavior**: Initializes camera with default values (ID=0, pan=0, zoom=2), creates thread lock, loads default font, starts the thread
- **Expected Output**: None (initialization)

#### `set_id(id_)`
- **Input**: `id_` (int) - Camera identifier
- **Output**: None
- **Behavior**: Thread-safe method that sets camera ID, attempts to load `camera{id_}.jpg` image file, calculates center coordinates. Shows error dialog if file not found.
- **Expected Output**: None (side effect: updates `cameraId`, `imgSource`, `centerWidth`, `centerHeight`)

#### `get_id()`
- **Input**: None
- **Output**: int - Camera ID
- **Behavior**: Returns the current camera identifier
- **Expected Output**: Current `cameraId` value (int)

#### `get_view()`
- **Input**: None
- **Output**: PIL Image (500x500 RGB image)
- **Behavior**: Thread-safe method that creates a 500x500 view image showing:
  - Time display (formatted as "Time = XX")
  - Zoom level (x{zoom})
  - Pan direction (left/center/right with offset)
  - Cropped and resized portion of source image based on zoom and pan
  - Gray rounded rectangle background with cyan text overlay
- **Expected Output**: PIL Image object (500x500) with camera view and metadata overlay

#### `pan_right()`
- **Input**: None
- **Output**: Boolean
- **Behavior**: Thread-safe method that increments pan value by 1. If pan exceeds 5, sets to 5 and returns False
- **Expected Output**: `True` if pan successful, `False` if already at maximum (pan=5)

#### `pan_left()`
- **Input**: None
- **Output**: Boolean
- **Behavior**: Thread-safe method that decrements pan value by 1. If pan is less than -5, reverts change and returns False
- **Expected Output**: `True` if pan successful, `False` if already at minimum (pan=-5)

#### `zoom_in()`
- **Input**: None
- **Output**: Boolean
- **Behavior**: Thread-safe method that increments zoom level by 1. If zoom exceeds 9, reverts change and returns False
- **Expected Output**: `True` if zoom successful, `False` if already at maximum (zoom=9)

#### `zoom_out()`
- **Input**: None
- **Output**: Boolean
- **Behavior**: Thread-safe method that decrements zoom level by 1. If zoom is less than 1, reverts change and returns False
- **Expected Output**: `True` if zoom successful, `False` if already at minimum (zoom=1)

#### `_tick()` (Private)
- **Input**: None
- **Output**: None
- **Behavior**: Thread-safe method that increments time counter. Resets to 0 when reaching 100
- **Expected Output**: None (side effect: updates `time` counter)

#### `run()`
- **Input**: None
- **Output**: None
- **Behavior**: Thread run method that sleeps for 1 second intervals and calls `_tick()` to update time counter. Runs until `_running` is False
- **Expected Output**: None (runs indefinitely until stopped)

#### `stop()`
- **Input**: None
- **Output**: None
- **Behavior**: Stops the camera thread by setting `_running` flag to False
- **Expected Output**: None (side effect: thread will exit on next iteration)

---

## device_control_panel_abstract.py

**Abstract Level**: Abstract base class for a control panel GUI (Tkinter Toplevel window)

**Purpose**: Provides a GUI framework for security system control panels with keypad buttons, status displays, and LEDs. Subclasses must implement button handlers.

### Class: `DeviceControlPanelAbstract`

**Inherits from**: `tk.Toplevel`, `ABC`

**Key GUI Components**:
- Security Zone number display
- Away/Stay/Not Ready status indicators
- Text message display area
- 12-button keypad (0-9, *, #)
- Armed and Power LEDs

### Functions

#### `__init__(master=None)`
- **Input**: `master` (tk.Tk or tk.Toplevel) - Parent window (optional)
- **Output**: None
- **Behavior**: Creates a 505x300 Toplevel window with control panel layout, initializes message variables, creates all GUI components
- **Expected Output**: None (initialization, displays window)

#### `_update_display_text()`
- **Input**: None
- **Output**: None
- **Behavior**: Updates the text display area with current `short_message1` and `short_message2` values
- **Expected Output**: None (side effect: updates text display widget)

#### `set_security_zone_number(num)`
- **Input**: `num` (int or string) - Zone number to display
- **Output**: None
- **Behavior**: Updates the security zone number display with the provided number
- **Expected Output**: None (side effect: updates zone display widget)

#### `set_display_away(on)`
- **Input**: `on` (boolean) - Whether "away" status is active
- **Output**: None
- **Behavior**: Sets the "away" display text color (black if on, light gray if off)
- **Expected Output**: None (side effect: updates away display widget color)

#### `set_display_stay(on)`
- **Input**: `on` (boolean) - Whether "stay" status is active
- **Output**: None
- **Behavior**: Sets the "stay" display text color (black if on, light gray if off)
- **Expected Output**: None (side effect: updates stay display widget color)

#### `set_display_not_ready(on)`
- **Input**: `on` (boolean) - Whether "not ready" status is active
- **Output**: None
- **Behavior**: Sets the "not ready" display text color (black if on, light gray if off)
- **Expected Output**: None (side effect: updates not ready display widget color)

#### `set_display_short_message1(message)`
- **Input**: `message` (string) - First message line
- **Output**: None
- **Behavior**: Sets the first short message and updates the display
- **Expected Output**: None (side effect: updates text display)

#### `set_display_short_message2(message)`
- **Input**: `message` (string) - Second message line
- **Output**: None
- **Behavior**: Sets the second short message and updates the display
- **Expected Output**: None (side effect: updates text display)

#### `set_armed_led(on)`
- **Input**: `on` (boolean) - Whether armed LED should be on
- **Output**: None
- **Behavior**: Sets the armed LED background color (red if on, light gray if off)
- **Expected Output**: None (side effect: updates LED widget color)

#### `set_powered_led(on)`
- **Input**: `on` (boolean) - Whether power LED should be on
- **Output**: None
- **Behavior**: Sets the power LED background color (green if on, light gray if off)
- **Expected Output**: None (side effect: updates LED widget color)

#### Abstract Button Methods (must be implemented by subclasses)

All button methods (`button1()` through `button9()`, `button0()`, `button_star()`, `button_sharp()`) are abstract and must be implemented by subclasses:

- **Input**: None
- **Output**: None (implementation-dependent)
- **Behavior**: Handle button press events (abstract, implementation required)
- **Expected Output**: Implementation-dependent

---

## device_motion_detector.py

**Abstract Level**: Concrete implementation of a motion detector sensor

**Purpose**: Implements a motion detection sensor that can be armed/disarmed and detects motion when armed. Uses linked list structure managed by `DeviceSensorTester`.

### Class: `DeviceMotionDetector`

**Inherits from**: `DeviceSensorTester`, `InterfaceSensor`

**Key Attributes**:
- `sensor_id`: Unique sensor identifier (int, auto-incremented)
- `detected`: Motion detection state (boolean)
- `armed`: Sensor armed/disarmed state (boolean)
- `next`: Pointer to next sensor in linked list

### Functions

#### `__init__()`
- **Input**: None
- **Output**: None
- **Behavior**: Initializes motion detector with unique ID from sequence counter, sets initial states (detected=False, armed=False), adds itself to linked list head, updates GUI if available
- **Expected Output**: None (initialization, side effect: updates global sensor list)

#### `intrude()`
- **Input**: None
- **Output**: None
- **Behavior**: Simulates motion detection by setting `detected` to True
- **Expected Output**: None (side effect: `detected = True`)

#### `release()`
- **Input**: None
- **Output**: None
- **Behavior**: Clears motion detection by setting `detected` to False
- **Expected Output**: None (side effect: `detected = False`)

#### `get_id()`
- **Input**: None
- **Output**: int - Sensor ID
- **Behavior**: Returns the sensor's unique identifier
- **Expected Output**: Current `sensor_id` value (int)

#### `read()`
- **Input**: None
- **Output**: Boolean - Detection state
- **Behavior**: Returns True if sensor is armed AND motion is detected, False otherwise
- **Expected Output**: `True` if armed and detected, `False` otherwise

#### `arm()`
- **Input**: None
- **Output**: None
- **Behavior**: Enables/arms the sensor by setting `armed` to True
- **Expected Output**: None (side effect: `armed = True`)

#### `disarm()`
- **Input**: None
- **Output**: None
- **Behavior**: Disables/disarms the sensor by setting `armed` to False
- **Expected Output**: None (side effect: `armed = False`)

#### `test_armed_state()`
- **Input**: None
- **Output**: Boolean - Armed state
- **Behavior**: Returns whether the sensor is currently armed
- **Expected Output**: `True` if armed, `False` if disarmed

---

## device_sensor_tester.py

**Abstract Level**: Abstract base class for sensor devices with testing infrastructure

**Purpose**: Provides base functionality for sensor testing, manages linked lists of sensors, and handles GUI initialization. Maintains class-level state for sensor registration.

### Class: `DeviceSensorTester`

**Inherits from**: `ABC`

**Class Attributes** (shared across all instances):
- `safeHomeSensorTest`: Reference to sensor test GUI instance
- `head_WinDoorSensor`: Head of window/door sensor linked list
- `head_MotionDetector`: Head of motion detector linked list
- `newIdSequence_WinDoorSensor`: ID counter for window/door sensors
- `newIdSequence_MotionDetector`: ID counter for motion detectors

### Functions

#### `__init__()`
- **Input**: None
- **Output**: None
- **Behavior**: Initializes sensor with `next` pointer set to None and `sensor_id` set to 0 (placeholder)
- **Expected Output**: None (base initialization)

#### `intrude()` (Abstract)
- **Input**: None
- **Output**: None
- **Behavior**: Abstract method to simulate intrusion/detection (must be implemented by subclasses)
- **Expected Output**: None (abstract, implementation-dependent)

#### `release()` (Abstract)
- **Input**: None
- **Output**: None
- **Behavior**: Abstract method to clear intrusion/detection state (must be implemented by subclasses)
- **Expected Output**: None (abstract, implementation-dependent)

#### `showSensorTester()` (Static)
- **Input**: None
- **Output**: None
- **Behavior**: Static method that creates and displays the sensor tester GUI if it doesn't exist. Checks for `SAFEHOME_HEADLESS` environment variable to skip GUI in headless mode. Creates Tkinter root if needed.
- **Expected Output**: None (side effect: opens GUI window if not in headless mode)

---

## device_windoor_sensor.py

**Abstract Level**: Concrete implementation of a window/door sensor

**Purpose**: Implements a sensor that detects when windows or doors are opened/closed. Can be armed/disarmed. Uses linked list structure managed by `DeviceSensorTester`.

### Class: `DeviceWinDoorSensor`

**Inherits from**: `DeviceSensorTester`, `InterfaceSensor`

**Key Attributes**:
- `sensor_id`: Unique sensor identifier (int, auto-incremented)
- `opened`: Door/window open state (boolean)
- `armed`: Sensor armed/disarmed state (boolean)
- `next`: Pointer to next sensor in linked list

### Functions

#### `__init__()`
- **Input**: None
- **Output**: None
- **Behavior**: Initializes window/door sensor with unique ID from sequence counter, sets initial states (opened=False, armed=False), adds itself to linked list head, updates GUI if available
- **Expected Output**: None (initialization, side effect: updates global sensor list)

#### `intrude()`
- **Input**: None
- **Output**: None
- **Behavior**: Simulates opening the window/door by setting `opened` to True
- **Expected Output**: None (side effect: `opened = True`)

#### `release()`
- **Input**: None
- **Output**: None
- **Behavior**: Simulates closing the window/door by setting `opened` to False
- **Expected Output**: None (side effect: `opened = False`)

#### `get_id()`
- **Input**: None
- **Output**: int - Sensor ID
- **Behavior**: Returns the sensor's unique identifier
- **Expected Output**: Current `sensor_id` value (int)

#### `read()`
- **Input**: None
- **Output**: Boolean - Open state (only if armed)
- **Behavior**: Returns True if sensor is armed AND door/window is opened, False otherwise
- **Expected Output**: `True` if armed and opened, `False` otherwise

#### `arm()`
- **Input**: None
- **Output**: None
- **Behavior**: Enables/arms the sensor by setting `armed` to True
- **Expected Output**: None (side effect: `armed = True`)

#### `disarm()`
- **Input**: None
- **Output**: None
- **Behavior**: Disables/disarms the sensor by setting `armed` to False
- **Expected Output**: None (side effect: `armed = False`)

#### `test_armed_state()`
- **Input**: None
- **Output**: Boolean - Armed state
- **Behavior**: Returns whether the sensor is currently armed
- **Expected Output**: `True` if armed, `False` if disarmed

---

## safehome_sensor_test.py

**Abstract Level**: Simple GUI implementation for sensor testing (Tkinter Toplevel window)

**Purpose**: Provides a basic GUI interface for testing window/door sensors and motion detectors. Allows users to trigger open/close and detect/clear actions by sensor ID.

### Class: `SafeHomeSensorTest`

**Inherits from**: `tk.Toplevel`

**Key GUI Components**:
- Left panel: Window/Door sensor controls (ID range, input ID, open/close buttons)
- Right panel: Motion detector controls (ID range, input ID, detect/clear buttons)

### Functions

#### `__init__(master=None)`
- **Input**: `master` (tk.Tk or tk.Toplevel) - Parent window (optional)
- **Output**: None
- **Behavior**: Creates a 355x170 Toplevel window with orange background, sets up two panels for sensor testing, initializes head pointers to None
- **Expected Output**: None (initialization, displays window)

#### `handle_windoor_action(action)`
- **Input**: `action` (string) - Either "open" or "close"
- **Output**: None
- **Behavior**: Reads sensor ID from input field, validates it (must be digits), searches linked list for matching sensor, calls `intrude()` for "open" or `release()` for "close". Shows error messages for invalid input or missing sensor.
- **Expected Output**: None (side effect: updates sensor state or shows error dialog)

#### `handle_motion_action(action)`
- **Input**: `action` (string) - Either "detect" or "clear"
- **Output**: None
- **Behavior**: Reads sensor ID from input field, validates it (must be digits), searches linked list for matching sensor, calls `intrude()` for "detect" or `release()` for "clear". Shows error messages for invalid input or missing sensor.
- **Expected Output**: None (side effect: updates sensor state or shows error dialog)

---

## safehome_sensor_test_gui.py

**Abstract Level**: Advanced GUI implementation for sensor testing with status display (Tkinter Toplevel window)

**Purpose**: Provides a comprehensive GUI interface for testing and monitoring sensors. Includes real-time status updates, arm/disarm controls, and sensor state visualization.

### Class: `SafeHomeSensorTest`

**Inherits from**: `tk.Toplevel`

**Key GUI Components**:
- Window/Door sensor panel with arm/disarm and open/close controls
- Motion detector panel with arm/disarm and detect/clear controls
- Real-time status display area showing all sensors with their states
- Auto-updating status display (refreshes every 500ms)

### Functions

#### `__init__(master=None)`
- **Input**: `master` (tk.Tk or tk.Toplevel) - Parent window (optional)
- **Output**: None
- **Behavior**: Creates a 500x450 Toplevel window, sets up two sensor control panels, creates status display area, starts automatic status update loop
- **Expected Output**: None (initialization, displays window)

#### `_update_status()`
- **Input**: None
- **Output**: None
- **Behavior**: Updates the status display by traversing sensor linked lists, reads each sensor's armed state and physical state (opened/detected), formats and displays status with emoji indicators. Schedules next update after 500ms.
- **Expected Output**: None (side effect: updates status text widgets, schedules next update)

#### `_validate_digits(s)`
- **Input**: `s` (string) - String to validate
- **Output**: Boolean - True if all digits
- **Behavior**: Validates that input string contains only digits
- **Expected Output**: `True` if string is empty or contains only digits, `False` otherwise

#### `_handle_windoor_sensor(action)`
- **Input**: `action` (string) - Either "arm" or "disarm"
- **Output**: None
- **Behavior**: Reads sensor ID from input field, validates it, searches linked list for matching window/door sensor, calls `arm()` or `disarm()` method, immediately updates status display. Shows error messages for invalid input or missing sensor.
- **Expected Output**: None (side effect: updates sensor armed state and status display, or shows error dialog)

#### `_handle_windoor(action)`
- **Input**: `action` (string) - Either "open" or "close"
- **Output**: None
- **Behavior**: Reads sensor ID from input field, validates it, searches linked list for matching window/door sensor, calls `intrude()` for "open" or `release()` for "close", immediately updates status display. Shows error messages for invalid input or missing sensor.
- **Expected Output**: None (side effect: updates sensor open state and status display, or shows error dialog)

#### `_handle_motion_sensor(action)`
- **Input**: `action` (string) - Either "arm" or "disarm"
- **Output**: None
- **Behavior**: Reads sensor ID from input field, validates it, searches linked list for matching motion detector, calls `arm()` or `disarm()` method, immediately updates status display. Shows error messages for invalid input or missing sensor.
- **Expected Output**: None (side effect: updates sensor armed state and status display, or shows error dialog)

#### `_handle_motion(action)`
- **Input**: `action` (string) - Either "detect" or "clear"
- **Output**: None
- **Behavior**: Reads sensor ID from input field, validates it, searches linked list for matching motion detector, calls `intrude()` for "detect" or `release()` for "clear", immediately updates status display. Shows error messages for invalid input or missing sensor.
- **Expected Output**: None (side effect: updates sensor detection state and status display, or shows error dialog)

---

## Design Patterns and Architecture

### Interface Pattern
- `InterfaceCamera` and `InterfaceSensor` define contracts that concrete implementations must follow
- Ensures consistent API across different device implementations

### Abstract Base Class Pattern
- `DeviceControlPanelAbstract` and `DeviceSensorTester` provide base functionality while requiring subclasses to implement specific methods
- Promotes code reuse and consistent structure

### Linked List Pattern
- Sensors are organized in linked lists managed by class-level head pointers
- Enables dynamic sensor registration and iteration

### Threading Pattern
- `DeviceCamera` uses a separate thread to update time counter independently
- Thread-safe operations using locks prevent race conditions

### Observer Pattern (implicit)
- GUI components observe sensor states and update displays automatically
- Status updates reflect current sensor states in real-time

---

## Summary of Dependencies

- **PIL/Pillow**: Image processing for camera views
- **tkinter**: GUI framework for all windows and widgets
- **threading**: Concurrent execution for camera time updates
- **abc**: Abstract base classes for interface definitions

---

## Common Functionality Patterns

1. **Sensor Management**: All sensors register themselves in linked lists during initialization
2. **ID Assignment**: Sensors receive auto-incremented IDs from class-level counters
3. **State Management**: Sensors maintain armed/disarmed and physical state (opened/detected)
4. **Thread Safety**: Camera operations use locks for synchronization
5. **Error Handling**: GUI methods validate input and show error dialogs for invalid operations
6. **Status Display**: GUI components provide real-time feedback on sensor states

