# system_settings.py


class SystemSettings:
    """
    SystemSettings: Maintains system configuration attributes.
    Attributes:
        - systemLockTime (int): system lock duration in seconds/minutes
        - panicPhoneNumber (str): phone number for monitoring service
        - alarmTimeBeforePhoneCall (int): delay time before calling
        - homePhoneNumber (str): phone number of homeowner
    """

    def __init__(
        self,
        systemLockTime: int = 0,
        panicPhoneNumber: str = "",
        alarmTimeBeforePhoneCall: int = 0,
        homePhoneNumber: str = "",
    ):
        self._systemLockTime = systemLockTime
        self._panicPhoneNumber = panicPhoneNumber
        self._alarmTimeBeforePhoneCall = alarmTimeBeforePhoneCall
        self._homePhoneNumber = homePhoneNumber

    # ------------------ System Lock Time ------------------

    def setSystemLockTime(self, lockTime: int):
        self._systemLockTime = lockTime

    def getSystemLockTime(self) -> int:
        return self._systemLockTime

    # ------------------ Panic Phone Number ------------------

    def setPanicPhoneNumber(self, phoneNumber: str):
        self._panicPhoneNumber = phoneNumber

    def getPanicPhoneNumber(self) -> str:
        return self._panicPhoneNumber

    # ------------------ Alarm Time Before Phone Call ------------------

    def setAlarmTimeBeforePhoneCall(self, timeDelay: int):
        self._alarmTimeBeforePhoneCall = timeDelay

    def getAlarmTimeBeforePhoneCall(self) -> int:
        return self._alarmTimeBeforePhoneCall

    # ------------------ Home Phone Number ------------------

    def setHomePhoneNumber(self, phoneNumber: str):
        self._homePhoneNumber = phoneNumber

    def getHomePhoneNumber(self) -> str:
        return self._homePhoneNumber
