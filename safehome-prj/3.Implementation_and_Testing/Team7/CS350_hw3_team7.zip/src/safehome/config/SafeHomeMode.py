# SafeHomeMode.py
from typing import List
from ..sensors.Sensor import Sensor


class SafeHomeMode:
    _mode_id_counter = 0  # Class-level counter for unique IDs

    def __init__(self, name: str, sensor_list: List[Sensor] = None, mode_id: int = None):
        """
        SafeHomeMode: Represents a system mode composed of multiple sensors.
        If mode_id is provided (from storage), use it.
        Otherwise, assign a new unique ID automatically.
        """
        self._name = name
        self._sensor_list = sensor_list if sensor_list is not None else []

        # Assign ID
        if mode_id is not None:
            self._id = mode_id
            # update class counter if necessary
            if mode_id > SafeHomeMode._mode_id_counter:
                SafeHomeMode._mode_id_counter = mode_id
        else:
            SafeHomeMode._mode_id_counter += 1
            self._id = SafeHomeMode._mode_id_counter

    # ---------------- Getters ----------------
    def get_name(self) -> str:
        return self._name

    def get_id(self) -> int:
        return self._id

    def get_sensor_list(self) -> List[Sensor]:
        return self._sensor_list.copy()

    # ---------------- Setters ----------------
    def set_name(self, name: str):
        self._name = name

    def set_sensor_list(self, sensor_list: List[Sensor]):
        self._sensor_list = sensor_list.copy()

    # ---------------- Serialization ----------------
    def to_dict(self) -> dict:
        """
        Serialize SafeHomeMode to a JSON-serializable dictionary.
        """
        return {
            "name": self._name,
            "id": self._id,
            "sensor_list": [
                {
                    "sensor_type": s.get_type(),
                    "sensor_name": s.get_name(),
                    "sensor_id": s.get_id(),
                    "sensor_location": s.get_location(),
                }
                for s in self._sensor_list
            ],
        }

    @staticmethod
    def from_dict(data: dict) -> "SafeHomeMode":
        """
        Deserialize a SafeHomeMode from a dictionary.
        Constructs Sensor objects from serialized dicts.
        """
        sensors_in_mode = []
        for s_data in data.get("sensor_list", []):
            sensor_obj = Sensor(
                sensor_type=s_data["sensor_type"],
                sensor_name=s_data["sensor_name"],
                sensor_id=s_data["sensor_id"],
                sensor_location=s_data["sensor_location"],
            )
            sensors_in_mode.append(sensor_obj)

        mode = SafeHomeMode(
            name=data.get("name", "UnknownMode"),
            sensor_list=sensors_in_mode,
            mode_id=data.get("id"),
        )
        return mode
