# configuration_manager.py
from typing import List, Optional
from ..storage.StorageManager import StorageManager
from .SystemSettings import SystemSettings
from .SafetyZone import SafetyZone
from .SafeHomeMode import SafeHomeMode


class ConfigurationManager:
    """
    ConfigurationManager: Handles system-wide settings, safety zones, and safe home modes.
    Only one instance of SystemSettings is allowed in storage.
    Safety zones -> 'safetyzones.json'
    Safe home modes -> 'safehome_modes.json'
    """

    def __init__(self, storage_dir: str = "Storage"):
        self.storage = StorageManager(storage_dir)
        self._settings: SystemSettings | None = None
        self._safety_zones: List[SafetyZone] = []
        self._modes: List[SafeHomeMode] = []
        self.load_system_settings()
        self.load_safety_zones()
        self.load_safehome_modes()

    # ------------------ System Settings ------------------

    def load_system_settings(self):
        data = self.storage.load_json("system_settings")
        if data:
            self._settings = SystemSettings(
                systemLockTime=data.get("systemLockTime", 0),
                panicPhoneNumber=data.get("panicPhoneNumber", ""),
                alarmTimeBeforePhoneCall=data.get("alarmTimeBeforePhoneCall", 0),
                homePhoneNumber=data.get("homePhoneNumber", ""),
            )
        else:
            self._settings = SystemSettings()

    def save_system_settings(self) -> bool:
        if not self._settings:
            return False
        data = {
            "systemLockTime": self._settings.getSystemLockTime(),
            "panicPhoneNumber": self._settings.getPanicPhoneNumber(),
            "alarmTimeBeforePhoneCall": self._settings.getAlarmTimeBeforePhoneCall(),
            "homePhoneNumber": self._settings.getHomePhoneNumber(),
        }
        return self.storage.save_json("system_settings", data)

    def updateSystemSettings(self, settings: SystemSettings) -> bool:
        self._settings = settings
        return self.save_system_settings()

    def getSystemSettings(self) -> SystemSettings:
        if not self._settings:
            self.load_system_settings()
        return self._settings

    # ------------------ Safety Zones ------------------

    def load_safety_zones(self):
        data_list = self.storage.load_json("safetyzones") or []
        self._safety_zones = [SafetyZone.from_dict(d) for d in data_list]

    def save_safety_zones(self) -> bool:
        return self.storage.save_json("safetyzones", [z.to_dict() for z in self._safety_zones])

    def getAllSafetyZones(self) -> List[SafetyZone]:
        return self._safety_zones.copy()

    def addSafetyZone(self, zone: SafetyZone) -> bool:
        if any(z.get_name() == zone.get_name() for z in self._safety_zones):
            return False  # Name already exists
        self._safety_zones.append(zone)
        return self.save_safety_zones()

    def deleteSafetyZone(self, zone_name: str) -> bool:
        original_len = len(self._safety_zones)
        self._safety_zones = [z for z in self._safety_zones if z.get_name() != zone_name]
        if len(self._safety_zones) == original_len:
            return False
        return self.save_safety_zones()

    def getSafetyZoneByName(self, zone_name: str) -> Optional[SafetyZone]:
        for z in self._safety_zones:
            if z.get_name() == zone_name:
                return z
        return None

    # ------------------ SafeHome Modes ------------------

    def load_safehome_modes(self):
        data_list = self.storage.load_json("safehome_modes") or []
        self._modes = [SafeHomeMode.from_dict(d) for d in data_list]

    def save_safehome_modes(self) -> bool:
        return self.storage.save_json("safehome_modes", [m.to_dict() for m in self._modes])

    def getAllSafeHomeModes(self) -> List[SafeHomeMode]:
        return self._modes.copy()

    def addSafeHomeMode(self, mode: SafeHomeMode) -> bool:
        if any(m.get_name() == mode.get_name() for m in self._modes):
            return False  # Name already exists
        self._modes.append(mode)
        return self.save_safehome_modes()

    def deleteSafeHomeMode(self, mode_name: str) -> bool:
        original_len = len(self._modes)
        self._modes = [m for m in self._modes if m.get_name() != mode_name]
        if len(self._modes) == original_len:
            return False
        return self.save_safehome_modes()

    def getSafeHomeModeByName(self, mode_name: str) -> Optional[SafeHomeMode]:
        for m in self._modes:
            if m.get_name() == mode_name:
                return m
        return None
