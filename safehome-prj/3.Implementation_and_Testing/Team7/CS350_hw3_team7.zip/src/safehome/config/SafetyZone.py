# SafetyZone.py
from typing import List
from ..sensors.Sensor import Sensor


class SafetyZone:
    _zone_id_counter = 0  # Class-level counter for unique IDs

    def __init__(
        self,
        name: str,
        sensor_list: List[Sensor] = None,
        arm_status: bool = False,
        zone_id: int = None,
    ):
        """
        If zone_id is provided (from storage), use it.
        Otherwise, assign a new unique ID automatically.
        """
        self._name = name
        self._sensor_list = sensor_list if sensor_list is not None else []
        self._arm_status = arm_status

        # Assign ID
        if zone_id is not None:
            self._id = zone_id
            # update class counter if necessary
            if zone_id > SafetyZone._zone_id_counter:
                SafetyZone._zone_id_counter = zone_id
        else:
            SafetyZone._zone_id_counter += 1
            self._id = SafetyZone._zone_id_counter

        # Arm sensors if zone is armed
        if self._arm_status:
            for s in self._sensor_list:
                s.arm()

    # ---------------- Getters ----------------
    def get_name(self) -> str:
        return self._name

    def get_id(self) -> int:
        return self._id

    def get_sensor_list(self) -> List[Sensor]:
        return self._sensor_list.copy()

    def is_armed(self) -> bool:
        return self._arm_status

    # ---------------- Setters ----------------
    def set_name(self, name: str):
        self._name = name

    def armSafetyZone(self):
        self._arm_status = True
        for s in self._sensor_list:
            s.arm()

    def disarmSafetyZone(self):
        self._arm_status = False
        for s in self._sensor_list:
            s.disarm()

    # ---------------- Serialization ----------------
    def to_dict(self) -> dict:
        return {
            "name": self._name,
            "id": self._id,
            "arm_status": self._arm_status,
            "sensor_list": [
                {
                    "sensor_type": s.get_type(),
                    "sensor_name": s.get_name(),
                    "sensor_id": s.get_id(),
                    "sensor_location": s.get_location(),
                }
                for s in self._sensor_list
            ],
        }

    @staticmethod
    def from_dict(data: dict) -> "SafetyZone":
        sensors_in_zone = []
        for s_data in data.get("sensor_list", []):
            sensor_obj = Sensor(
                sensor_type=s_data["sensor_type"],
                sensor_name=s_data["sensor_name"],
                sensor_id=s_data["sensor_id"],
                sensor_location=s_data["sensor_location"],
            )
            sensors_in_zone.append(sensor_obj)

        zone = SafetyZone(
            name=data.get("name", "UnknownZone"),
            sensor_list=sensors_in_zone,
            arm_status=data.get("arm_status", False),
            zone_id=data.get("id"),
        )
        return zone
