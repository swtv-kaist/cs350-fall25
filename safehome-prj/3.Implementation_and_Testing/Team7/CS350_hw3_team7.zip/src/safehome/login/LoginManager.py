# login_manager.py
from ..storage.StorageManager import StorageManager
from .UserEntry import UserEntry


class LoginManager:
    """
    LoginManager: Handles multi-session login/logout and updates.
    Interacts with StorageManager and CryptoManager.
    """

    def __init__(self, storage_dir: str = "Storage"):
        self.storage = StorageManager(storage_dir)
        self.active_sessions = set()
        self._users = []
        self.load_users()

    def load_users(self):
        users_data = self.storage.load_json("users") or []
        self._users = [UserEntry.from_dict(d) for d in users_data]

    def save_users(self):
        data = [s.to_dict() for s in self._users]
        return self.storage.save_json("users", data)

    def getUserbyUsername(self, username):
        for u in self._users:
            if u.getUsername() == username:
                return u
        return None

    # ------------------ Login ------------------

    def login(self, username: str, password: str):
        user = self.getUserbyUsername(username)

        if not user:
            return False, None  # unknown username

        # Verify password using CryptoManager
        if not user.verifyPassword(password):
            return False, None

        self.active_sessions.add(user.getUsername())
        return True, user

    # ------------------ Logout ------------------

    def logout(self, user: UserEntry) -> bool:
        username = user.getUsername()
        if username not in self.active_sessions:
            return False
        self.active_sessions.remove(username)
        return True

    # ------------------ Password Update ------------------

    def change_password(self, user: UserEntry, new_password: str) -> bool:
        if user.getUsername() not in self.active_sessions:
            return False  # session not found

        if len(new_password) < 6:
            return False  # enforce minimum lengt

        # Persist change to storage
        user.setPassword(new_password)
        return self.save_users()
