# user_entry.py


class UserEntry:
    """
    UserEntry: Holds user session data.
    Stores only hashed password and salt for security.
    """

    def __init__(self, username: str, password: str, type: str, interface: str = "web"):
        self._username = username
        self._password = password
        self._interface = interface
        self._type = type

    # ------------------ Username ------------------

    def setUsername(self, username: str):
        self._username = username

    def getUsername(self) -> str:
        return self._username

    # ------------------ Password ------------------

    def setPassword(self, new_pass):
        self._password = new_pass

    def getPassword(self) -> str:
        return self._password

    def verifyPassword(self, password):
        return self._password == password

    # ------------------ Interface ------------------

    def setInterface(self, interface: str):
        self._interface = interface

    def getInterface(self) -> str:
        return self._interface

    # ------------------ Type ------------------

    def setType(self, type: str):
        self._type = type

    def getType(self) -> str:
        return self._type

    def to_dict(self):
        return {
            "username": self._username,
            "password": self._password,
            "interface": self._interface,
            "type": self._type,
        }

    @staticmethod
    def from_dict(data):
        return UserEntry(
            username=data["username"],
            password=data["password"],
            type=data["type"],
            interface=data["interface"],
        )
