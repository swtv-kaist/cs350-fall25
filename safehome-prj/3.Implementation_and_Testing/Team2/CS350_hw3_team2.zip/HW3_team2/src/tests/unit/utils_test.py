"""
Unit tests for utils.py
Tests utility functions for drawing floor plans and sensor operations
"""

from unittest.mock import Mock, patch

import customtkinter as ctk
import pytest
from PIL import Image

from core.pages.utils import (check_line_intersection, draw_floor_plan,
                              find_lowest_empty_id, is_sensor_in_rect,
                              show_toast)
from database.schema.sensor import SensorType


# Fixtures
@pytest.fixture
def root():
    """Create and cleanup CTk root window"""
    root_window = ctk.CTk()
    root_window.withdraw()
    yield root_window
    try:
        root_window.destroy()
    except Exception:
        pass


@pytest.fixture
def canvas(root):
    """Create canvas widget"""
    canvas_widget = ctk.CTkCanvas(root, width=500, height=312)
    yield canvas_widget
    try:
        canvas_widget.destroy()
    except Exception:
        pass


# Tests for draw_floor_plan
@patch("core.pages.utils.ImageTk.PhotoImage")
@patch("core.pages.utils.Image.open")
def test_draw_floor_plan_success(mock_image_open, mock_photo_image, canvas):
    """Test successful floor plan drawing"""
    mock_img = Mock(spec=Image.Image)
    mock_img.size = (500, 312)
    mock_img.convert.return_value = mock_img
    mock_image_open.return_value = mock_img

    # Mock PhotoImage to return a valid object
    mock_photo = Mock()
    mock_photo_image.return_value = mock_photo

    draw_floor_plan(canvas)

    # Verify image was opened and converted
    mock_image_open.assert_called_once()
    mock_img.convert.assert_called_once_with("RGBA")

    # Verify PhotoImage was created
    mock_photo_image.assert_called_once_with(mock_img)

    # Verify canvas has the image reference
    assert hasattr(canvas, "_floor_img_tk")
    assert canvas._floor_img_tk == mock_photo


@patch("core.pages.utils.Image.open")
def test_draw_floor_plan_image_not_found(mock_image_open, canvas):
    """Test floor plan drawing when image is not found"""
    mock_image_open.side_effect = FileNotFoundError()

    draw_floor_plan(canvas)

    # Should draw fallback rectangle and text
    items = canvas.find_all()
    assert len(items) > 0


@patch("core.pages.utils.Image.open")
def test_draw_floor_plan_clears_previous(mock_image_open, canvas):
    """Test that draw_floor_plan clears previous drawings"""
    mock_img = Mock(spec=Image.Image)
    mock_img.convert.return_value = mock_img
    mock_image_open.return_value = mock_img

    # Draw something first
    canvas.create_rectangle(0, 0, 100, 100)

    # Draw floor plan
    draw_floor_plan(canvas)

    # Canvas should be cleared and redrawn
    assert canvas is not None


# Tests for show_toast
def test_show_toast_creates_toplevel(root):
    """Test that show_toast creates a toplevel window"""
    show_toast(root, "Test message")

    # Update to process pending events
    root.update_idletasks()

    # Find and hide any toast windows that were created
    for child in root.winfo_children():
        if isinstance(child, ctk.CTkToplevel):
            child.withdraw()

    # Toast should be created (checking doesn't throw error)
    assert root is not None


def test_show_toast_with_custom_duration(root):
    """Test show_toast with custom duration"""
    show_toast(root, "Test message", duration_ms=1000)

    # Update to process pending events
    root.update_idletasks()

    # Find and hide any toast windows that were created
    for child in root.winfo_children():
        if isinstance(child, ctk.CTkToplevel):
            child.withdraw()

    # Toast should be created
    assert root is not None


def test_show_toast_long_message(root):
    """Test show_toast with a long message"""
    long_message = "This is a very long message " * 20
    show_toast(root, long_message)

    # Update to process pending events
    root.update_idletasks()

    # Find and hide any toast windows that were created
    for child in root.winfo_children():
        if isinstance(child, ctk.CTkToplevel):
            child.withdraw()

    # Should handle long messages
    assert root is not None


# Tests for check_line_intersection
@pytest.mark.parametrize(
    "p1,p2,p3,p4,expected",
    [
        ((0, 0), (10, 10), (0, 10), (10, 0), True),  # Intersecting X pattern
        (
            (0, 0),
            (5, 5),
            (10, 10),
            (15, 15),
            False,
        ),  # Non-intersecting parallel
        ((0, 0), (10, 0), (0, 5), (10, 5), False),  # Parallel horizontal
        ((0, 0), (10, 10), (10, 10), (20, 0), True),  # Touching at endpoint
        ((5, 0), (5, 10), (0, 5), (10, 5), True),  # Perpendicular intersecting
    ],
)
def test_check_line_intersection(p1, p2, p3, p4, expected):
    """Test line intersection with various configurations"""
    assert check_line_intersection(p1, p2, p3, p4) is expected


# Tests for is_sensor_in_rect
@pytest.mark.parametrize(
    "x,y,x2,y2,sensor_type,rx1,ry1,rx2,ry2,expected",
    [
        # WinDoor sensor tests
        (
            5,
            5,
            None,
            None,
            SensorType.WINDOOR_SENSOR,
            0,
            0,
            10,
            10,
            True,
        ),  # Inside
        (
            15,
            15,
            None,
            None,
            SensorType.WINDOOR_SENSOR,
            0,
            0,
            10,
            10,
            False,
        ),  # Outside
        (
            10,
            10,
            None,
            None,
            SensorType.WINDOOR_SENSOR,
            0,
            0,
            10,
            10,
            True,
        ),  # On boundary
        (
            5,
            5,
            None,
            None,
            SensorType.WINDOOR_SENSOR,
            10,
            10,
            0,
            0,
            True,
        ),  # Inverted rect
        # Motion detector tests
        (
            2,
            2,
            8,
            8,
            SensorType.MOTION_DETECTOR_SENSOR,
            0,
            0,
            10,
            10,
            True,
        ),  # Both points inside
        (
            5,
            5,
            15,
            15,
            SensorType.MOTION_DETECTOR_SENSOR,
            0,
            0,
            10,
            10,
            True,
        ),  # One point inside
        (
            -5,
            5,
            15,
            5,
            SensorType.MOTION_DETECTOR_SENSOR,
            0,
            0,
            10,
            10,
            True,
        ),  # Line intersects
        (
            20,
            20,
            25,
            25,
            SensorType.MOTION_DETECTOR_SENSOR,
            0,
            0,
            10,
            10,
            False,
        ),  # Outside
        # Unknown type
        (5, 5, None, None, None, 0, 0, 10, 10, False),
    ],
)
def test_is_sensor_in_rect(
    x, y, x2, y2, sensor_type, rx1, ry1, rx2, ry2, expected
):
    """Test sensor in rectangle with various configurations"""
    sensor = Mock()
    sensor.coordinate_x = x
    sensor.coordinate_y = y
    sensor.coordinate_x2 = x2
    sensor.coordinate_y2 = y2
    sensor.get_type.return_value = sensor_type
    result = is_sensor_in_rect(sensor, rx1, ry1, rx2, ry2)
    assert result is expected


# Tests for find_lowest_empty_id
@pytest.mark.parametrize(
    "ids,expected",
    [
        ([], 1),  # Empty list
        ([1, 2, 3, 4], 5),  # Continuous from 1
        ([1, 2, 4, 5], 3),  # Gap in middle
        ([2, 3, 4], 1),  # Missing first ID
        ([1], 2),  # Single ID
        ([1, 3, 5, 7], 2),  # Non-continuous
        ([100, 101, 102], 1),  # Large numbers
        ([4, 1, 3, 2], 5),  # Unordered
    ],
)
def test_find_lowest_empty_id(ids, expected):
    """Test find_lowest_empty_id with various inputs"""
    result = find_lowest_empty_id(ids)
    assert result == expected


def test_show_toast_when_viewable(root):
    """Test show_toast when window is viewable (58->61 branch)."""
    # Make window visible
    root.deiconify()
    root.update_idletasks()

    # Mock winfo_viewable to return True
    with patch.object(root, "winfo_viewable", return_value=True):
        show_toast(root, "Test message", duration_ms=100)
        root.update_idletasks()

    # Toast should be visible (not withdrawn)
    # Just verify no errors occurred
    root.update()
