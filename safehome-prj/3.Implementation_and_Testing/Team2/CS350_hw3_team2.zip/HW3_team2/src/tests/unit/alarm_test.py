from unittest.mock import patch

import pytest

from device.appliance.alarm import ALARM_DURATION, Alarm


@pytest.fixture
def mock_thread_start():
    """Prevent the thread from actually starting during __init__."""
    with patch("threading.Thread.start") as mock_start:
        yield mock_start


@pytest.fixture
def alarm(mock_thread_start):
    return Alarm()


def test_init_success(alarm, mock_thread_start):
    assert alarm.alarm_id == 0
    assert alarm.ringing is False
    assert alarm._running is True
    # Verify thread start was called
    mock_thread_start.assert_called_once()


@pytest.mark.parametrize(
    "new_id,expected_result,expected_id",
    [
        (5, True, 5),
        ("invalid", False, 0),
    ],
)
def test_set_id(alarm, new_id, expected_result, expected_id):
    result = alarm.set_id(new_id)
    assert result is expected_result
    assert alarm.get_id() == expected_id


def test_get_location(alarm):
    assert alarm.get_location() == (0, 0)


def test_ring_and_stop_alarm(alarm):
    """Test ring and stop alarm operations"""
    # Test ring alarm start
    with patch("time.time", return_value=1000.0):
        alarm.ring_alarm()
    assert alarm.is_ringing() is True
    assert alarm.ring_start_time == 1000.0

    # Test ring when already ringing
    alarm.ring_alarm()
    assert alarm.is_ringing() is True

    # Test stop alarm
    alarm.stop_alarm()
    assert alarm.is_ringing() is False
    assert alarm.ring_start_time is None

    # Test stop when not ringing
    alarm.stop_alarm()
    assert alarm.is_ringing() is False


@pytest.mark.parametrize(
    "ringing,expected_status",
    [
        (True, "RINGING"),
        (False, "SILENT"),
    ],
)
def test_get_info(alarm, ringing, expected_status):
    alarm.ringing = ringing
    alarm.alarm_id = 1
    info = alarm.get_info()
    assert info["alarm_id"] == 1
    assert info["status"] == expected_status
    assert info["ringing"] is ringing


def test_shutdown(alarm):
    alarm.ringing = True
    alarm.shutdown()

    assert alarm._running is False
    assert alarm.ringing is False


@patch("time.sleep")
@patch("time.time")
def test_run_loop_auto_stop(mock_time, mock_sleep, alarm):
    """
    Test the run loop auto-stop logic.
    We simulate the loop running once by having side_effect on sleep.
    """
    # Setup: Alarm is ringing, time has passed ALARM_DURATION
    alarm.ringing = True
    start_t = 1000.0
    alarm.ring_start_time = start_t

    # Sequence of time.time calls:
    # 1. Inside loop check: current time > start + duration
    # 2. Inside stop_alarm calculation
    # 3. Inside stop_alarm calculation (if needed)
    current_t = start_t + ALARM_DURATION + 10
    mock_time.return_value = current_t

    # Side effect for sleep to break the loop after one iteration
    def stop_loop(*args):
        alarm._running = False

    mock_sleep.side_effect = stop_loop

    alarm.run()

    assert alarm.ringing is False
    mock_sleep.assert_called()


@patch("time.sleep")
@patch("time.time")
def test_run_loop_no_auto_stop(mock_time, mock_sleep, alarm):
    """Test run loop when duration hasn't passed."""
    alarm.ringing = True
    start_t = 1000.0
    alarm.ring_start_time = start_t

    # Time has not passed duration yet
    mock_time.return_value = start_t + 1

    def stop_loop(*args):
        alarm._running = False

    mock_sleep.side_effect = stop_loop

    alarm.run()

    assert alarm.ringing is True


@patch("time.sleep")
def test_run_loop_not_ringing(mock_sleep, alarm):
    """Test run loop when alarm is not ringing (line 91->85)."""
    alarm.ringing = False  # Not ringing
    alarm.ring_start_time = None

    def stop_loop(*args):
        alarm._running = False

    mock_sleep.side_effect = stop_loop

    alarm.run()

    # Should complete without error
    assert alarm.ringing is False
