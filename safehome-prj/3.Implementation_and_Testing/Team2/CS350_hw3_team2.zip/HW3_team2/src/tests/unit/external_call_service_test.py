from unittest.mock import patch

from service.external_call_service import ExternalCallService


def test_external_call_service_full():
    """Test singleton, initialization, and call method with various inputs."""
    # Singleton
    service1 = ExternalCallService()
    service2 = ExternalCallService()
    assert service1 is service2
    assert isinstance(service1, ExternalCallService)

    # Call with valid phone number
    with patch("builtins.print") as mock_print:
        result = service1.call("911")
        assert result is True
        mock_print.assert_called_once_with("Calling 911...")

    # Call with empty string
    with patch("builtins.print") as mock_print:
        result = service1.call("")
        assert result is False
        mock_print.assert_not_called()

    # Call with None
    with patch("builtins.print") as mock_print:
        result = service1.call(None)
        assert result is False
        mock_print.assert_not_called()
