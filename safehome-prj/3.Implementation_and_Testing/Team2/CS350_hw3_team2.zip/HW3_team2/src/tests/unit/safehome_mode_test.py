from datetime import datetime

import pytest

from configurations.safehome_mode import SafeHomeMode


@pytest.mark.parametrize(
    "mode_id,mode_name,sensor_ids,expected_sensors",
    [
        (1, "Home", [1, 2, 3], [1, 2, 3]),
        (2, "Away", [], []),
        (3, "Overnight", None, []),
    ],
)
def test_safehome_mode_initialization(
    mode_id, mode_name, sensor_ids, expected_sensors
):
    """Test SafeHomeMode initialization with various parameters"""
    now = datetime.now()
    mode = SafeHomeMode(
        mode_id=mode_id,
        mode_name=mode_name,
        sensor_ids=sensor_ids,
        created_at=now,
        updated_at=now,
    )

    assert mode.get_id() == mode_id
    assert mode.get_mode_name() == mode_name
    assert mode.get_sensor_list() == expected_sensors


def test_safehome_mode_initialization_copies_sensor_list():
    """Test that initialization creates a copy of sensor list"""
    original_list = [1, 2, 3]
    mode = SafeHomeMode(
        mode_id=1,
        mode_name="Home",
        sensor_ids=original_list,
    )

    # Modify original list
    original_list.append(4)

    # Mode's sensor list should be unaffected
    assert mode.get_sensor_list() == [1, 2, 3]


@pytest.mark.parametrize(
    "new_id,expected_result,expected_id",
    [
        (5, True, 5),
        (0, True, 0),
        (-5, True, -5),
        ("not_an_int", False, 1),
    ],
)
def test_safehome_mode_set_id(new_id, expected_result, expected_id):
    """Test setting mode ID with various inputs"""
    mode = SafeHomeMode(mode_id=1, mode_name="Home", sensor_ids=[])
    result = mode.set_id(new_id)
    assert result is expected_result
    assert mode.get_id() == expected_id


def test_safehome_mode_get_id_and_name():
    """Test getting mode ID and name"""
    mode = SafeHomeMode(mode_id=42, mode_name="Extended Travel", sensor_ids=[])
    assert mode.get_id() == 42
    assert mode.get_mode_name() == "Extended Travel"


def test_safehome_mode_set_sensor_list():
    """Test setting sensor list"""
    mode = SafeHomeMode(
        mode_id=1,
        mode_name="Home",
        sensor_ids=[1, 2],
    )

    result = mode.set_sensor_list([10, 20, 30])
    assert result is True
    assert mode.get_sensor_list() == [10, 20, 30]


def test_safehome_mode_set_sensor_list_creates_copy():
    """Test that set_sensor_list creates a copy"""
    mode = SafeHomeMode(
        mode_id=1,
        mode_name="Home",
        sensor_ids=[],
    )

    new_list = [5, 6, 7]
    mode.set_sensor_list(new_list)

    # Modify original list
    new_list.append(8)

    # Mode's sensor list should be unaffected
    assert mode.get_sensor_list() == [5, 6, 7]


def test_safehome_mode_get_sensor_list_returns_copy():
    """Test that get_sensor_list returns a copy"""
    mode = SafeHomeMode(
        mode_id=1,
        mode_name="Home",
        sensor_ids=[1, 2, 3],
    )

    sensor_list = mode.get_sensor_list()
    sensor_list.append(4)

    # Original should not be modified
    assert mode.get_sensor_list() == [1, 2, 3]


@pytest.mark.parametrize(
    "initial_sensors,sensor_to_add,expected_result,expected_list",
    [
        ([1, 2], 3, True, [1, 2, 3]),
        ([1, 2, 3], 2, False, [1, 2, 3]),  # duplicate
        ([1, 2], "not_int", False, [1, 2]),  # invalid type
    ],
)
def test_safehome_mode_add_sensor(
    initial_sensors, sensor_to_add, expected_result, expected_list
):
    """Test adding sensors with various inputs"""
    mode = SafeHomeMode(
        mode_id=1, mode_name="Home", sensor_ids=initial_sensors
    )
    result = mode.add_sensor(sensor_to_add)
    assert result is expected_result
    assert mode.get_sensor_list() == expected_list


@pytest.mark.parametrize(
    "initial_sensors,sensor_to_remove,expected_result,expected_list",
    [
        ([1, 2, 3], 2, True, [1, 3]),
        ([1, 2, 3], 5, False, [1, 2, 3]),  # not found
    ],
)
def test_safehome_mode_remove_sensor(
    initial_sensors, sensor_to_remove, expected_result, expected_list
):
    """Test removing sensors with various inputs"""
    mode = SafeHomeMode(
        mode_id=1, mode_name="Home", sensor_ids=initial_sensors
    )
    result = mode.remove_sensor(sensor_to_remove)
    assert result is expected_result
    assert mode.get_sensor_list() == expected_list


@pytest.mark.parametrize(
    "initial_sensors",
    [
        [1, 2, 3, 4, 5],
        [],
    ],
)
def test_safehome_mode_delete_all_sensors(initial_sensors):
    """Test deleting all sensors"""
    mode = SafeHomeMode(
        mode_id=1, mode_name="Home", sensor_ids=initial_sensors
    )
    mode.delete_all_sensors()
    assert mode.get_sensor_list() == []


@pytest.mark.parametrize(
    "mode_id,mode_name,sensor_ids,expected_count",
    [
        (1, "Home", [1, 2, 3, 4], 4),
        (2, "Away", [], 0),
    ],
)
def test_safehome_mode_str(mode_id, mode_name, sensor_ids, expected_count):
    """Test string representation"""
    mode = SafeHomeMode(
        mode_id=mode_id, mode_name=mode_name, sensor_ids=sensor_ids
    )
    str_repr = str(mode)
    assert f"ID={mode_id}" in str_repr
    assert f"Mode='{mode_name}'" in str_repr
    assert f"Sensors={expected_count}" in str_repr


def test_safehome_mode_to_schema():
    """Test conversion to SafeHomeModeSchema"""
    now = datetime.now()
    mode = SafeHomeMode(
        mode_id=1,
        mode_name="Home",
        sensor_ids=[1, 2, 3],
        created_at=now,
        updated_at=now,
    )

    schema = mode.to_schema()

    assert schema.mode_id == 1
    assert schema.mode_name == "Home"
    assert schema.sensor_ids == [1, 2, 3]
    assert schema.created_at == now
