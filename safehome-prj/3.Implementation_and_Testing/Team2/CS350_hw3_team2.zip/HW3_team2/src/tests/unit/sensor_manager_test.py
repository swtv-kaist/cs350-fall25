from datetime import datetime
from unittest.mock import Mock, patch

import pytest

from database.schema.sensor import SensorType
from device.sensor.interface_sensor import InterfaceSensor
from manager.sensor_manager import SensorManager


@pytest.fixture
def mock_sensor():
    sensor = Mock(spec=InterfaceSensor)
    sensor.sensor_id = 1
    sensor.coordinate_x = 0
    sensor.coordinate_y = 0
    sensor.created_at = datetime(2024, 1, 1, 0, 0, 0)
    sensor.updated_at = datetime(2024, 1, 1, 0, 0, 0)
    sensor.get_type.return_value = SensorType.MOTION_DETECTOR_SENSOR
    return sensor


@pytest.fixture
def sensor_manager(mock_sensor):
    return SensorManager(sensor_dict={1: mock_sensor})


def test_sensor_basic_operations(sensor_manager, mock_sensor):
    """
    Test basic sensor operations: get, arm/disarm, intrude/release, read, move.
    """
    # Get sensor
    assert sensor_manager.get_sensor(1) == mock_sensor

    # Arm/disarm single
    assert sensor_manager.arm_sensor(1) is True
    mock_sensor.arm.assert_called()
    assert sensor_manager.disarm_sensor(1) is True
    mock_sensor.disarm.assert_called()

    # Arm/disarm multiple
    sensor_manager.arm_sensors([1])
    sensor_manager.disarm_sensors([1])

    # Arm/disarm all
    sensor_manager.arm_all_sensors()
    sensor_manager.disarm_all_sensors()

    # Intrude/release
    sensor_manager.intrude_sensor(1)
    mock_sensor.intrude.assert_called()
    sensor_manager.release_sensor(1)
    mock_sensor.release.assert_called()

    # Read sensor
    mock_sensor.read.return_value = True
    assert sensor_manager.read_sensor(1) is True
    mock_sensor.read.return_value = False
    assert sensor_manager.read_sensor(1) is False

    # Get coordinates
    assert sensor_manager.get_coordinates(1) == (0, 0)

    # Move sensor
    assert sensor_manager.move_sensor(1, (10, 10)) is True
    assert mock_sensor.coordinate_x == 10
    assert mock_sensor.coordinate_y == 10


def test_get_all_sensor_info(sensor_manager):
    info = sensor_manager.get_all_sensor_info()
    assert 1 in info
    assert info[1].sensor_id == 1
    assert info[1].created_at == datetime(2024, 1, 1, 0, 0, 0)


def test_start_stop_monitoring(sensor_manager):
    with patch("threading.Thread") as mock_thread:
        sensor_manager.start_monitoring()
        assert sensor_manager._monitoring_active is True
        mock_thread.return_value.start.assert_called_once()

        sensor_manager.stop_monitoring()
        assert sensor_manager._monitoring_active is False
        mock_thread.return_value.join.assert_called()


def test_check_all_sensors_trigger(sensor_manager, mock_sensor):
    # Setup handle_intrusion callback
    mock_handler = Mock()
    sensor_manager.handle_intrusion = mock_handler

    # Setup sensor state (Armed AND Intrusion detected)
    mock_sensor.is_armed.return_value = True
    mock_sensor.read.return_value = True

    sensor_manager._check_all_sensors()

    mock_handler.assert_called_with(1, SensorType.MOTION_DETECTOR_SENSOR)


def test_not_implemented_methods(sensor_manager):
    with pytest.raises(NotImplementedError):
        sensor_manager.add_sensor(2, Mock())
    with pytest.raises(NotImplementedError):
        sensor_manager.remove_sensor(1)


def test_invalid_sensor_id_operations(sensor_manager):
    invalid_id = 999

    assert sensor_manager.arm_sensor(invalid_id) is False
    assert sensor_manager.disarm_sensor(invalid_id) is False
    assert sensor_manager.intrude_sensor(invalid_id) is False
    assert sensor_manager.release_sensor(invalid_id) is False
    assert sensor_manager.read_sensor(invalid_id) is False
    assert sensor_manager.get_coordinates(invalid_id) is None
    assert sensor_manager.move_sensor(invalid_id, (5, 5)) is False

    assert sensor_manager.arm_sensors([invalid_id]) is True
    assert sensor_manager.disarm_sensors([invalid_id]) is True


def test_if_intrusion_detected(sensor_manager, mock_sensor):
    mock_sensor.read.return_value = False
    assert sensor_manager.if_intrusion_detected() is False

    mock_sensor.read.return_value = True
    assert sensor_manager.if_intrusion_detected() is True


def test_monitoring_edge_cases(sensor_manager, mock_sensor):
    """Test monitoring edge cases: already active, not active, no trigger."""
    # Start already active
    sensor_manager._monitoring_active = True
    with patch("threading.Thread") as mock_thread:
        sensor_manager.start_monitoring()
        mock_thread.assert_not_called()

    # Stop not active
    sensor_manager._monitoring_active = False
    sensor_manager.stop_monitoring()

    # Check sensors - no trigger cases
    sensor_manager.handle_intrusion = Mock()
    mock_sensor.is_armed.return_value = False
    mock_sensor.read.return_value = True
    sensor_manager._check_all_sensors()
    sensor_manager.handle_intrusion.assert_not_called()

    mock_sensor.is_armed.return_value = True
    mock_sensor.read.return_value = False
    sensor_manager._check_all_sensors()
    sensor_manager.handle_intrusion.assert_not_called()


def test_monitor_loop_exception_with_sleep(sensor_manager):
    """Test that monitor loop handles exceptions and sleeps."""
    sensor_manager._monitoring_active = True
    mock_log_manager = Mock()
    sensor_manager.log_manager = mock_log_manager

    call_count = [0]
    sleep_calls = []

    def check_sensors_error():
        call_count[0] += 1
        if call_count[0] == 1:
            raise Exception("Test Error")
        sensor_manager._monitoring_active = False

    def track_sleep(duration):
        sleep_calls.append(duration)
        if len(sleep_calls) >= 2:
            sensor_manager._monitoring_active = False

    with (
        patch.object(
            sensor_manager,
            "_check_all_sensors",
            side_effect=check_sensors_error,
        ),
        patch("time.sleep", side_effect=track_sleep),
    ):
        sensor_manager._monitor_sensors_loop()

    assert len(sleep_calls) >= 1
    assert sleep_calls[0] == sensor_manager._monitor_interval
    mock_log_manager.error.assert_called()


def test_stop_monitoring_no_thread(sensor_manager):
    """Test stop_monitoring when _monitor_thread is None (252->254)."""
    sensor_manager._monitoring_active = True
    sensor_manager._monitor_thread = None

    sensor_manager.stop_monitoring()

    assert sensor_manager._monitoring_active is False


def test_monitor_loop_exception_no_log_manager(sensor_manager):
    """Test monitor loop exception when log_manager is None (272->274)."""
    sensor_manager._monitoring_active = True
    sensor_manager.log_manager = None  # No log manager

    call_count = [0]

    def check_sensors_error():
        call_count[0] += 1
        if call_count[0] == 1:
            raise Exception("Test Error")
        sensor_manager._monitoring_active = False

    def stop_after_one(duration):
        sensor_manager._monitoring_active = False

    with (
        patch.object(
            sensor_manager,
            "_check_all_sensors",
            side_effect=check_sensors_error,
        ),
        patch("time.sleep", side_effect=stop_after_one),
    ):
        sensor_manager._monitor_sensors_loop()

    # Should complete without error even without log_manager
