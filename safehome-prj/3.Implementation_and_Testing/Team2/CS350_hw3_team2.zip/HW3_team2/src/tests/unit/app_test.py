from unittest.mock import Mock, patch

from app import App, build_arg_parser


def test_build_arg_parser():
    """Test argument parser creation and parsing."""
    parser = build_arg_parser()

    # Default args
    args = parser.parse_args([])
    assert args.reset_db is False
    assert args.auto_login is False

    # With flags
    args = parser.parse_args(["--reset-db", "--auto-login"])
    assert args.reset_db is True
    assert args.auto_login is True


def test_app_init_and_run():
    """Test App initialization and run method."""
    with patch("app.System") as mock_system_class:
        mock_system = Mock()
        mock_system_class.return_value = mock_system

        mock_args = Mock()
        mock_args.reset_db = False
        mock_args.auto_login = True

        app = App(args=mock_args)
        mock_system_class.assert_called_once_with(
            reset_database=False, auto_login=True
        )

        app.run()
        mock_system.run.assert_called_once()
