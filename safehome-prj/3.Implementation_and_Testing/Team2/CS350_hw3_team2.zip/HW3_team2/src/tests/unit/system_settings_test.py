from datetime import datetime

import pytest

from configurations.system_settings import SystemSettings


def test_system_settings_initialization_all_params():
    """Test SystemSettings initialization with all parameters"""
    now = datetime.now()
    settings = SystemSettings(
        system_setting_id=1,
        panic_phone_number="911",
        homeowner_phone_number="555-1234",
        system_lock_time=30,
        alarm_delay_time=10,
        created_at=now,
        updated_at=now,
    )

    assert settings.system_setting_id == 1
    assert settings.get_panic_phone_number() == "911"
    assert settings.get_homeowner_phone_number() == "555-1234"
    assert settings.get_system_lock_time() == 30
    assert settings.get_alarm_delay_time() == 10


def test_system_settings_initialization_defaults():
    """Test SystemSettings initialization with default None values"""
    settings = SystemSettings(system_setting_id=1)

    assert settings.system_setting_id == 1
    assert settings.get_panic_phone_number() is None
    assert settings.get_homeowner_phone_number() is None
    assert settings.get_system_lock_time() is None
    assert settings.get_alarm_delay_time() is None


@pytest.mark.parametrize(
    "phone_type,initial,new_value,expected_result,expected_value,raises_error",
    [
        ("panic", None, "911", True, "911", False),
        ("panic", "911", 12345, False, "911", False),
        ("panic", "911", "555-HELP", None, "911", True),
        ("homeowner", None, "555-1234", True, "555-1234", False),
        ("homeowner", "555-0000", 5551234, False, "555-0000", False),
        ("homeowner", "555-0000", "(123) 456-7890", None, "555-0000", True),
    ],
)
def test_system_settings_set_phone_number(
    phone_type,
    initial,
    new_value,
    expected_result,
    expected_value,
    raises_error,
):
    """Test setting phone numbers with various inputs"""
    kwargs = {f"{phone_type}_phone_number": initial}
    settings = SystemSettings(system_setting_id=1, **kwargs)
    setter = getattr(settings, f"set_{phone_type}_phone_number")
    getter = getattr(settings, f"get_{phone_type}_phone_number")

    if raises_error:
        with pytest.raises(
            ValueError, match="Phone number must contain only 0~9, \\+ and -"
        ):
            setter(new_value)
    else:
        result = setter(new_value)
        assert result is expected_result

    assert getter() == expected_value


@pytest.mark.parametrize(
    "phone_type,initial,expected",
    [
        ("panic", "112", "112"),
        ("panic", None, None),
        ("homeowner", "555-9876", "555-9876"),
        ("homeowner", None, None),
    ],
)
def test_system_settings_get_phone_number(phone_type, initial, expected):
    """Test getting phone numbers"""
    kwargs = {f"{phone_type}_phone_number": initial}
    settings = SystemSettings(system_setting_id=1, **kwargs)
    getter = getattr(settings, f"get_{phone_type}_phone_number")
    assert getter() == expected


@pytest.mark.parametrize(
    "initial,new_value,expected_result,expected_value",
    [
        (None, 45, True, 45),
        (None, 0, True, 0),
        (30, -5, False, 30),
        (30, "30", False, 30),
    ],
)
def test_system_settings_set_system_lock_time(
    initial, new_value, expected_result, expected_value
):
    """Test setting system lock time with various inputs"""
    settings = SystemSettings(system_setting_id=1, system_lock_time=initial)
    result = settings.set_system_lock_time(new_value)
    assert result is expected_result
    assert settings.get_system_lock_time() == expected_value


@pytest.mark.parametrize(
    "initial,expected",
    [
        (60, 60),
        (None, None),
    ],
)
def test_system_settings_get_system_lock_time(initial, expected):
    """Test getting system lock time"""
    settings = SystemSettings(system_setting_id=1, system_lock_time=initial)
    assert settings.get_system_lock_time() == expected


@pytest.mark.parametrize(
    "initial,new_value,expected_result,expected_value,raises_error",
    [
        (None, 10, True, 10, False),
        (None, 5, True, 5, False),
        (10, "10", False, 10, False),
        (10, 4, None, 10, True),
        (10, 0, None, 10, True),
        (10, -5, None, 10, True),
    ],
)
def test_system_settings_set_alarm_delay_time(
    initial, new_value, expected_result, expected_value, raises_error
):
    """Test setting alarm delay time with various inputs"""
    settings = SystemSettings(system_setting_id=1, alarm_delay_time=initial)
    if raises_error:
        with pytest.raises(
            ValueError, match="Alarm delay time must be at least 5 minutes"
        ):
            settings.set_alarm_delay_time(new_value)
    else:
        result = settings.set_alarm_delay_time(new_value)
        assert result is expected_result
    assert settings.get_alarm_delay_time() == expected_value


@pytest.mark.parametrize(
    "initial,expected",
    [
        (15, 15),
        (None, None),
    ],
)
def test_system_settings_get_alarm_delay_time(initial, expected):
    """Test getting alarm delay time"""
    settings = SystemSettings(system_setting_id=1, alarm_delay_time=initial)
    assert settings.get_alarm_delay_time() == expected


@pytest.mark.parametrize(
    "panic,homeowner,lock_time,delay,expected_panic,expected_homeowner"
    ",expected_lock,expected_delay",
    [
        ("911", "555-1234", 30, 10, "'911'", "'555-1234'", "30min", "10min"),
        (None, None, None, None, "'None'", "'None'", "Nonemin", "Nonemin"),
    ],
)
def test_system_settings_str(
    panic,
    homeowner,
    lock_time,
    delay,
    expected_panic,
    expected_homeowner,
    expected_lock,
    expected_delay,
):
    """Test string representation"""
    settings = SystemSettings(
        system_setting_id=1,
        panic_phone_number=panic,
        homeowner_phone_number=homeowner,
        system_lock_time=lock_time,
        alarm_delay_time=delay,
    )
    str_repr = str(settings)
    assert f"panic_phone_number={expected_panic}" in str_repr
    assert f"homeowner_phone_number={expected_homeowner}" in str_repr
    assert f"lock_time={expected_lock}" in str_repr
    assert f"alarm_delay={expected_delay}" in str_repr


@pytest.mark.parametrize(
    "setting_id,panic,homeowner,lock_time,delay",
    [
        (1, "911", "555-1234", 30, 10),
        (2, None, None, None, None),
    ],
)
def test_system_settings_to_schema(
    setting_id, panic, homeowner, lock_time, delay
):
    """Test conversion to SystemSettingSchema"""
    settings = SystemSettings(
        system_setting_id=setting_id,
        panic_phone_number=panic,
        homeowner_phone_number=homeowner,
        system_lock_time=lock_time,
        alarm_delay_time=delay,
    )
    schema = settings.to_schema()
    assert schema.system_setting_id == setting_id
    assert schema.panic_phone_number == panic
    assert schema.homeowner_phone_number == homeowner
    assert schema.system_lock_time == lock_time
    assert schema.alarm_delay_time == delay
