from datetime import datetime
from unittest.mock import Mock

import pytest  # pytest 임포트 확인

from database.schema.sensor import SensorType
from device.sensor import create_sensor_from_schema
from device.sensor.motion_detector_sensor import MotionDetectorSensor


def create_mock_schema(sensor_type, sensor_id=1):
    schema = Mock()
    schema.sensor_type = sensor_type
    schema.sensor_id = sensor_id
    schema.coordinate_x = 10
    schema.coordinate_y = 20
    schema.zone_id = 5
    schema.created_at = datetime.now()
    schema.updated_at = datetime.now()
    schema.armed = False
    return schema


def test_motion_detector_full_lifecycle():
    """Test init, arming, detection, and disarm behavior."""
    # Init
    schema = create_mock_schema(
        SensorType.MOTION_DETECTOR_SENSOR, sensor_id=10
    )
    sensor = MotionDetectorSensor(schema)
    assert sensor.get_id() == 10
    assert sensor.get_type() == SensorType.MOTION_DETECTOR_SENSOR
    assert sensor.coordinate_x == 10
    assert not sensor.is_armed()

    # Invalid type
    with pytest.raises(
        AssertionError, match="Sensor type must be MOTION_DETECTOR_SENSOR"
    ):
        MotionDetectorSensor(create_mock_schema(SensorType.WINDOOR_SENSOR))

    # Arming
    sensor.arm()
    assert sensor.is_armed()
    sensor.disarm()
    assert not sensor.is_armed()

    # Detection logic when armed
    sensor.arm()
    assert not sensor.read()
    sensor.intrude()
    assert sensor.read() is True
    sensor.release()
    assert sensor.read() is False

    # Read detection when disarmed (should be False)
    sensor.disarm()
    sensor.intrude()
    assert sensor.read() is False
    sensor.arm()
    assert sensor.read() is True


def test_create_sensor_from_schema():
    """Test factory function creates correct instance or raises error."""
    # Success
    schema = create_mock_schema(SensorType.MOTION_DETECTOR_SENSOR)
    sensor = create_sensor_from_schema(schema)
    assert isinstance(sensor, MotionDetectorSensor)

    # Invalid type
    schema = create_mock_schema("UNKNOWN_TYPE")
    with pytest.raises(ValueError, match="Unknown sensor type"):
        create_sensor_from_schema(schema)
