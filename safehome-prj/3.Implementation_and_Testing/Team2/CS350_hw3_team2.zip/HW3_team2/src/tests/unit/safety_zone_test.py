from datetime import datetime

import pytest

from configurations.safety_zone import SafetyZone


@pytest.mark.parametrize(
    "zone_id,zone_name,sensor_list,arm_status,expected_sensors,expected_armed",
    [
        (1, "Living Room", [1, 2, 3], True, [1, 2, 3], True),
        (2, "Bedroom", None, False, [], False),
    ],
)
def test_safety_zone_initialization(
    zone_id,
    zone_name,
    sensor_list,
    arm_status,
    expected_sensors,
    expected_armed,
):
    """Test SafetyZone initialization with various parameters"""
    zone = SafetyZone(
        zone_id=zone_id,
        zone_name=zone_name,
        coordinate_x1=10.0,
        coordinate_y1=20.0,
        coordinate_x2=100.0,
        coordinate_y2=200.0,
        sensor_id_list=sensor_list,
        arm_status=arm_status,
    )

    assert zone.get_zone_id() == zone_id
    assert zone.get_zone_name() == zone_name
    assert zone.get_sensor_list() == expected_sensors
    assert zone.is_armed() is expected_armed


@pytest.mark.parametrize(
    "new_id,expected_result,expected_id",
    [
        (5, True, 5),
        ("not_an_int", False, 1),
    ],
)
def test_safety_zone_set_id(new_id, expected_result, expected_id):
    """Test setting zone ID with various inputs"""
    zone = SafetyZone(
        zone_id=1,
        zone_name="Test",
        coordinate_x1=0.0,
        coordinate_y1=0.0,
        coordinate_x2=10.0,
        coordinate_y2=10.0,
    )
    result = zone.set_id(new_id)
    assert result is expected_result
    assert zone.get_zone_id() == expected_id


@pytest.mark.parametrize(
    "new_name,expected_result,expected_name",
    [
        ("New Name", True, "New Name"),
        (12345, False, "Valid Name"),
    ],
)
def test_safety_zone_set_zone_name(new_name, expected_result, expected_name):
    """Test setting zone name with various inputs"""
    zone = SafetyZone(
        zone_id=1,
        zone_name="Valid Name",
        coordinate_x1=0.0,
        coordinate_y1=0.0,
        coordinate_x2=10.0,
        coordinate_y2=10.0,
    )
    result = zone.set_zone_name(new_name)
    assert result is expected_result
    assert zone.get_zone_name() == expected_name


@pytest.mark.parametrize(
    "coords,expected_result,expected_coords",
    [
        ((5.0, 15.0, 25.0, 35.0), True, (5.0, 15.0, 25.0, 35.0)),
        ((5, 15, 25, 35), True, (5, 15, 25, 35)),
        ((-50.0, -100.0, 50.0, 100.0), True, (-50.0, -100.0, 50.0, 100.0)),
        (("invalid", 15.0, 25.0, 35.0), False, (0.0, 0.0, 10.0, 10.0)),
    ],
)
def test_safety_zone_set_coordinates(coords, expected_result, expected_coords):
    """Test setting coordinates with various inputs"""
    zone = SafetyZone(
        zone_id=1,
        zone_name="Test",
        coordinate_x1=0.0,
        coordinate_y1=0.0,
        coordinate_x2=10.0,
        coordinate_y2=10.0,
    )
    result = zone.set_coordinates(*coords)
    assert result is expected_result
    assert zone.get_coordinates() == expected_coords


@pytest.mark.parametrize(
    "new_list,expected_result,expected_list",
    [
        ([10, 20, 30], True, [10, 20, 30]),
        ("not a list", False, [1, 2]),
        ([1, "2", 3], False, [1, 2]),
    ],
)
def test_safety_zone_set_sensor_list(new_list, expected_result, expected_list):
    """Test setting sensor list with various inputs"""
    zone = SafetyZone(
        zone_id=1,
        zone_name="Test",
        coordinate_x1=0.0,
        coordinate_y1=0.0,
        coordinate_x2=10.0,
        coordinate_y2=10.0,
        sensor_id_list=[1, 2],
    )
    result = zone.set_sensor_list(new_list)
    assert result is expected_result
    assert zone.get_sensor_list() == expected_list


def test_safety_zone_get_sensor_list_returns_copy():
    """Test that get_sensor_list returns a copy"""
    zone = SafetyZone(
        zone_id=1,
        zone_name="Test",
        coordinate_x1=0.0,
        coordinate_y1=0.0,
        coordinate_x2=10.0,
        coordinate_y2=10.0,
        sensor_id_list=[1, 2, 3],
    )

    sensor_list = zone.get_sensor_list()
    sensor_list.append(4)

    # Original should not be modified
    assert zone.get_sensor_list() == [1, 2, 3]


@pytest.mark.parametrize(
    "initial_sensors,sensor_to_add,expected_result,expected_list",
    [
        ([1, 2], 3, True, [1, 2, 3]),
        ([1, 2, 3], 2, False, [1, 2, 3]),  # duplicate
        ([1, 2], "not_int", False, [1, 2]),  # invalid type
    ],
)
def test_safety_zone_add_sensor(
    initial_sensors, sensor_to_add, expected_result, expected_list
):
    """Test adding sensors with various inputs"""
    zone = SafetyZone(
        zone_id=1,
        zone_name="Test",
        coordinate_x1=0.0,
        coordinate_y1=0.0,
        coordinate_x2=10.0,
        coordinate_y2=10.0,
        sensor_id_list=initial_sensors,
    )
    result = zone.add_sensor(sensor_to_add)
    assert result is expected_result
    assert zone.get_sensor_list() == expected_list


@pytest.mark.parametrize(
    "initial_sensors,sensor_to_remove,expected_result,expected_list",
    [
        ([1, 2, 3], 2, True, [1, 3]),
        ([1, 2, 3], 5, False, [1, 2, 3]),  # not found
    ],
)
def test_safety_zone_remove_sensor(
    initial_sensors, sensor_to_remove, expected_result, expected_list
):
    """Test removing sensors with various inputs"""
    zone = SafetyZone(
        zone_id=1,
        zone_name="Test",
        coordinate_x1=0.0,
        coordinate_y1=0.0,
        coordinate_x2=10.0,
        coordinate_y2=10.0,
        sensor_id_list=initial_sensors,
    )
    result = zone.remove_sensor(sensor_to_remove)
    assert result is expected_result
    assert zone.get_sensor_list() == expected_list


def test_safety_zone_delete_all_sensors():
    """Test deleting all sensors"""
    zone = SafetyZone(
        zone_id=1,
        zone_name="Test",
        coordinate_x1=0.0,
        coordinate_y1=0.0,
        coordinate_x2=10.0,
        coordinate_y2=10.0,
        sensor_id_list=[1, 2, 3, 4, 5],
    )

    zone.delete_all_sensors()
    assert zone.get_sensor_list() == []


@pytest.mark.parametrize(
    "initial_armed,action,expected_armed",
    [
        (False, "arm", True),
        (True, "disarm", False),
        (True, "arm", True),  # arm when already armed
        (False, "disarm", False),  # disarm when already disarmed
    ],
)
def test_safety_zone_arm_disarm(initial_armed, action, expected_armed):
    """Test arming and disarming a zone"""
    zone = SafetyZone(
        zone_id=1,
        zone_name="Test",
        coordinate_x1=0.0,
        coordinate_y1=0.0,
        coordinate_x2=10.0,
        coordinate_y2=10.0,
        arm_status=initial_armed,
    )
    getattr(zone, action)()
    assert zone.is_armed() is expected_armed


def test_safety_zone_to_schema():
    """Test conversion to SafetyZoneSchema"""
    now = datetime.now()
    zone = SafetyZone(
        zone_id=1,
        zone_name="Test Zone",
        coordinate_x1=10.0,
        coordinate_y1=20.0,
        coordinate_x2=100.0,
        coordinate_y2=200.0,
        sensor_id_list=[1, 2, 3],
        arm_status=True,
        created_at=now,
        updated_at=now,
    )

    schema = zone.to_schema()

    assert schema.zone_id == 1
    assert schema.zone_name == "Test Zone"
    assert schema.coordinate_x1 == 10.0
    assert schema.coordinate_y1 == 20.0
    assert schema.coordinate_x2 == 100.0
    assert schema.coordinate_y2 == 200.0
    assert schema.sensor_id_list == [1, 2, 3]
    assert schema.arm_status is True
    assert schema.created_at == now
    assert schema.updated_at == now


@pytest.mark.parametrize(
    "zone_id,zone_name,sensor_list,arm_status,expected_sensor_count,"
    "expected_status",
    [
        (1, "Living Room", [1, 2, 3], True, 3, "ARMED"),
        (2, "Bedroom", [4, 5], False, 2, "DISARMED"),
    ],
)
def test_safety_zone_str(
    zone_id,
    zone_name,
    sensor_list,
    arm_status,
    expected_sensor_count,
    expected_status,
):
    """Test string representation"""
    zone = SafetyZone(
        zone_id=zone_id,
        zone_name=zone_name,
        coordinate_x1=0.0,
        coordinate_y1=0.0,
        coordinate_x2=10.0,
        coordinate_y2=10.0,
        sensor_id_list=sensor_list,
        arm_status=arm_status,
    )
    str_repr = str(zone)
    assert f"ID={zone_id}" in str_repr
    assert zone_name in str_repr
    assert f"Sensors={expected_sensor_count}" in str_repr
    assert expected_status in str_repr


def test_safety_zone_coordinates_with_negative_values():
    """Test coordinates with negative values"""
    zone = SafetyZone(
        zone_id=1,
        zone_name="Test",
        coordinate_x1=-10.0,
        coordinate_y1=-20.0,
        coordinate_x2=30.0,
        coordinate_y2=40.0,
    )
    assert zone.get_coordinates() == (-10.0, -20.0, 30.0, 40.0)
