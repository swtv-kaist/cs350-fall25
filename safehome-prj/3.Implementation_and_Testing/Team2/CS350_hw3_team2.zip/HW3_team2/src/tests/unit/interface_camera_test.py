import pytest

from device.appliance.interface_camera import InterfaceCamera


class ConcreteCamera(InterfaceCamera):
    """Concrete implementation for testing abstract interface."""

    def __init__(self):
        self._id = 0

    def set_id(self, id_):
        self._id = id_

    def get_id(self):
        return self._id

    def get_view(self):
        return None

    def pan_right(self):
        return True

    def pan_left(self):
        return True

    def zoom_in(self):
        return True

    def zoom_out(self):
        return True


def test_interface_camera_implementation():
    """Test that InterfaceCamera can be properly subclassed."""
    camera = ConcreteCamera()

    # Test all interface methods
    camera.set_id(5)
    assert camera.get_id() == 5
    assert camera.get_view() is None
    assert camera.pan_right() is True
    assert camera.pan_left() is True
    assert camera.zoom_in() is True
    assert camera.zoom_out() is True


def test_interface_camera_is_abstract():
    """Test that InterfaceCamera cannot be instantiated directly."""
    with pytest.raises(TypeError):
        InterfaceCamera()
