"""
Unit tests for login_page.py
Tests LoginPage class with comprehensive coverage
"""

from unittest.mock import Mock, patch

import customtkinter as ctk
import pytest

from core.pages.login_page import LoginPage


# Fixtures
@pytest.fixture
def root():
    """Create and cleanup CTk root window"""
    root_window = ctk.CTk()
    root_window.withdraw()
    yield root_window
    try:
        root_window.destroy()
    except Exception:
        pass


@pytest.fixture
def mock_login_manager():
    """Create mock login manager"""
    return Mock()


@pytest.fixture
def mock_on_login_success():
    """Create mock login success callback"""
    return Mock()


@pytest.fixture
def mock_is_system_powered():
    """Create mock system powered check"""
    return Mock(return_value=True)


# Tests
def test_init_and_draw(
    root, mock_login_manager, mock_on_login_success, mock_is_system_powered
):
    """Test LoginPage initialization and draw_page."""
    # Basic init
    page = LoginPage(
        root, "login_page", mock_login_manager, mock_on_login_success
    )
    assert page.get_id() == "login_page"
    assert page.login_manager == mock_login_manager
    assert page.on_login_success == mock_on_login_success

    # With is_system_powered
    page = LoginPage(
        root,
        "login_page",
        mock_login_manager,
        mock_on_login_success,
        is_system_powered=mock_is_system_powered,
    )
    assert page.is_system_powered == mock_is_system_powered

    # Widgets created
    assert page.username_entry is not None
    assert page.password_entry is not None
    assert isinstance(page.username_entry, ctk.CTkEntry)
    assert isinstance(page.password_entry, ctk.CTkEntry)


@patch("core.pages.login_page.show_toast")
def test_attempt_login_edge_cases(
    mock_toast, root, mock_login_manager, mock_on_login_success
):
    """
    Test attempt_login with edge cases: no widgets, not powered, no manager,
     empty fields.
    """
    # Widgets not initialized
    page = LoginPage(
        root, "login_page", mock_login_manager, mock_on_login_success
    )
    page.username_entry = None
    page.password_entry = None
    page.attempt_login()
    mock_login_manager.login_web.assert_not_called()

    # System not powered
    page = LoginPage(
        root,
        "login_page",
        mock_login_manager,
        mock_on_login_success,
        is_system_powered=Mock(return_value=False),
    )
    page.username_entry.insert(0, "testuser")
    page.password_entry.insert(0, "testpass")
    page.attempt_login()
    mock_login_manager.login_web.assert_not_called()

    # No login manager
    mock_toast.reset_mock()
    page = LoginPage(root, "login_page", None, mock_on_login_success)
    page.username_entry.insert(0, "testuser")
    page.password_entry.insert(0, "testpass")
    page.attempt_login()
    mock_toast.assert_called()

    # Empty username
    mock_toast.reset_mock()
    page = LoginPage(
        root, "login_page", mock_login_manager, mock_on_login_success
    )
    page.password_entry.insert(0, "testpass")
    page.attempt_login()
    assert "required" in mock_toast.call_args[0][1].lower()

    # Empty password
    mock_toast.reset_mock()
    page = LoginPage(
        root, "login_page", mock_login_manager, mock_on_login_success
    )
    page.username_entry.insert(0, "testuser")
    page.attempt_login()
    assert "required" in mock_toast.call_args[0][1].lower()


@patch("core.pages.login_page.show_toast")
def test_attempt_login_success_and_failure(
    mock_toast, root, mock_on_login_success
):
    """Test login success and failure scenarios."""
    # Success
    mock_login_manager = Mock()
    mock_login_manager.login_web.return_value = True
    page = LoginPage(
        root, "login_page", mock_login_manager, mock_on_login_success
    )
    page.username_entry.insert(0, "testuser")
    page.password_entry.insert(0, "testpass")
    page.attempt_login()
    mock_login_manager.login_web.assert_called_once_with(
        "testuser", "testpass"
    )
    mock_on_login_success.assert_called_once()

    # Failure
    mock_toast.reset_mock()
    mock_on_login_success.reset_mock()
    mock_login_manager = Mock()
    mock_login_manager.login_web.return_value = False
    page = LoginPage(
        root, "login_page", mock_login_manager, mock_on_login_success
    )
    page.username_entry.insert(0, "testuser")
    page.password_entry.insert(0, "wrongpass")
    page.attempt_login()
    mock_on_login_success.assert_not_called()
    assert "incorrect" in mock_toast.call_args[0][1].lower()


def test_utility_methods_and_bindings(
    root, mock_login_manager, mock_on_login_success
):
    """Test set_login_manager, key bindings, and password masking."""
    # set_login_manager
    page = LoginPage(root, "login_page", None, mock_on_login_success)
    new_manager = Mock()
    page.set_login_manager(new_manager)
    assert page.login_manager == new_manager

    # Key bindings - username and password entries accessible
    page = LoginPage(
        root, "login_page", mock_login_manager, mock_on_login_success
    )
    assert page.username_entry is not None
    assert page.password_entry is not None
    page.username_entry.focus_set()
    page.password_entry.focus_set()

    # Password masking
    assert page.password_entry.cget("show") == "*"
