"""
Integration Test: SingleCameraViewPage + CameraManager

Tests the interaction between SingleCameraViewPage and CameraManager.
Verifies camera control operations (pan, zoom) and view updates.
"""

from unittest.mock import MagicMock

import pytest

from database.schema.camera import CameraControlType
from device.appliance.camera import SafeHomeCamera
from manager.camera_manager import CameraManager

# ==================== Fixtures ====================


@pytest.fixture
def mock_storage_manager():
    """Create a mock StorageManager."""
    storage = MagicMock()
    storage.get_all_cameras.return_value = []
    storage.update_camera.return_value = True
    return storage


@pytest.fixture
def camera():
    """Create a real SafeHomeCamera instance."""
    cam = SafeHomeCamera(
        camera_id=1,
        coordinate_x=100,
        coordinate_y=100,
        pan=0,
        zoom_setting=1,
        has_password=False,
        password=None,
        enabled=True,
    )
    return cam


@pytest.fixture
def camera_manager(mock_storage_manager, camera):
    """Create CameraManager with real Camera instance."""
    manager = CameraManager(storage_manager=mock_storage_manager)
    manager.camera_list = [camera]
    return manager


# ==================== Pan Control Integration Tests ====================


def test_single_camera_page_pan_left_through_manager(camera_manager, camera):
    """Test pan left operation from page through manager."""
    # Arrange
    initial_pan = camera.pan

    # Act - Simulate SingleCameraViewPage.pan_left() calling camera_manager
    result = camera_manager.control_single_camera(
        camera.get_id(), CameraControlType.PAN_LEFT
    )

    # Assert
    assert result is True
    assert camera.pan == initial_pan - 1


def test_single_camera_page_pan_right_through_manager(camera_manager, camera):
    """Test pan right operation from page through manager."""
    # Arrange
    initial_pan = camera.pan

    # Act - Simulate SingleCameraViewPage.pan_right() calling camera_manager
    result = camera_manager.control_single_camera(
        camera.get_id(), CameraControlType.PAN_RIGHT
    )

    # Assert
    assert result is True
    assert camera.pan == initial_pan + 1


# ==================== Zoom Control Integration Tests ====================


def test_single_camera_page_zoom_in_through_manager(camera_manager, camera):
    """Test zoom in operation from page through manager."""
    # Arrange
    initial_zoom = camera.zoom_setting

    # Act - Simulate SingleCameraViewPage.zoom_in() calling camera_manager
    result = camera_manager.control_single_camera(
        camera.get_id(), CameraControlType.ZOOM_IN
    )

    # Assert
    assert result is True
    assert camera.zoom_setting == initial_zoom + 1


def test_single_camera_page_zoom_out_at_minimum(camera_manager, camera):
    """Test zoom out at minimum zoom level returns False."""
    # Arrange - camera is already at minimum zoom (1)
    assert camera.zoom_setting == SafeHomeCamera.MIN_ZOOM

    # Act
    result = camera_manager.control_single_camera(
        camera.get_id(), CameraControlType.ZOOM_OUT
    )

    # Assert
    assert result is False
    assert camera.zoom_setting == SafeHomeCamera.MIN_ZOOM


# ==================== Camera State Integration Tests ====================


def test_single_camera_page_disabled_camera_control_blocked(
    camera_manager, camera
):
    """Test that disabled camera cannot be controlled from page."""
    # Arrange - Disable camera
    camera.disable()
    assert camera.is_enabled() is False

    # Act - Try to control disabled camera
    # In SingleCameraViewPage, controls check camera.is_enabled() first
    can_control = camera.is_enabled()

    # Assert
    assert can_control is False
