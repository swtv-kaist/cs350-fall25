"""
Integration Test: SensorManager + AlarmManager

Tests the interaction between SensorManager and AlarmManager.
Verifies intrusion detection triggering alarm and sensor-alarm coordination.
"""

from datetime import datetime

import pytest

from database.schema.sensor import SensorSchema, SensorType
from device.appliance.alarm import Alarm
from device.sensor.motion_detector_sensor import MotionDetectorSensor
from device.sensor.window_door_sensor import WindowDoorSensor
from manager.alarm_manager import AlarmManager
from manager.sensor_manager import SensorManager

# ==================== Fixtures ====================


@pytest.fixture
def alarm():
    """Create a real Alarm instance."""
    alarm_instance = Alarm()
    alarm_instance.set_id(1)
    yield alarm_instance
    alarm_instance.shutdown()


@pytest.fixture
def alarm_manager(alarm):
    """Create AlarmManager with real Alarm instance."""
    return AlarmManager(alarm=alarm)


@pytest.fixture
def sensors():
    """Create sensor instances for testing."""
    now = datetime.now()
    windoor_schema = SensorSchema(
        sensor_id=1,
        sensor_type=SensorType.WINDOOR_SENSOR,
        coordinate_x=100,
        coordinate_y=100,
        armed=False,
        created_at=now,
        updated_at=now,
    )
    motion_schema = SensorSchema(
        sensor_id=2,
        sensor_type=SensorType.MOTION_DETECTOR_SENSOR,
        coordinate_x=200,
        coordinate_y=200,
        coordinate_x2=250,
        coordinate_y2=250,
        armed=False,
        created_at=now,
        updated_at=now,
    )
    windoor = WindowDoorSensor(sensor_schema=windoor_schema)
    motion = MotionDetectorSensor(sensor_schema=motion_schema)
    return {1: windoor, 2: motion}


@pytest.fixture
def sensor_manager(sensors, alarm_manager):
    """Create SensorManager with sensors and intrusion handler."""
    intrusion_triggered = []

    def handle_intrusion(sensor_id, sensor_type):
        intrusion_triggered.append((sensor_id, sensor_type))
        alarm_manager.ring_alarm()

    manager = SensorManager(
        sensor_dict=sensors,
        handle_intrusion=handle_intrusion,
    )
    manager._intrusion_triggered = intrusion_triggered
    return manager


# ==================== Intrusion Detection Integration Tests =============


def test_armed_sensor_intrusion_triggers_alarm(
    sensor_manager, alarm_manager, alarm
):
    """Test that armed sensor intrusion triggers alarm through handler."""
    # Arrange
    sensor_manager.arm_sensor(1)

    # Act - Simulate intrusion
    sensor_manager.intrude_sensor(1)
    # Manually call check since monitoring thread isn't running
    sensor_manager._check_all_sensors()

    # Assert
    assert alarm_manager.is_ringing() is True
    assert len(sensor_manager._intrusion_triggered) == 1

    # Cleanup
    alarm_manager.stop_alarm()


def test_disarmed_sensor_intrusion_does_not_trigger_alarm(
    sensor_manager, alarm_manager, alarm
):
    """Test that disarmed sensor intrusion does not trigger alarm."""
    # Arrange - Sensor is disarmed by default
    assert sensor_manager.get_sensor(1).is_armed() is False

    # Act - Simulate intrusion on disarmed sensor
    sensor_manager.intrude_sensor(1)
    sensor_manager._check_all_sensors()

    # Assert
    assert alarm_manager.is_ringing() is False
    assert len(sensor_manager._intrusion_triggered) == 0


# ==================== Sensor State and Alarm Coordination Tests =========


def test_stop_alarm_after_intrusion_detected(
    sensor_manager, alarm_manager, alarm
):
    """Test stopping alarm after intrusion detection."""
    # Arrange
    sensor_manager.arm_sensor(1)
    sensor_manager.intrude_sensor(1)
    sensor_manager._check_all_sensors()
    assert alarm_manager.is_ringing() is True

    # Act - Stop alarm
    alarm_manager.stop_alarm()

    # Assert
    assert alarm_manager.is_ringing() is False


def test_multiple_sensors_intrusion_single_alarm(
    sensor_manager, alarm_manager, alarm
):
    """Test multiple sensor intrusions trigger alarm (both detected)."""
    # Arrange
    sensor_manager.arm_all_sensors()

    # Act - Trigger intrusion on both sensors at once, then check
    sensor_manager.intrude_sensor(1)
    sensor_manager.intrude_sensor(2)
    sensor_manager._check_all_sensors()

    # Assert - Alarm is ringing
    assert alarm_manager.is_ringing() is True
    # Both sensors should have been detected
    triggered_ids = [t[0] for t in sensor_manager._intrusion_triggered]
    assert 1 in triggered_ids
    assert 2 in triggered_ids

    # Cleanup
    alarm_manager.stop_alarm()


# ==================== Sensor Release Integration Tests ====================


def test_release_sensor_clears_intrusion_state(sensor_manager):
    """Test releasing sensor clears intrusion state."""
    # Arrange - Arm and intrude sensor
    sensor_manager.arm_sensor(1)
    sensor_manager.intrude_sensor(1)
    assert sensor_manager.read_sensor(1) is True

    # Act
    sensor_manager.release_sensor(1)

    # Assert
    assert sensor_manager.read_sensor(1) is False
