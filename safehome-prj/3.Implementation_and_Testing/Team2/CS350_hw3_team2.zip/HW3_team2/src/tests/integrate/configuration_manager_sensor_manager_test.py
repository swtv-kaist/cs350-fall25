"""
Integration Test: ConfigurationManager + SensorManager

Tests the interaction between ConfigurationManager and SensorManager.
Verifies SafeHome mode changes,
safety zone management, and sensor coordination.
"""

import os
import tempfile
from datetime import datetime

import pytest

from database.schema.sensor import SensorSchema, SensorType
from device.sensor.motion_detector_sensor import MotionDetectorSensor
from device.sensor.window_door_sensor import WindowDoorSensor
from manager.configuration_manager import ConfigurationManager
from manager.sensor_manager import SensorManager
from manager.storage_manager import StorageManager

# ==================== Fixtures ====================


@pytest.fixture
def temp_db_path():
    """Create a temporary database file path."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield os.path.join(tmpdir, "test_config.db")


@pytest.fixture
def storage_manager(temp_db_path):
    """Create a real StorageManager with test database."""
    StorageManager._instance = None
    manager = StorageManager(
        db_path=temp_db_path,
        reset_database=True,
    )
    yield manager
    manager.clean_up()


@pytest.fixture
def sensors():
    """Create sensor instances for testing."""
    now = datetime.now()
    windoor1_schema = SensorSchema(
        sensor_id=1,
        sensor_type=SensorType.WINDOOR_SENSOR,
        coordinate_x=50,
        coordinate_y=50,
        armed=False,
        created_at=now,
        updated_at=now,
    )
    windoor2_schema = SensorSchema(
        sensor_id=2,
        sensor_type=SensorType.WINDOOR_SENSOR,
        coordinate_x=150,
        coordinate_y=150,
        armed=False,
        created_at=now,
        updated_at=now,
    )
    motion_schema = SensorSchema(
        sensor_id=3,
        sensor_type=SensorType.MOTION_DETECTOR_SENSOR,
        coordinate_x=100,
        coordinate_y=100,
        coordinate_x2=200,
        coordinate_y2=200,
        armed=False,
        created_at=now,
        updated_at=now,
    )
    windoor1 = WindowDoorSensor(sensor_schema=windoor1_schema)
    windoor2 = WindowDoorSensor(sensor_schema=windoor2_schema)
    motion = MotionDetectorSensor(sensor_schema=motion_schema)
    return {1: windoor1, 2: windoor2, 3: motion}


@pytest.fixture
def sensor_manager(sensors):
    """Create SensorManager with test sensors."""
    return SensorManager(sensor_dict=sensors)


@pytest.fixture
def config_manager(storage_manager, sensor_manager):
    """Create ConfigurationManager with StorageManager and SensorManager."""
    return ConfigurationManager(
        storage_manager=storage_manager,
        sensor_manager=sensor_manager,
    )


# ==================== SafeHome Mode Integration Tests ====================


def test_change_to_safehome_mode_arms_sensors(config_manager, sensor_manager):
    """Test changing to SafeHome mode arms specified sensors."""
    from configurations.safehome_mode import SafeHomeMode

    # Arrange - Create a test mode with sensors 1 and 2
    test_mode = SafeHomeMode(
        mode_id=100,
        mode_name="TEST_AWAY",
        sensor_ids=[1, 2],
    )
    config_manager.safehome_modes[100] = test_mode

    # Ensure all sensors are disarmed
    sensor_manager.disarm_all_sensors()
    assert sensor_manager.get_sensor(1).is_armed() is False
    assert sensor_manager.get_sensor(2).is_armed() is False

    # Act
    result = config_manager.change_to_safehome_mode("TEST_AWAY")

    # Assert - Sensors 1 and 2 should be armed, sensor 3 should be disarmed
    assert result is True
    assert sensor_manager.get_sensor(1).is_armed() is True
    assert sensor_manager.get_sensor(2).is_armed() is True
    assert sensor_manager.get_sensor(3).is_armed() is False


def test_change_to_safehome_mode_disarms_non_listed_sensors(
    config_manager, sensor_manager
):
    """Test mode change disarms sensors not in the mode's list."""
    from configurations.safehome_mode import SafeHomeMode

    # Arrange - Create a test mode with only sensor 1
    test_mode = SafeHomeMode(
        mode_id=101,
        mode_name="TEST_STAY",
        sensor_ids=[1],
    )
    config_manager.safehome_modes[101] = test_mode

    # Arm all sensors first
    sensor_manager.arm_all_sensors()
    assert sensor_manager.get_sensor(1).is_armed() is True
    assert sensor_manager.get_sensor(2).is_armed() is True
    assert sensor_manager.get_sensor(3).is_armed() is True

    # Act
    result = config_manager.change_to_safehome_mode("TEST_STAY")

    # Assert - Only sensor 1 should be armed, others disarmed
    assert result is True
    assert sensor_manager.get_sensor(1).is_armed() is True
    assert sensor_manager.get_sensor(2).is_armed() is False
    assert sensor_manager.get_sensor(3).is_armed() is False


# ==================== Safety Zone Integration Tests ====================


def test_arm_safety_zone_arms_sensors_in_zone(config_manager, sensor_manager):
    """Test arming safety zone arms all sensors within the zone."""
    # Arrange
    zones = config_manager.get_all_safety_zones()
    if not zones:
        pytest.skip("No safety zones in test database")

    zone_id = list(zones.keys())[0]
    _ = zones[zone_id]

    # Disarm all sensors first
    sensor_manager.disarm_all_sensors()

    # Act
    result = config_manager.arm_safety_zone(zone_id)

    # Assert
    assert result is True


def test_disarm_safety_zone_disarms_sensors(config_manager, sensor_manager):
    """Test disarming safety zone disarms sensors in zone."""
    # Arrange
    zones = config_manager.get_all_safety_zones()
    if not zones:
        pytest.skip("No safety zones in test database")

    zone_id = list(zones.keys())[0]

    # Arm the zone first
    config_manager.arm_safety_zone(zone_id)

    # Act
    result = config_manager.disarm_safety_zone(zone_id)

    # Assert
    assert result is True


# ==================== Sensor Sync Integration Tests ====================


def test_sensor_coordinates_sync_to_zones(config_manager, sensor_manager):
    """Test sensors are assigned to zones based on coordinates."""
    # Arrange - Get all zones
    _ = config_manager.get_all_safety_zones()

    # Act - Trigger sync (already done in init, but verify)
    config_manager._sync_sensors_to_zones()

    # Assert - Zones should have sensors assigned based on coordinates
    # This verifies the integration between ConfigurationManager
    # and SensorManager coordinate systems
    assert sensor_manager.sensor_dict is not None
    assert len(sensor_manager.sensor_dict) == 3
