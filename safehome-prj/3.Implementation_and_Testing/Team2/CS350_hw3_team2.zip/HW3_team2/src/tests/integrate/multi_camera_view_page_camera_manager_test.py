"""
Integration Test: MultiCameraViewPage + CameraManager

Tests the interaction between MultiCameraViewPage and CameraManager.
Verifies camera list display, password validation, and slot click handling.
"""

from unittest.mock import MagicMock

import pytest

from database.schema.camera import CameraValidationResult
from device.appliance.camera import SafeHomeCamera
from manager.camera_manager import CameraManager

# ==================== Fixtures ====================


@pytest.fixture
def mock_storage_manager():
    """Create a mock StorageManager."""
    storage = MagicMock()
    storage.get_all_cameras.return_value = []
    storage.update_camera.return_value = True
    return storage


@pytest.fixture
def cameras():
    """Create multiple SafeHomeCamera instances."""
    cam1 = SafeHomeCamera(
        camera_id=1,
        coordinate_x=100,
        coordinate_y=100,
        pan=0,
        zoom_setting=1,
        has_password=False,
        password=None,
        enabled=True,
    )
    cam2 = SafeHomeCamera(
        camera_id=2,
        coordinate_x=200,
        coordinate_y=200,
        pan=0,
        zoom_setting=1,
        has_password=True,
        password="secret",
        enabled=True,
    )
    cam3 = SafeHomeCamera(
        camera_id=3,
        coordinate_x=300,
        coordinate_y=300,
        pan=0,
        zoom_setting=1,
        has_password=False,
        password=None,
        enabled=False,
    )
    return [cam1, cam2, cam3]


@pytest.fixture
def camera_manager(mock_storage_manager, cameras):
    """Create CameraManager with multiple cameras."""
    manager = CameraManager(storage_manager=mock_storage_manager)
    manager.camera_list = cameras
    return manager


# ==================== Camera List Integration Tests ====================


def test_multi_camera_page_displays_all_cameras(camera_manager):
    """Test MultiCameraViewPage can access all cameras through manager."""
    # Act - Simulate page accessing camera_manager.camera_list
    camera_list = camera_manager.camera_list

    # Assert
    assert len(camera_list) == 3
    assert camera_list[0].get_id() == 1
    assert camera_list[1].get_id() == 2
    assert camera_list[2].get_id() == 3


def test_multi_camera_page_shows_disabled_camera_status(camera_manager):
    """Test page correctly identifies disabled cameras."""
    # Arrange
    cameras = camera_manager.camera_list

    # Act - Simulate page checking enabled status for display
    statuses = [cam.is_enabled() for cam in cameras]

    # Assert
    assert statuses[0] is True  # Camera 1: enabled
    assert statuses[1] is True  # Camera 2: enabled
    assert statuses[2] is False  # Camera 3: disabled


# ==================== Password Validation Integration Tests =============


def test_multi_camera_page_validate_password_correct(camera_manager):
    """Test password validation returns VALID for correct password."""
    # Arrange
    camera_id = 2  # Camera with password "secret"

    # Act - Simulate page calling validate_camera_password
    result = camera_manager.validate_camera_password(camera_id, "secret")

    # Assert
    assert result == CameraValidationResult.VALID


def test_multi_camera_page_validate_password_incorrect(camera_manager):
    """Test password validation returns INCORRECT for wrong password."""
    # Arrange
    camera_id = 2  # Camera with password "secret"

    # Act
    result = camera_manager.validate_camera_password(camera_id, "wrong")

    # Assert
    assert result == CameraValidationResult.INCORRECT


# ==================== Slot Click Integration Tests ====================


def test_multi_camera_page_slot_click_unlocks_camera(camera_manager):
    """Test clicking locked camera slot and
    entering correct password unlocks it."""
    # Arrange
    camera = camera_manager.camera_list[1]  # Camera 2 with password
    assert camera.is_locked() is True

    # Act - Simulate page validating password and unlocking
    validation = camera_manager.validate_camera_password(
        camera.get_id(), "secret"
    )
    if validation == CameraValidationResult.VALID:
        camera.unlock()

    # Assert
    assert camera.is_locked() is False
