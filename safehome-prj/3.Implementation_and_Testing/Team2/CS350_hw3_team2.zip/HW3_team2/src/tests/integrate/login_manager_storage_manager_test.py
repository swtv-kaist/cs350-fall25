"""
Integration Test: LoginManager + StorageManager

Tests the interaction between LoginManager and StorageManager.
Verifies login authentication, password management, and database operations.
"""

import os
import tempfile

import pytest

from manager.login_manager import LoginManager
from manager.storage_manager import StorageManager

# ==================== Fixtures ====================


@pytest.fixture
def temp_db_path():
    """Create a temporary database file path."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield os.path.join(tmpdir, "test_safehome.db")


@pytest.fixture
def storage_manager(temp_db_path):
    """Create a real StorageManager with test database."""
    # Reset singleton
    StorageManager._instance = None

    manager = StorageManager(
        db_path=temp_db_path,
        reset_database=True,
    )

    # Insert test user
    manager.insert_user(
        user_id="test_user",
        role="HOMEOWNER",
        panel_id="admin",
        panel_password="1234",
        web_id="webadmin",
        web_password="password",
    )

    yield manager

    # Cleanup
    manager.clean_up()


@pytest.fixture
def login_manager(storage_manager):
    """Create LoginManager with real StorageManager."""
    return LoginManager(storage_manager=storage_manager)


# ==================== Panel Login Integration Tests ====================


def test_login_panel_success(login_manager):
    """Test successful panel login with correct credentials."""
    # Act
    result = login_manager.login_panel("admin", "1234")

    # Assert
    assert result is True
    assert login_manager.is_logged_in_panel is True
    assert login_manager.current_user_id == "admin"
    assert login_manager.login_trials == 0


def test_login_panel_failure_wrong_password(login_manager):
    """Test panel login failure with wrong password."""
    # Act
    result = login_manager.login_panel("admin", "wrong")

    # Assert
    assert result is False
    assert login_manager.is_logged_in_panel is False
    assert login_manager.login_trials == 1


# ==================== Web Login Integration Tests ====================


def test_login_web_success(login_manager):
    """Test successful web login with correct credentials."""
    # Act
    result = login_manager.login_web("webadmin", "password")

    # Assert
    assert result is True
    assert login_manager.is_logged_in_web is True
    assert login_manager.current_user_id == "webadmin"


def test_login_web_failure_wrong_credentials(login_manager):
    """Test web login failure with wrong credentials."""
    # Act
    result = login_manager.login_web("webadmin", "wrongpass")

    # Assert
    assert result is False
    assert login_manager.is_logged_in_web is False
    assert login_manager.login_trials == 1


# ==================== Password Change Integration Tests ====================


def test_change_panel_password_success(login_manager):
    """Test changing panel password with valid credentials."""
    # Act
    result = login_manager.change_panel_password("admin", "1234", "5678")

    # Assert
    assert result is True

    # Verify new password works
    assert login_manager.login_panel("admin", "5678") is True
