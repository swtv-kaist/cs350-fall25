"""Common."""

from .common import router

__all__ = ["router"]
