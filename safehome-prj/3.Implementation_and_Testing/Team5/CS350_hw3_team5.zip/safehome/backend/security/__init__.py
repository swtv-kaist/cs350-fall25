"""Security."""

from .security import router

__all__ = ["router"]
