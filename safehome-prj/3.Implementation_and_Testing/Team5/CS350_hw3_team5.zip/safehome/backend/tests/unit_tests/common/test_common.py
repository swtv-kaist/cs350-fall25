"""Tests for the common use cases."""

import pytest
from fastapi.testclient import TestClient

from backend.app import app
from backend.common.device import CameraDB, SensorDB
from backend.common.user import Device, DeviceType, User, UserDB

client = TestClient(app)


@pytest.fixture(autouse=True)
def reset_user_db():
    """Reset UserDB to initial state before each test."""
    UserDB.users = [
        User(
            user_id="homeowner1",
            password1="12345678",
            password2="abcdefgh",
            master_password="1234",
            guest_password="5678",
            delay_time=300,
            phone_number="01012345678",
            is_powered_on=True,
            address="123 Main St",
            devices=[
                # All motion sensors from SensorDB (device IDs: 1-2)
                Device(
                    type=DeviceType.SENSOR,
                    id=1,
                    sensor_info=SensorDB.get_motion_sensor(1),
                ),
                Device(
                    type=DeviceType.SENSOR,
                    id=2,
                    sensor_info=SensorDB.get_motion_sensor(2),
                ),
                # All windoor sensors from SensorDB (device IDs: 3-10)
                Device(
                    type=DeviceType.SENSOR,
                    id=3,
                    sensor_info=SensorDB.get_windoor_sensor(1),
                ),
                Device(
                    type=DeviceType.SENSOR,
                    id=4,
                    sensor_info=SensorDB.get_windoor_sensor(2),
                ),
                Device(
                    type=DeviceType.SENSOR,
                    id=5,
                    sensor_info=SensorDB.get_windoor_sensor(3),
                ),
                Device(
                    type=DeviceType.SENSOR,
                    id=6,
                    sensor_info=SensorDB.get_windoor_sensor(4),
                ),
                Device(
                    type=DeviceType.SENSOR,
                    id=7,
                    sensor_info=SensorDB.get_windoor_sensor(5),
                ),
                Device(
                    type=DeviceType.SENSOR,
                    id=8,
                    sensor_info=SensorDB.get_windoor_sensor(6),
                ),
                Device(
                    type=DeviceType.SENSOR,
                    id=9,
                    sensor_info=SensorDB.get_windoor_sensor(7),
                ),
                Device(
                    type=DeviceType.SENSOR,
                    id=10,
                    sensor_info=SensorDB.get_windoor_sensor(8),
                ),
                # All cameras from CameraDB (device IDs: 11-13)
                Device(
                    type=DeviceType.CAMERA,
                    id=11,
                    camera_info=CameraDB.get_camera(1),
                ),
                Device(
                    type=DeviceType.CAMERA,
                    id=12,
                    camera_info=CameraDB.get_camera(2),
                ),
                Device(
                    type=DeviceType.CAMERA,
                    id=13,
                    camera_info=CameraDB.get_camera(3),
                ),
            ],
            safety_zones=[],
        )
    ]


def test_control_panel_login_master_success():
    """Test successful master login through control panel."""
    response = client.post(
        "/control-panel-login/",
        json={
            "user_id": "homeowner1",
            "password": "1234",
        },
    )
    assert response.status_code == 200
    assert response.json() == "master"


def test_control_panel_login_guest_success():
    """Test successful guest login through control panel."""
    response = client.post(
        "/control-panel-login/",
        json={
            "user_id": "homeowner1",
            "password": "5678",
        },
    )
    assert response.status_code == 200
    assert response.json() == "guest"


def test_control_panel_login_invalid_user():
    """Test control panel login with invalid user ID."""
    response = client.post(
        "/control-panel-login/",
        json={
            "user_id": "unknown",
            "password": "1234",
        },
    )
    assert response.status_code == 401
    assert response.json()["detail"] == "ID not recognized"


def test_control_panel_login_wrong_password():
    """Test control panel login with wrong password."""
    response = client.post(
        "/control-panel-login/",
        json={
            "user_id": "homeowner1",
            "password": "wrongpass",
        },
    )
    assert response.status_code == 401
    assert response.json()["detail"] == "Password incorrect"


def test_login_success():
    """Test successful login."""
    response = client.post(
        "/login/",
        json={
            "user_id": "homeowner1",
            "password1": "12345678",
            "password2": "abcdefgh",
        },
    )
    assert response.status_code == 200
    assert response.json() == "Welcome!"


def test_login_invalid_user():
    """Test login with invalid user ID."""
    response = client.post(
        "/login/",
        json={
            "user_id": "unknown",
            "password1": "12345678",
            "password2": "abcdefgh",
        },
    )
    assert response.status_code == 401
    assert response.json()["detail"] == "ID not recognized"


def test_login_wrong_password():
    """Test login with wrong password."""
    response = client.post(
        "/login/",
        json={
            "user_id": "homeowner1",
            "password1": "wrongpass",
            "password2": "abcdefgh",
        },
    )
    assert response.status_code == 401
    assert response.json()["detail"] == "Password incorrect"


def test_config_success():
    """Test successful config update."""
    response = client.post(
        "/config/",
        json={
            "user_id": "homeowner1",
            "password1": "newpass1",
            "password2": "newpass2",
            "master_password": "newmaster",
            "guest_password": "newguest",
            "delay_time": 600,
            "phone_number": "01098765432",
        },
    )
    assert response.status_code == 200
    assert response.json() == {"message": "Configuration updated successfully"}
    # Check if actual values have changed
    assert UserDB.users[0].password1 == "newpass1"
    assert UserDB.users[0].password2 == "newpass2"
    assert UserDB.users[0].master_password == "newmaster"
    assert UserDB.users[0].guest_password == "newguest"
    assert UserDB.users[0].delay_time == 600
    assert UserDB.users[0].phone_number == "01098765432"


def test_config_invalid_user():
    """Test config with invalid user ID."""
    response = client.post(
        "/config/",
        json={
            "user_id": "unknown",
            "password1": "newpass1",
            "password2": "newpass2",
            "master_password": "newmaster",
            "guest_password": "newguest",
            "delay_time": 600,
            "phone_number": "01098765432",
        },
    )
    assert response.status_code == 401
    assert response.json()["detail"] == "Invalid user ID"


def test_config_delay_time_too_small():
    """Test config with delay time less than 0."""
    response = client.post(
        "/config/",
        json={
            "user_id": "homeowner1",
            "password1": None,
            "password2": None,
            "master_password": None,
            "guest_password": None,
            "delay_time": -1,
            "phone_number": None,
        },
    )
    assert response.status_code == 400
    assert response.json()["detail"] == "Delay time must be at least 0"


def test_power_on_success():
    """Test successful power on."""
    response = client.post(
        "/power-on/",
        json={"user_id": "homeowner1"},
    )
    assert response.status_code == 200
    assert response.json() == {"message": "System powered on"}
    # Check if actual value has changed
    assert UserDB.users[0].is_powered_on is True


def test_power_on_invalid_user():
    """Test power on with invalid user ID."""
    response = client.post(
        "/power-on/",
        json={"user_id": "unknown"},
    )
    assert response.status_code == 401
    assert response.json()["detail"] == "Invalid user ID"


def test_power_off_success():
    """Test successful power off."""
    response = client.post(
        "/power-off/",
        json={"user_id": "homeowner1"},
    )
    assert response.status_code == 200
    assert response.json() == {"message": "System powered off"}
    # Check if actual value has changed
    assert UserDB.users[0].is_powered_on is False


def test_power_off_invalid_user():
    """Test power off with invalid user ID."""
    response = client.post(
        "/power-off/",
        json={"user_id": "unknown"},
    )
    assert response.status_code == 401
    assert response.json()["detail"] == "Invalid user ID"


def test_get_config_success():
    """Test successful get config."""
    from backend.common.common import get_config
    from backend.common.request import GetConfigRequest

    # Test the function directly to cover the missing lines
    request = GetConfigRequest(user_id="homeowner1")
    result = get_config(request)
    assert "password1" in result
    assert "password2" in result
    assert "master_password" in result
    assert "guest_password" in result
    assert "delay_time" in result
    assert "phone_number" in result


def test_get_config_invalid_user():
    """Test get config with invalid user ID."""
    from fastapi import HTTPException

    from backend.common.common import get_config
    from backend.common.request import GetConfigRequest

    # Test the function directly to cover the missing lines
    request = GetConfigRequest(user_id="unknown")
    with pytest.raises(HTTPException) as exc_info:
        get_config(request)
    assert exc_info.value.status_code == 401
    assert exc_info.value.detail == "Invalid user ID"
