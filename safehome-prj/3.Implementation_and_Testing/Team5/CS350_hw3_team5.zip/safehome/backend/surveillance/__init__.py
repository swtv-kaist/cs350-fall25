"""Surveillance API module."""

from .surveillance import router

__all__ = ["router"]
