"""Control panel."""
