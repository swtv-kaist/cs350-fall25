"""
Create submission zip file for SafeHome project.
Excludes unnecessary files like __pycache__, .git, etc.
"""
import os
import zipfile
from pathlib import Path


def should_exclude(path: str) -> bool:
    """Check if path should be excluded from zip."""
    exclude_patterns = [
        '__pycache__',
        '.git',
        '.pytest_cache',
        '.coverage',
        'htmlcov',
        '.venv',
        'venv',
        '.idea',
        '.vscode',
        '*.pyc',
        '*.pyo',
        '.DS_Store',
        'Thumbs.db',
        '~$',  # Word temp files
        'nul',
        '.claude',
        'create_submission_zip.py',  # This script itself
        'convert_to_docx.py',
        'convert_to_docx_v2.py',
        'create_appendix.py',
        'merge_documents',  # Merge scripts
        '_temp_fixed.md',
        '__MACOSX',  # Mac metadata
        '.msi',  # Installer files
        '_updated.docx',  # Old versions
        '_updated_v2.docx',
        '_v3.docx',
        '_v4.docx',
        '_MConverter',  # Converter temp files
        'virtual_device_v4\\virtual_device_v4',  # Duplicated folder
        'merge_full.py',
    ]

    path_lower = path.lower()
    for pattern in exclude_patterns:
        if pattern in path_lower:
            return True
    return False


def create_submission_zip():
    project_root = Path(r"C:\Users\louis\Desktop\kaist\25 fall\소공개\SafeHome_team9")
    output_zip = project_root.parent / "SafeHome_Team9_Submission.zip"

    # Files/folders to include
    include_items = [
        # a. Python implementation (source code)
        'main.py',
        'requirements.txt',
        'auth',
        'common',
        'config',
        'devices',
        'domain',
        'event_logging',
        'interfaces',
        'security',
        'storage',
        'surveillance',
        'templates',
        'ui',
        'utils',
        'virtual_device_v4',

        # b. User manual
        'README.md',

        # c. Test document (editable word files)
        'docs',

        # d. Test scripts
        'tests',
    ]

    with zipfile.ZipFile(output_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for item in include_items:
            item_path = project_root / item

            if not item_path.exists():
                print(f"Warning: {item} not found, skipping...")
                continue

            if item_path.is_file():
                # Single file
                if not should_exclude(str(item_path)):
                    arcname = f"SafeHome_Team9/{item}"
                    zipf.write(item_path, arcname)
                    print(f"Added: {arcname}")
            else:
                # Directory
                for root, dirs, files in os.walk(item_path):
                    # Filter out excluded directories
                    dirs[:] = [d for d in dirs if not should_exclude(d)]

                    for file in files:
                        file_path = Path(root) / file
                        if should_exclude(str(file_path)):
                            continue

                        # Calculate relative path
                        rel_path = file_path.relative_to(project_root)
                        arcname = f"SafeHome_Team9/{rel_path}"

                        zipf.write(file_path, arcname)
                        print(f"Added: {arcname}")

    print(f"\n{'='*50}")
    print(f"Submission zip created: {output_zip}")
    print(f"Size: {output_zip.stat().st_size / 1024 / 1024:.2f} MB")
    print(f"{'='*50}")

    # List contents summary
    print("\nZip contents summary:")
    with zipfile.ZipFile(output_zip, 'r') as zipf:
        folders = set()
        file_count = 0
        for name in zipf.namelist():
            parts = name.split('/')
            if len(parts) > 2:
                folders.add(parts[1])
            file_count += 1

        print(f"Total files: {file_count}")
        print(f"Main folders: {', '.join(sorted(folders))}")


if __name__ == "__main__":
    create_submission_zip()
