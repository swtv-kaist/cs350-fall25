"""
Tests package for SafeHome system
"""

