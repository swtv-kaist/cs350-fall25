from typing import Dict, List, Optional

from PIL import Image

from .safehome_camera import SafeHomeCamera


class CameraAccessGuard:
    """Helper to centralize camera lookup and password/lock checks."""

    def __init__(self, logger=None):
        self.logger = logger

    def require_access(
        self,
        camera: Optional[SafeHomeCamera],
        camera_id: int,
        password: Optional[str],
        action: str,
    ):
        """Validate camera existence and password/lock; return camera or None."""
        if not camera:
            self._warn(f"Camera access denied: Camera {camera_id} not found")
            return None

        if camera.has_password() and not camera.verify_password(password):
            self._warn(
                f"Camera {camera_id} {action} denied: Invalid password or locked"
            )
            return None

        return camera

    def _warn(self, msg: str):
        if self.logger:
            self.logger.add_log(msg, level="WARNING", source="CameraController")


class CameraController:
    """
    Camera Controller manages all cameras in the system
    Provides centralized camera management with password protection
    Based on SRS requirements UC19-25 for camera access control
    """

    def __init__(
        self, storage_manager=None, logger=None, login_manager=None, settings=None
    ):
        """
        Initialize Camera Controller

        Args:
            storage_manager: StorageManager for persistence
            logger: LogManager for logging events
            login_manager: LoginManager for user authentication
            settings: SystemSettings (for lockout policy)
        """
        self.cameras: Dict[int, SafeHomeCamera] = (
            {}
        )  # {camera_id: SafeHomeCamera instance}
        self.storage = storage_manager
        self.logger = logger
        self.login_manager = login_manager
        self._next_camera_id = 1  # Auto-increment camera ID
        self.max_attempts = (
            getattr(settings, "max_login_attempts", 3) if settings else 3
        )
        self.lockout_seconds = (
            getattr(settings, "system_lock_time", 300) if settings else 300
        )
        self.access_guard = CameraAccessGuard(logger)

    def add_camera(
        self, name: str, location: str, password: Optional[str] = None
    ) -> SafeHomeCamera:
        """
        Add a new camera to the system

        Args:
            name: Camera name
            location: Physical location description
            password: Optional password for camera access

        Returns:
            Created camera instance
        """
        camera_id = self._next_camera_id
        self._next_camera_id += 1

        # Create camera
        camera = SafeHomeCamera(
            camera_id,
            name,
            location,
            password,
            max_attempts=self.max_attempts,
            lockout_seconds=self.lockout_seconds,
        )

        # Store camera
        self.cameras[camera_id] = camera

        # Persist to database
        if self.storage:
            self.storage.save_camera(camera_id, name, location, password)

        # Log event
        if self.logger:
            self.logger.add_log(
                f"Camera {camera_id} ({name}) added at {location}",
                source="CameraController",
            )

        return camera

    def remove_camera(self, camera_id: int) -> bool:
        """
        Remove a camera from the system

        Args:
            camera_id: ID of camera to remove

        Returns:
            True if removed, False if not found
        """
        if camera_id not in self.cameras:
            return False

        camera = self.cameras[camera_id]

        # Stop camera hardware
        camera.stop()

        # Remove from memory
        del self.cameras[camera_id]

        # Remove from database
        if self.storage:
            self.storage.delete_camera(camera_id)

        # Log event
        if self.logger:
            self.logger.add_log(
                f"Camera {camera_id} removed", source="CameraController"
            )

        return True

    def get_camera(self, camera_id: int) -> Optional[SafeHomeCamera]:
        """Get camera by ID"""
        return self.cameras.get(camera_id)

    def get_all_cameras(self) -> List[SafeHomeCamera]:
        """Get list of all cameras"""
        return list(self.cameras.values())

    def get_camera_view(
        self, camera_id: int, password: Optional[str] = None
    ) -> Optional[Image.Image]:
        """
        Get camera view with password verification
        Implements SRS UC19-25 camera password protection

        Args:
            camera_id: Camera ID
            password: Password for camera access (if required)

        Returns:
            PIL Image if access granted, None otherwise
        """
        camera = self._get_camera_with_access(camera_id, password, action="view")
        if not camera:
            return None

        view = camera.get_view()

        if view and self.logger:
            self.logger.add_log(
                f"Camera {camera_id} view accessed", source="CameraController"
            )

        return view

    def pan_camera(
        self, camera_id: int, direction: str, password: Optional[str] = None
    ) -> bool:
        """
        Pan camera left or right with password verification

        Args:
            camera_id: Camera ID
            direction: 'left' or 'right'
            password: Password for camera access (if required)

        Returns:
            True if successful, False otherwise
        """
        camera = self._get_camera_with_access(camera_id, password, action="pan")
        if not camera:
            return False

        # Pan camera
        success = False
        if direction.lower() == "left":
            success = camera.pan_left()
        elif direction.lower() == "right":
            success = camera.pan_right()

        # Log action
        if success and self.logger:
            self.logger.add_log(
                f"Camera {camera_id} panned {direction}", source="CameraController"
            )

        return success

    def tilt_camera(
        self, camera_id: int, direction: str, password: Optional[str] = None
    ) -> bool:
        """
        Tilt camera up or down with password verification

        Args:
            camera_id: Camera ID
            direction: 'up' or 'down'
            password: Password for camera access (if required)

        Returns:
            True if successful, False otherwise
        """
        camera = self._get_camera_with_access(camera_id, password, action="tilt")
        if not camera:
            return False

        # Tilt camera
        success = False
        if direction.lower() == "up":
            success = camera.tilt_up()
        elif direction.lower() == "down":
            success = camera.tilt_down()

        # Log action
        if success and self.logger:
            self.logger.add_log(
                f"Camera {camera_id} tilted {direction}", source="CameraController"
            )

        return success

    def zoom_camera(
        self, camera_id: int, direction: str, password: Optional[str] = None
    ) -> bool:
        """
        Zoom camera in or out with password verification

        Args:
            camera_id: Camera ID
            direction: 'in' or 'out'
            password: Password for camera access (if required)

        Returns:
            True if successful, False otherwise
        """
        camera = self._get_camera_with_access(camera_id, password, action="zoom")
        if not camera:
            return False

        # Zoom camera
        success = False
        if direction.lower() == "in":
            success = camera.zoom_in()
        elif direction.lower() == "out":
            success = camera.zoom_out()

        # Log action
        if success and self.logger:
            self.logger.add_log(
                f"Camera {camera_id} zoomed {direction}", source="CameraController"
            )

        return success

    def enable_camera(self, camera_id: int, role: str) -> bool:
        """
        Enable a camera

        Args:
            camera_id: Camera ID
            role: The role of the user requesting the action.
        Returns:
            True if enabled, False if not found or permission denied.
        """
        if role != "admin":
            if self.logger:
                self.logger.add_log(
                    f"User with role '{role}' tried to enable camera {camera_id}. Denied.",
                    level="WARNING",
                    source="CameraController",
                )
            return False

        camera = self.get_camera(camera_id)
        if not camera:
            return False

        camera.enable()

        if self.logger:
            self.logger.add_log(
                f"Camera {camera_id} enabled", source="CameraController"
            )

        return True

    def disable_camera(self, camera_id: int, role: str) -> bool:
        """
        Disable a camera

        Args:
            camera_id: Camera ID
            role: The role of the user requesting the action.
        Returns:
            True if disabled, False if not found or permission denied.
        """
        if role != "admin":
            if self.logger:
                self.logger.add_log(
                    f"User with role '{role}' tried to disable camera {camera_id}. Denied.",
                    level="WARNING",
                    source="CameraController",
                )
            return False

        camera = self.get_camera(camera_id)
        if not camera:
            return False

        camera.disable()

        if self.logger:
            self.logger.add_log(
                f"Camera {camera_id} disabled", source="CameraController"
            )

        return True

    def set_camera_password(
        self,
        camera_id: int,
        new_password: Optional[str],
        old_password: Optional[str] = None,
        confirm_password: Optional[str] = None,
    ) -> bool:
        """
        Set or change camera password (requires current password if one exists).

        Args:
            camera_id: Camera ID
            new_password: Desired new password (None is not allowed here; use delete_camera_password to remove)
            old_password: Current password (required if a password is already set)
            confirm_password: Confirmation of new password

        Returns:
            True if successful, False otherwise
        """
        camera = self.get_camera(camera_id)
        if not camera or new_password is None:
            return False

        if confirm_password is not None and new_password != confirm_password:
            if self.logger:
                self.logger.add_log(
                    f"Camera {camera_id} password change failed: confirmation mismatch",
                    level="WARNING",
                    source="CameraController",
                )
            return False

        # If password exists, require old_password
        if camera.has_password():
            if not camera.verify_password(old_password):
                if self.logger:
                    self.logger.add_log(
                        f"Camera {camera_id} password change denied: invalid old password or locked",
                        level="WARNING",
                        source="CameraController",
                    )
                return False

        camera.set_password(new_password)

        # Update in database
        if self.storage:
            self.storage.update_camera_password(camera_id, new_password)

        # Log event
        if self.logger:
            self.logger.add_log(
                f"Camera {camera_id} password set/changed", source="CameraController"
            )

        return True

    def delete_camera_password(
        self, camera_id: int, old_password: Optional[str] = None
    ) -> bool:
        """
        Remove camera password (requires current password if set).
        """
        camera = self.get_camera(camera_id)
        if not camera:
            return False

        if camera.has_password():
            if not camera.verify_password(old_password):
                if self.logger:
                    self.logger.add_log(
                        f"Camera {camera_id} password delete denied: invalid old password or locked",
                        level="WARNING",
                        source="CameraController",
                    )
                return False

        camera.set_password(None)

        # Update in database
        if self.storage:
            self.storage.update_camera_password(camera_id, None)

        if self.logger:
            self.logger.add_log(
                f"Camera {camera_id} password removed", source="CameraController"
            )
        return True

    # ===== Internal helpers =====
    def _get_camera_with_access(
        self, camera_id: int, password: Optional[str], action: str
    ):
        """
        Retrieve camera and verify password/lock state for an action.
        """
        camera = self.get_camera(camera_id)
        return self.access_guard.require_access(camera, camera_id, password, action)

    def get_camera_status(self, camera_id: int) -> Optional[dict]:
        """
        Get status of a specific camera

        Args:
            camera_id: Camera ID

        Returns:
            Status dictionary or None if not found
        """
        camera = self.get_camera(camera_id)
        if camera:
            return camera.get_status()
        return None

    def get_all_camera_statuses(self) -> List[dict]:
        """
        Get status of all cameras

        Returns:
            List of status dictionaries
        """
        return [camera.get_status() for camera in self.cameras.values()]

    def load_cameras_from_storage(self):
        """Load cameras from database storage"""
        if not self.storage:
            return

        camera_data = self.storage.load_all_cameras()

        # Reset in-memory state before loading to avoid duplicates
        self.cameras.clear()
        self._next_camera_id = 1

        for data in camera_data:
            camera_id = data["camera_id"]
            name = data["camera_name"]
            location = data["camera_location"]
            password = data.get("camera_password")

            # Update next ID
            if camera_id >= self._next_camera_id:
                self._next_camera_id = camera_id + 1

            # Create camera
            camera = SafeHomeCamera(
                camera_id,
                name,
                location,
                password,
                max_attempts=self.max_attempts,
                lockout_seconds=self.lockout_seconds,
            )
            self.cameras[camera_id] = camera

        if self.logger:
            self.logger.add_log(
                f"Loaded {len(camera_data)} cameras from storage",
                source="CameraController",
            )

    def shutdown(self):
        """Stop all camera hardware threads"""
        for camera in self.cameras.values():
            camera.stop()

        if self.logger:
            self.logger.add_log("All cameras stopped", source="CameraController")
