"""
SafeHome Core System Layer
Main system logic and integration
"""

from .system import System

__all__ = ["System"]
