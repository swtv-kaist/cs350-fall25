# Tests package initializer (keeps pytest imports stable from repo root)
