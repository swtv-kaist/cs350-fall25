class IControlPanelSettingsDB:
    def __init__(self):
        pass

    def get_master_password(self) -> str:
        pass

    def set_master_password(self, new_password) -> None:
        pass

    def get_guest_password(self) -> str:
        pass

    def set_guest_password(self, new_password) -> None:
        pass
