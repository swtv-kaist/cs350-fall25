class IPasswordDB:
    def __init__(self):
        pass

    def get_password(self, user_id):
        pass

    def set_password(self, user_id, new_password):
        pass
